#!/usr/bin/env bash
set -euo pipefail
FILE="${1:-}"
if [ -z "$FILE" ]; then
    echo "Usage: $0 <backup-file.sql.gz>"
    exit 1
fi
if [ ! -f "$FILE" ]; then
    echo "File not found: $FILE"
    exit 1
fi
echo "[$(date)] Restoring from $FILE..."
gzip -dc "$FILE" | docker compose exec -T db psql -U corepulse corepulse
echo "[$(date)] Restore complete"
