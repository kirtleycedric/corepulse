import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

export function formatBps(bps: number): string {
  if (bps < 1000) return `${bps} bps`;
  if (bps < 1_000_000) return `${(bps / 1000).toFixed(1)} Kbps`;
  if (bps < 1_000_000_000) return `${(bps / 1_000_000).toFixed(1)} Mbps`;
  return `${(bps / 1_000_000_000).toFixed(1)} Gbps`;
}

export function formatPercent(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`;
}

export function formatUptime(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

export function formatIops(iops: number): string {
  if (iops < 1000) return `${iops.toFixed(0)} IOPS`;
  return `${(iops / 1000).toFixed(1)}K IOPS`;
}

export function formatLatency(us: number): string {
  if (us < 1000) return `${us.toFixed(0)}µs`;
  return `${(us / 1000).toFixed(2)}ms`;
}

export function statusColor(status: string | null | undefined): string {
  switch (status) {
    case 'success': case 'healthy': case 'online': case 'running': return 'text-status-healthy';
    case 'warning': return 'text-status-warning';
    case 'error': case 'critical': case 'offline': case 'stopped': return 'text-status-critical';
    default: return 'text-status-unknown';
  }
}

export function statusDotClass(status: string | null | undefined): string {
  switch (status) {
    case 'success': case 'healthy': case 'online': case 'running': return 'healthy';
    case 'warning': return 'warning';
    case 'error': case 'critical': case 'offline': case 'stopped': return 'critical';
    default: return 'unknown';
  }
}

export function severityColor(severity: string): string {
  switch (severity) {
    case 'critical': return 'text-status-critical';
    case 'warning': return 'text-status-warning';
    case 'info': return 'text-status-info';
    default: return 'text-muted-foreground';
  }
}

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '…';
}
