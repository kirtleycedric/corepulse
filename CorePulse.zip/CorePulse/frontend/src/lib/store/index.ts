// CorePulse — Zustand state stores
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { AlertIncident, DeviceSummary, Severity, WSMessage } from '@/types';

// ── Auth store ────────────────────────────────────────────────────────────────
interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  username: string | null;
  role: string | null;
  isAuthenticated: boolean;
  setTokens: (access: string, refresh: string, username: string, role: string) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      accessToken: null,
      refreshToken: null,
      username: null,
      role: null,
      isAuthenticated: false,
      setTokens: (access, refresh, username, role) => {
        if (typeof window !== 'undefined') {
          localStorage.setItem('cp_access_token', access);
          localStorage.setItem('cp_refresh_token', refresh);
        }
        set({ accessToken: access, refreshToken: refresh, username, role, isAuthenticated: true });
      },
      clearAuth: () => {
        if (typeof window !== 'undefined') {
          localStorage.removeItem('cp_access_token');
          localStorage.removeItem('cp_refresh_token');
        }
        set({ accessToken: null, refreshToken: null, username: null, role: null, isAuthenticated: false });
      },
    }),
    { name: 'cp-auth', partialize: (s) => ({ username: s.username, role: s.role, isAuthenticated: s.isAuthenticated }) }
  )
);

// ── UI store ──────────────────────────────────────────────────────────────────
interface UIState {
  sidebarCollapsed: boolean;
  nocMode: boolean;
  timeRange: string;
  theme: 'light' | 'dark' | 'system';
  toggleSidebar: () => void;
  toggleNocMode: () => void;
  setTimeRange: (range: string) => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      nocMode: false,
      timeRange: '1h',
      theme: 'dark',
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      toggleNocMode: () => set((s) => ({ nocMode: !s.nocMode })),
      setTimeRange: (timeRange) => set({ timeRange }),
      setTheme: (theme) => set({ theme }),
    }),
    { name: 'cp-ui' }
  )
);

// ── WebSocket store ────────────────────────────────────────────────────────────
interface WSState {
  connected: boolean;
  connId: string | null;
  subscriptions: Set<string>;
  setConnected: (connected: boolean, connId?: string) => void;
  addSubscription: (room: string) => void;
  removeSubscription: (room: string) => void;
}

export const useWSStore = create<WSState>()((set) => ({
  connected: false,
  connId: null,
  subscriptions: new Set(),
  setConnected: (connected, connId) => set({ connected, connId: connId || null }),
  addSubscription: (room) => set((s) => ({ subscriptions: new Set([...s.subscriptions, room]) })),
  removeSubscription: (room) => set((s) => {
    const next = new Set(s.subscriptions);
    next.delete(room);
    return { subscriptions: next };
  }),
}));

// ── Metrics store (ring buffer per device+metric) ─────────────────────────────
interface MetricEntry {
  timestamp: number;
  value: number;
  labels: Record<string, string>;
}

interface MetricsState {
  // key: `${device_id}:${metric}`
  data: Record<string, MetricEntry[]>;
  maxPoints: number;
  push: (deviceId: string, metric: string, value: number, labels: Record<string, string>) => void;
  getLatest: (deviceId: string, metric: string) => MetricEntry | undefined;
  getSeries: (deviceId: string, metric: string) => MetricEntry[];
}

export const useMetricsStore = create<MetricsState>()((set, get) => ({
  data: {},
  maxPoints: 300,
  push: (deviceId, metric, value, labels) => {
    const key = `${deviceId}:${metric}`;
    const entry: MetricEntry = { timestamp: Date.now(), value, labels };
    set((s) => {
      const existing = s.data[key] || [];
      const next = [...existing, entry];
      // Ring buffer — keep last maxPoints entries
      const trimmed = next.length > s.maxPoints ? next.slice(next.length - s.maxPoints) : next;
      return { data: { ...s.data, [key]: trimmed } };
    });
  },
  getLatest: (deviceId, metric) => {
    const key = `${deviceId}:${metric}`;
    const series = get().data[key];
    return series?.[series.length - 1];
  },
  getSeries: (deviceId, metric) => {
    return get().data[`${deviceId}:${metric}`] || [];
  },
}));

// ── Alert store ────────────────────────────────────────────────────────────────
interface AlertState {
  firingIncidents: AlertIncident[];
  unacknowledgedCount: number;
  addIncident: (incident: AlertIncident) => void;
  resolveIncident: (id: string) => void;
  acknowledgeIncident: (id: string) => void;
  setIncidents: (incidents: AlertIncident[]) => void;
}

export const useAlertStore = create<AlertState>()((set, get) => ({
  firingIncidents: [],
  unacknowledgedCount: 0,
  addIncident: (incident) => set((s) => {
    const incidents = [incident, ...s.firingIncidents.filter(i => i.id !== incident.id)].slice(0, 100);
    return { firingIncidents: incidents, unacknowledgedCount: incidents.filter(i => !i.acknowledged && i.status === 'firing').length };
  }),
  resolveIncident: (id) => set((s) => {
    const incidents = s.firingIncidents.map(i => i.id === id ? { ...i, status: 'resolved' as const } : i);
    return { firingIncidents: incidents, unacknowledgedCount: incidents.filter(i => !i.acknowledged && i.status === 'firing').length };
  }),
  acknowledgeIncident: (id) => set((s) => {
    const incidents = s.firingIncidents.map(i => i.id === id ? { ...i, acknowledged: true } : i);
    return { firingIncidents: incidents, unacknowledgedCount: incidents.filter(i => !i.acknowledged && i.status === 'firing').length };
  }),
  setIncidents: (incidents) => set({
    firingIncidents: incidents,
    unacknowledgedCount: incidents.filter(i => !i.acknowledged && i.status === 'firing').length,
  }),
}));

// ── Dashboard edit store ───────────────────────────────────────────────────────
import type { WidgetConfig } from '@/types';

interface DashEditState {
  editing: boolean;
  dashboardId: string | null;
  widgets: WidgetConfig[];
  dirty: boolean;
  startEditing: (id: string, widgets: WidgetConfig[]) => void;
  stopEditing: () => void;
  updateWidgets: (widgets: WidgetConfig[]) => void;
  addWidget: (widget: WidgetConfig) => void;
  removeWidget: (id: string) => void;
}

export const useDashEditStore = create<DashEditState>()((set) => ({
  editing: false,
  dashboardId: null,
  widgets: [],
  dirty: false,
  startEditing: (id, widgets) => set({ editing: true, dashboardId: id, widgets, dirty: false }),
  stopEditing: () => set({ editing: false, dashboardId: null, widgets: [], dirty: false }),
  updateWidgets: (widgets) => set({ widgets, dirty: true }),
  addWidget: (widget) => set((s) => ({ widgets: [...s.widgets, widget], dirty: true })),
  removeWidget: (id) => set((s) => ({ widgets: s.widgets.filter(w => w.id !== id), dirty: true })),
}));
