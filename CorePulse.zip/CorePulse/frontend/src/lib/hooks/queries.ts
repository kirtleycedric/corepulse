// CorePulse — React Query hooks
'use client';
import { useQuery, useMutation, useQueryClient, UseQueryOptions } from '@tanstack/react-query';
import { devicesApi, metricsApi, alertsApi, dashboardsApi, usersApi, healthApi } from '@/lib/api/client';
import { Device, AlertRule, AlertIncident, Dashboard, MetricSeries, User } from '@/types';
import { subSeconds, formatISO } from 'date-fns';

// ── Query keys ─────────────────────────────────────────────────────────────────
export const qk = {
  devices: (params?: object) => ['devices', params] as const,
  device: (id: string) => ['device', id] as const,
  deviceInterfaces: (id: string) => ['device', id, 'interfaces'] as const,
  deviceSummary: (id: string) => ['device', id, 'summary'] as const,
  metrics: (params: object) => ['metrics', params] as const,
  alertRules: (params?: object) => ['alert-rules', params] as const,
  alertRule: (id: string) => ['alert-rule', id] as const,
  incidents: (params?: object) => ['incidents', params] as const,
  dashboards: (params?: object) => ['dashboards', params] as const,
  dashboard: (id: string) => ['dashboard', id] as const,
  users: (params?: object) => ['users', params] as const,
  health: () => ['health'] as const,
};

// ── Devices ───────────────────────────────────────────────────────────────────
export function useDevices(params?: Parameters<typeof devicesApi.list>[0]) {
  return useQuery({
    queryKey: qk.devices(params),
    queryFn: () => devicesApi.list(params),
    staleTime: 30_000,
  });
}

export function useDevice(id: string) {
  return useQuery({
    queryKey: qk.device(id),
    queryFn: () => devicesApi.get(id),
    enabled: !!id,
    staleTime: 15_000,
  });
}

export function useDeviceInterfaces(id: string) {
  return useQuery({
    queryKey: qk.deviceInterfaces(id),
    queryFn: () => devicesApi.interfaces(id),
    enabled: !!id,
    staleTime: 60_000,
  });
}

export function useDeviceSummary(id: string, refreshInterval?: number) {
  return useQuery({
    queryKey: qk.deviceSummary(id),
    queryFn: () => devicesApi.summary(id),
    enabled: !!id,
    refetchInterval: refreshInterval || 30_000,
    staleTime: 15_000,
  });
}

export function useCreateDevice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: devicesApi.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['devices'] }),
  });
}

export function useUpdateDevice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Device> }) => devicesApi.update(id, data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['devices'] });
      qc.invalidateQueries({ queryKey: qk.device(id) });
    },
  });
}

export function useDeleteDevice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => devicesApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['devices'] }),
  });
}

export function usePollDevice() {
  return useMutation({
    mutationFn: (id: string) => devicesApi.poll(id),
  });
}

// ── Metrics ───────────────────────────────────────────────────────────────────
export function useMetrics(params: {
  device_id?: string;
  metric?: string;
  metric_prefix?: string;
  timeRangeSeconds?: number;
  aggregation?: string;
  bucket_interval?: string;
  enabled?: boolean;
}) {
  const { timeRangeSeconds = 3600, enabled = true, ...rest } = params;
  const from_ts = formatISO(subSeconds(new Date(), timeRangeSeconds));
  const to_ts = formatISO(new Date());

  return useQuery({
    queryKey: qk.metrics({ ...rest, from_ts }),
    queryFn: () => metricsApi.query({
      ...rest,
      from_ts,
      to_ts,
      bucket_interval: rest.bucket_interval || (timeRangeSeconds <= 3600 ? '1m' : timeRangeSeconds <= 86400 ? '5m' : '1h'),
    }),
    enabled,
    staleTime: 30_000,
    refetchInterval: 30_000,
  });
}

// ── Alerts ────────────────────────────────────────────────────────────────────
export function useAlertRules(params?: Parameters<typeof alertsApi.listRules>[0]) {
  return useQuery({
    queryKey: qk.alertRules(params),
    queryFn: () => alertsApi.listRules(params),
    staleTime: 60_000,
  });
}

export function useIncidents(params?: Parameters<typeof alertsApi.listIncidents>[0]) {
  return useQuery({
    queryKey: qk.incidents(params),
    queryFn: () => alertsApi.listIncidents(params),
    staleTime: 10_000,
    refetchInterval: 30_000,
  });
}

export function useAcknowledgeIncident() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, note }: { id: string; note?: string }) => alertsApi.acknowledge(id, note),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['incidents'] }),
  });
}

export function useCreateAlertRule() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: alertsApi.createRule,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['alert-rules'] }),
  });
}

export function useDeleteAlertRule() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: alertsApi.deleteRule,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['alert-rules'] }),
  });
}

// ── Dashboards ────────────────────────────────────────────────────────────────
export function useDashboards(params?: Parameters<typeof dashboardsApi.list>[0]) {
  return useQuery({
    queryKey: qk.dashboards(params),
    queryFn: () => dashboardsApi.list(params),
    staleTime: 60_000,
  });
}

export function useDashboard(id: string) {
  return useQuery({
    queryKey: qk.dashboard(id),
    queryFn: () => dashboardsApi.get(id),
    enabled: !!id,
    staleTime: 30_000,
  });
}

export function useUpdateDashboard() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Dashboard> }) => dashboardsApi.update(id, data),
    onSuccess: (_, { id }) => qc.invalidateQueries({ queryKey: qk.dashboard(id) }),
  });
}

export function useCreateDashboard() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: dashboardsApi.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['dashboards'] }),
  });
}

export function useDeleteDashboard() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: dashboardsApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['dashboards'] }),
  });
}

// ── Users ─────────────────────────────────────────────────────────────────────
export function useUsers() {
  return useQuery({
    queryKey: qk.users(),
    queryFn: () => usersApi.list(),
    staleTime: 120_000,
  });
}

// ── Health ─────────────────────────────────────────────────────────────────────
export function useHealth() {
  return useQuery({
    queryKey: qk.health(),
    queryFn: healthApi.check,
    staleTime: 10_000,
    refetchInterval: 30_000,
  });
}
