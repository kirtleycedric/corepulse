// CorePulse — typed API client
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import {
  AlertIncident, AlertRule, Dashboard, Device, DeviceInterface,
  MetricSeries, PaginatedResponse, TokenResponse, User,
  FlashSystemArray, ProxmoxNode, DeviceSummary,
} from '@/types';

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || '';

function createAxiosInstance(): AxiosInstance {
  const instance = axios.create({
    baseURL: `${BASE_URL}/api/v1`,
    timeout: 30000,
    headers: { 'Content-Type': 'application/json' },
  });

  // Attach access token
  instance.interceptors.request.use((config) => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('cp_access_token');
      if (token) config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  // Auto-refresh on 401
  instance.interceptors.response.use(
    (res) => res,
    async (error) => {
      const original = error.config;
      if (error.response?.status === 401 && !original._retry) {
        original._retry = true;
        try {
          const refreshToken = localStorage.getItem('cp_refresh_token');
          if (!refreshToken) throw new Error('No refresh token');
          const res = await axios.post<TokenResponse>(`${BASE_URL}/api/v1/auth/refresh`, {
            refresh_token: refreshToken,
          });
          localStorage.setItem('cp_access_token', res.data.access_token);
          localStorage.setItem('cp_refresh_token', res.data.refresh_token);
          original.headers.Authorization = `Bearer ${res.data.access_token}`;
          return instance(original);
        } catch {
          localStorage.removeItem('cp_access_token');
          localStorage.removeItem('cp_refresh_token');
          window.location.href = '/auth/login';
          return Promise.reject(error);
        }
      }
      return Promise.reject(error);
    }
  );

  return instance;
}

export const api = createAxiosInstance();

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authApi = {
  login: (username: string, password: string) =>
    api.post<TokenResponse>('/auth/login', { username, password }).then(r => r.data),
  logout: (refreshToken: string) =>
    api.post('/auth/logout', { refresh_token: refreshToken }),
  me: () => api.get<User>('/auth/me').then(r => r.data),
};

// ── Devices ───────────────────────────────────────────────────────────────────
export const devicesApi = {
  list: (params?: { device_type?: string; enabled?: boolean; site?: string; page?: number; page_size?: number }) =>
    api.get<PaginatedResponse<Device>>('/devices', { params }).then(r => r.data),
  get: (id: string) => api.get<Device>(`/devices/${id}`).then(r => r.data),
  create: (data: Partial<Device>) => api.post<Device>('/devices', data).then(r => r.data),
  update: (id: string, data: Partial<Device>) => api.patch<Device>(`/devices/${id}`, data).then(r => r.data),
  delete: (id: string) => api.delete(`/devices/${id}`),
  interfaces: (id: string) => api.get<DeviceInterface[]>(`/devices/${id}/interfaces`).then(r => r.data),
  poll: (id: string) => api.post<{ task_id: string }>(`/devices/${id}/poll`).then(r => r.data),
  summary: (id: string) => api.get<DeviceSummary>(`/metrics/device/${id}/summary`).then(r => r.data),
};

// ── Metrics ───────────────────────────────────────────────────────────────────
export const metricsApi = {
  query: (params: {
    device_id?: string;
    metric?: string;
    metric_prefix?: string;
    from_ts?: string;
    to_ts?: string;
    aggregation?: string;
    bucket_interval?: string;
    limit?: number;
  }) => api.post<MetricSeries[]>('/metrics/query', params).then(r => r.data),
  topTalkers: (params: { metric: string; device_id?: string; limit?: number; window_minutes?: number }) =>
    api.get<unknown[]>('/metrics/top-talkers', { params }).then(r => r.data),
  stats: () => api.get<unknown>('/metrics/stats').then(r => r.data),
};

// ── Alerts ────────────────────────────────────────────────────────────────────
export const alertsApi = {
  listRules: (params?: { enabled?: boolean; severity?: string; page?: number }) =>
    api.get<PaginatedResponse<AlertRule>>('/alerts/rules', { params }).then(r => r.data),
  getRule: (id: string) => api.get<AlertRule>(`/alerts/rules/${id}`).then(r => r.data),
  createRule: (data: Partial<AlertRule>) => api.post<AlertRule>('/alerts/rules', data).then(r => r.data),
  updateRule: (id: string, data: Partial<AlertRule>) => api.patch<AlertRule>(`/alerts/rules/${id}`, data).then(r => r.data),
  deleteRule: (id: string) => api.delete(`/alerts/rules/${id}`),
  listIncidents: (params?: { status?: string; severity?: string; device_id?: string; acknowledged?: boolean; page?: number }) =>
    api.get<PaginatedResponse<AlertIncident>>('/alerts/incidents', { params }).then(r => r.data),
  acknowledge: (id: string, note?: string) =>
    api.post<AlertIncident>(`/alerts/incidents/${id}/acknowledge`, { note }).then(r => r.data),
  listChannels: () => api.get<unknown[]>('/alerts/channels').then(r => r.data),
  createChannel: (data: unknown) => api.post('/alerts/channels', data).then(r => r.data),
};

// ── Dashboards ────────────────────────────────────────────────────────────────
export const dashboardsApi = {
  list: (params?: { is_template?: boolean; is_starred?: boolean; page?: number }) =>
    api.get<PaginatedResponse<Dashboard>>('/dashboards', { params }).then(r => r.data),
  get: (id: string) => api.get<Dashboard>(`/dashboards/${id}`).then(r => r.data),
  create: (data: Partial<Dashboard>) => api.post<Dashboard>('/dashboards', data).then(r => r.data),
  update: (id: string, data: Partial<Dashboard>) => api.put<Dashboard>(`/dashboards/${id}`, data).then(r => r.data),
  delete: (id: string) => api.delete(`/dashboards/${id}`),
  star: (id: string) => api.post(`/dashboards/${id}/star`),
};

// ── Users ─────────────────────────────────────────────────────────────────────
export const usersApi = {
  list: (params?: { page?: number; page_size?: number }) =>
    api.get<PaginatedResponse<User>>('/users', { params }).then(r => r.data),
  get: (id: string) => api.get<User>(`/users/${id}`).then(r => r.data),
  create: (data: Partial<User> & { password: string }) => api.post<User>('/users', data).then(r => r.data),
  update: (id: string, data: Partial<User> & { password?: string }) =>
    api.patch<User>(`/users/${id}`, data).then(r => r.data),
  delete: (id: string) => api.delete(`/users/${id}`),
};

// ── Discovery ─────────────────────────────────────────────────────────────────
export const discoveryApi = {
  scan: (subnet: string, community?: string, snmp_version?: string) =>
    api.post<{ task_id: string; subnet: string; status: string }>(
      `/discovery/scan?subnet=${encodeURIComponent(subnet)}&community=${community || 'public'}&snmp_version=${snmp_version || '2c'}`
    ).then(r => r.data),
  result: (taskId: string) =>
    api.get<{ status: string; result?: unknown }>(`/discovery/result/${taskId}`).then(r => r.data),
};

// ── Health ─────────────────────────────────────────────────────────────────────
export const healthApi = {
  check: () => api.get<{ status: string; version: string; services: Record<string, string> }>('/health').then(r => r.data),
};
