// CorePulse — WebSocket manager singleton
import { useMetricsStore, useAlertStore, useWSStore } from '@/lib/store';
import { WSMessage } from '@/types';

const WS_BASE = process.env.NEXT_PUBLIC_WS_URL || (
  typeof window !== 'undefined'
    ? `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}/api/v1/ws`
    : 'ws://localhost:8000/api/v1/ws'
);

class WSManager {
  private ws: WebSocket | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectDelay = 1000;
  private maxDelay = 30000;
  private shouldConnect = false;
  private pendingSubscriptions: Set<string> = new Set();
  private messageHandlers: Map<string, Set<(msg: WSMessage) => void>> = new Map();

  connect(token?: string): void {
    this.shouldConnect = true;
    this.reconnectDelay = 1000;
    this._connect(token);
  }

  private _connect(token?: string): void {
    if (!this.shouldConnect) return;
    if (typeof window === 'undefined') return;

    const url = token ? `${WS_BASE}?token=${encodeURIComponent(token)}` : WS_BASE;
    this.ws = new WebSocket(url);

    this.ws.onopen = () => {
      console.info('[WS] Connected');
      this.reconnectDelay = 1000;
      useWSStore.getState().setConnected(true);

      // Re-subscribe to all pending rooms
      for (const room of this.pendingSubscriptions) {
        this._send({ type: 'subscribe', room });
      }
    };

    this.ws.onmessage = (event) => {
      try {
        const msg: WSMessage = JSON.parse(event.data);
        this._route(msg);
      } catch {
        // Ignore unparseable messages
      }
    };

    this.ws.onclose = (event) => {
      useWSStore.getState().setConnected(false);
      if (!this.shouldConnect) return;
      const delay = this.reconnectDelay;
      this.reconnectDelay = Math.min(delay * 2, this.maxDelay);
      console.info(`[WS] Closed (${event.code}), reconnecting in ${delay}ms`);
      this.reconnectTimer = setTimeout(() => this._connect(token), delay);
    };

    this.ws.onerror = () => {
      useWSStore.getState().setConnected(false);
    };
  }

  disconnect(): void {
    this.shouldConnect = false;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  subscribe(room: string): void {
    this.pendingSubscriptions.add(room);
    useWSStore.getState().addSubscription(room);
    if (this.ws?.readyState === WebSocket.OPEN) {
      this._send({ type: 'subscribe', room });
    }
  }

  unsubscribe(room: string): void {
    this.pendingSubscriptions.delete(room);
    useWSStore.getState().removeSubscription(room);
    if (this.ws?.readyState === WebSocket.OPEN) {
      this._send({ type: 'unsubscribe', room });
    }
  }

  on(messageType: string, handler: (msg: WSMessage) => void): () => void {
    if (!this.messageHandlers.has(messageType)) {
      this.messageHandlers.set(messageType, new Set());
    }
    this.messageHandlers.get(messageType)!.add(handler);
    return () => this.messageHandlers.get(messageType)?.delete(handler);
  }

  ping(): void {
    this._send({ type: 'ping' });
  }

  private _send(data: object): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  private _route(msg: WSMessage): void {
    // Built-in routing to Zustand stores
    switch (msg.type) {
      case 'connected':
        useWSStore.getState().setConnected(true, msg.conn_id);
        break;
      case 'metric_update':
        useMetricsStore.getState().push(
          msg.device_id, msg.metric, msg.value, msg.labels
        );
        break;
      case 'alert_event':
        // Handled by listeners
        break;
    }

    // Dispatch to registered handlers
    const handlers = this.messageHandlers.get(msg.type);
    if (handlers) {
      handlers.forEach(h => h(msg));
    }
    // Also dispatch to wildcard handlers
    const wildcards = this.messageHandlers.get('*');
    if (wildcards) {
      wildcards.forEach(h => h(msg));
    }
  }
}

// Singleton
export const wsManager = new WSManager();
