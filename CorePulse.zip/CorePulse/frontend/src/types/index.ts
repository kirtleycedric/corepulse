// CorePulse — shared TypeScript types

export type DeviceType =
  | 'proxmox_cluster' | 'proxmox_node' | 'vm' | 'container'
  | 'flashsystem' | 'juniper_switch' | 'cisco_sg300'
  | 'cisco_catalyst' | 'generic_snmp' | 'generic';

export type DeviceStatus = 'success' | 'error' | 'timeout' | 'unknown';
export type Severity = 'info' | 'warning' | 'critical';
export type AlertStatus = 'firing' | 'resolved' | 'suppressed';
export type Role = 'viewer' | 'operator' | 'engineer' | 'admin';

// ── Auth ──────────────────────────────────────────────────────────────────────
export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}

export interface UserContext {
  user_id: string;
  username: string;
  email: string;
  role: Role;
  is_superuser: boolean;
  permissions: string[];
}

// ── Devices ───────────────────────────────────────────────────────────────────
export interface Device {
  id: string;
  name: string;
  display_name: string;
  device_type: DeviceType;
  host: string;
  port: number | null;
  enabled: boolean;
  poll_interval_seconds: number;
  location: string;
  site: string;
  tags: Record<string, string>;
  vendor: string | null;
  model: string | null;
  firmware_version: string | null;
  sys_name: string | null;
  last_seen_at: string | null;
  last_poll_at: string | null;
  last_poll_status: DeviceStatus | null;
  consecutive_failures: number;
  created_at: string;
  updated_at: string;
}

export interface DeviceInterface {
  id: string;
  device_id: string;
  if_index: number;
  if_name: string;
  if_alias: string;
  if_descr: string;
  if_speed_bps: number;
  if_phys_addr: string;
  if_admin_status: number;
  if_oper_status: number;
  vlan_id: number | null;
  lldp_neighbor: string | null;
  lldp_neighbor_port: string | null;
  enabled_monitoring: boolean;
  updated_at: string;
}

// ── Metrics ───────────────────────────────────────────────────────────────────
export interface MetricPoint {
  timestamp: string;
  value: number;
  labels: Record<string, string>;
}

export interface MetricSeries {
  device_id: string;
  metric: string;
  unit: string;
  data: MetricPoint[];
}

export interface DeviceSummary {
  [metric: string]: {
    value: number;
    unit: string;
    timestamp: string;
    labels: Record<string, string>;
  };
}

// ── Alerts ────────────────────────────────────────────────────────────────────
export interface AlertRule {
  id: string;
  name: string;
  description: string;
  device_id: string | null;
  device_type_filter: string | null;
  tag_filter: Record<string, string>;
  metric: string;
  condition_type: string;
  condition_config: Record<string, unknown>;
  severity: Severity;
  enabled: boolean;
  cooldown_seconds: number;
  notification_channel_ids: string[];
  maintenance_until: string | null;
  created_at: string;
  updated_at: string;
}

export interface AlertIncident {
  id: string;
  rule_id: string;
  device_id: string;
  metric: string;
  severity: Severity;
  status: AlertStatus;
  trigger_value: number;
  trigger_labels: Record<string, string>;
  message: string;
  triggered_at: string;
  resolved_at: string | null;
  acknowledged: boolean;
  acknowledged_by: string | null;
  acknowledged_at: string | null;
}

// ── Dashboards ────────────────────────────────────────────────────────────────
export interface WidgetConfig {
  id: string;
  type: WidgetType;
  x: number;
  y: number;
  w: number;
  h: number;
  config: Record<string, unknown>;
}

export type WidgetType =
  | 'timeseries' | 'gauge' | 'stat' | 'heatmap' | 'bar_cluster'
  | 'port_table' | 'alert_list' | 'host_card' | 'topology_map' | 'text'
  | 'top_talkers' | 'vm_status' | 'storage_pools';

export interface Dashboard {
  id: string;
  name: string;
  description: string;
  owner_id: string | null;
  is_public: boolean;
  is_template: boolean;
  is_starred: boolean;
  layout: { widgets: WidgetConfig[] };
  variables: Record<string, unknown>;
  time_range: string;
  refresh_interval_seconds: number;
  tags: string[];
  version: number;
  slug: string;
  created_at: string;
  updated_at: string;
}

// ── WebSocket ─────────────────────────────────────────────────────────────────
export type WSMessage =
  | { type: 'connected'; conn_id: string }
  | { type: 'metric_update'; device_id: string; metric: string; value: number; labels: Record<string, string> }
  | { type: 'alert_event'; event: string; incident_id: string; severity: Severity; message: string }
  | { type: 'heartbeat'; timestamp: string }
  | { type: 'subscribed'; room: string }
  | { type: 'pong'; timestamp: string };

// ── Pagination ─────────────────────────────────────────────────────────────────
export interface PaginatedResponse<T> {
  total: number;
  page: number;
  page_size: number;
  items: T[];
}

// ── Users ──────────────────────────────────────────────────────────────────────
export interface User {
  id: string;
  username: string;
  email: string;
  full_name: string;
  role: Role;
  is_active: boolean;
  is_superuser: boolean;
  last_login_at: string | null;
  created_at: string;
  updated_at: string;
}

// ── Proxmox ───────────────────────────────────────────────────────────────────
export interface ProxmoxNode {
  id: string;
  device_id: string;
  node_name: string;
  status: string;
  cpu_count: number;
  cpu_util: number;
  mem_total_bytes: number;
  mem_used_bytes: number;
  disk_total_bytes: number;
  disk_used_bytes: number;
  uptime_seconds: number;
  pve_version: string;
  updated_at: string;
}

// ── FlashSystem ───────────────────────────────────────────────────────────────
export interface FlashSystemArray {
  id: string;
  device_id: string;
  array_name: string;
  model: string;
  code_level: string;
  total_capacity_bytes: number;
  used_capacity_bytes: number;
  free_capacity_bytes: number;
  read_iops: number;
  write_iops: number;
  read_bandwidth_mbps: number;
  write_bandwidth_mbps: number;
  read_latency_us: number;
  write_latency_us: number;
  status: string;
  updated_at: string;
}

export interface TimeRange {
  label: string;
  value: string;
  seconds: number;
}

export const TIME_RANGES: TimeRange[] = [
  { label: '15m', value: '15m', seconds: 900 },
  { label: '1h',  value: '1h',  seconds: 3600 },
  { label: '3h',  value: '3h',  seconds: 10800 },
  { label: '6h',  value: '6h',  seconds: 21600 },
  { label: '12h', value: '12h', seconds: 43200 },
  { label: '24h', value: '24h', seconds: 86400 },
  { label: '7d',  value: '7d',  seconds: 604800 },
];
