'use client';
import { useWSStore } from '@/lib/store';
import { useHealth } from '@/lib/hooks/queries';
import { cn } from '@/lib/utils';

export function StatusBar() {
  const wsConnected = useWSStore(s => s.connected);
  const { data: health } = useHealth();

  const dbStatus = health?.services?.database || 'unknown';
  const redisStatus = health?.services?.redis || 'unknown';
  const isHealthy = (s: string) => s === 'healthy';

  return (
    <footer className="flex items-center h-8 px-4 gap-4 border-t border-border bg-card shrink-0 text-2xs text-muted-foreground">
      <span className="flex items-center gap-1.5">
        <span className={cn('w-1.5 h-1.5 rounded-full', wsConnected ? 'bg-status-healthy' : 'bg-status-warning')} />
        {wsConnected ? 'Live' : 'Reconnecting...'}
      </span>
      <span className="flex items-center gap-1.5">
        <span className={cn('w-1.5 h-1.5 rounded-full', isHealthy(dbStatus) ? 'bg-status-healthy' : 'bg-status-critical')} />
        DB
      </span>
      <span className="flex items-center gap-1.5">
        <span className={cn('w-1.5 h-1.5 rounded-full', isHealthy(redisStatus) ? 'bg-status-healthy' : 'bg-status-critical')} />
        Redis
      </span>
      <span className="ml-auto">CorePulse v1.0.0</span>
    </footer>
  );
}
