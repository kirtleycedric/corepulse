'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Activity, AlertTriangle, BarChart3, ChevronLeft, ChevronRight,
  Database, HardDrive, LayoutDashboard, Network, Server,
  Settings, Shield, Users, Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUIStore, useAlertStore } from '@/lib/store';

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  badge?: () => number | null;
  group?: string;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Overview', href: '/dashboard', icon: LayoutDashboard, group: 'main' },
  { label: 'Dashboards', href: '/dashboards', icon: BarChart3, group: 'main' },
  { label: 'Alerts', href: '/alerts', icon: AlertTriangle, group: 'main' },
  { label: 'Cluster', href: '/cluster', icon: Server, group: 'infrastructure' },
  { label: 'Network', href: '/network', icon: Network, group: 'infrastructure' },
  { label: 'Storage', href: '/storage', icon: HardDrive, group: 'infrastructure' },
  { label: 'Devices', href: '/devices', icon: Zap, group: 'inventory' },
  { label: 'Discovery', href: '/discovery', icon: Activity, group: 'inventory' },
  { label: 'Users', href: '/users', icon: Users, group: 'admin' },
  { label: 'Settings', href: '/settings', icon: Settings, group: 'admin' },
];

const GROUP_LABELS: Record<string, string> = {
  main: '',
  infrastructure: 'Infrastructure',
  inventory: 'Inventory',
  admin: 'Admin',
};

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebar } = useUIStore();
  const unacknowledgedCount = useAlertStore(s => s.unacknowledgedCount);

  const groups = ['main', 'infrastructure', 'inventory', 'admin'];

  return (
    <aside
      className={cn(
        'flex flex-col h-full border-r border-border bg-sidebar-bg transition-all duration-200 select-none',
        sidebarCollapsed ? 'w-12' : 'w-[220px]'
      )}
      style={{ background: 'hsl(var(--cp-sidebar-bg, 222 47% 11%))' }}
    >
      {/* Logo */}
      <div className={cn(
        'flex items-center gap-2 px-3 py-3 border-b border-white/10',
        sidebarCollapsed ? 'justify-center' : ''
      )}>
        <div className="flex-shrink-0 w-7 h-7 rounded bg-primary flex items-center justify-center">
          <span className="text-xs font-bold text-white">CP</span>
        </div>
        {!sidebarCollapsed && (
          <span className="text-sm font-semibold text-white tracking-wide">CorePulse</span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2">
        {groups.map(group => {
          const items = NAV_ITEMS.filter(i => i.group === group);
          const label = GROUP_LABELS[group];
          return (
            <div key={group} className="mb-1">
              {label && !sidebarCollapsed && (
                <div className="px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white/30">
                  {label}
                </div>
              )}
              {items.map(item => {
                const active = pathname === item.href || pathname.startsWith(item.href + '/');
                const Icon = item.icon;
                const badge = item.badge ? item.badge() : null;
                const showBadge = item.href === '/alerts' && unacknowledgedCount > 0;

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    title={sidebarCollapsed ? item.label : undefined}
                    className={cn(
                      'flex items-center gap-2.5 mx-1 px-2 py-1.5 rounded text-sm transition-colors',
                      active
                        ? 'bg-primary text-white'
                        : 'text-white/60 hover:text-white hover:bg-white/10',
                      sidebarCollapsed ? 'justify-center' : ''
                    )}
                  >
                    <Icon size={15} className="flex-shrink-0" />
                    {!sidebarCollapsed && (
                      <span className="flex-1 truncate">{item.label}</span>
                    )}
                    {showBadge && !sidebarCollapsed && (
                      <span className="ml-auto flex-shrink-0 min-w-4 h-4 rounded-full bg-destructive text-xs text-white flex items-center justify-center px-1">
                        {unacknowledgedCount > 99 ? '99+' : unacknowledgedCount}
                      </span>
                    )}
                    {showBadge && sidebarCollapsed && (
                      <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-destructive" />
                    )}
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={toggleSidebar}
        className="flex items-center justify-center h-8 mx-2 mb-2 rounded text-white/40 hover:text-white hover:bg-white/10 transition-colors"
        aria-label={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {sidebarCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>
    </aside>
  );
}
