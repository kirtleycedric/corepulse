'use client';
import { Bell, Moon, RefreshCw, Search, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { useUIStore, useAlertStore, useWSStore } from '@/lib/store';
import { TIME_RANGES } from '@/types';
import { cn } from '@/lib/utils';

export function Topbar() {
  const { timeRange, setTimeRange } = useUIStore();
  const { setTheme, resolvedTheme } = useTheme();
  const unackCount = useAlertStore(s => s.unacknowledgedCount);
  const wsConnected = useWSStore(s => s.connected);

  return (
    <header className="flex items-center h-11 px-4 gap-3 border-b border-border bg-card shrink-0">
      {/* Search */}
      <div className="flex items-center gap-2 flex-1 max-w-sm rounded bg-muted px-2.5 py-1 text-muted-foreground hover:bg-muted/80 transition-colors">
        <Search size={13} />
        <input
          className="flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground/60"
          placeholder="Search devices, dashboards..."
          aria-label="Global search"
        />
        <kbd className="hidden sm:inline text-2xs px-1 py-0.5 rounded border border-border font-mono">⌘K</kbd>
      </div>

      <div className="flex items-center gap-1 ml-auto">
        {/* Time range */}
        <div className="flex items-center gap-0.5 rounded border border-border bg-card px-0.5">
          {TIME_RANGES.map(range => (
            <button
              key={range.value}
              onClick={() => setTimeRange(range.value)}
              className={cn(
                'px-2 py-0.5 rounded text-xs transition-colors',
                timeRange === range.value
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {range.label}
            </button>
          ))}
        </div>

        {/* Refresh */}
        <button
          className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          aria-label="Refresh data"
        >
          <RefreshCw size={14} />
        </button>

        {/* Alert bell */}
        <button
          className="relative p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          aria-label={`${unackCount} unacknowledged alerts`}
        >
          <Bell size={14} />
          {unackCount > 0 && (
            <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-destructive animate-pulse-slow" />
          )}
        </button>

        {/* Theme toggle */}
        <button
          onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
          className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          aria-label="Toggle theme"
        >
          {resolvedTheme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
        </button>

        {/* WS indicator */}
        <div
          className={cn('w-2 h-2 rounded-full ml-1', wsConnected ? 'bg-status-healthy' : 'bg-status-warning')}
          title={wsConnected ? 'Real-time: connected' : 'Real-time: reconnecting...'}
          role="status"
          aria-label={wsConnected ? 'WebSocket connected' : 'WebSocket disconnected'}
        />
      </div>
    </header>
  );
}
