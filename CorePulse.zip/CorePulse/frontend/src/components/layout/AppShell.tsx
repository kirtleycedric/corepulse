'use client';
import { usePathname } from 'next/navigation';
import { Sidebar } from './Sidebar';
import { Topbar } from './Topbar';
import { StatusBar } from './StatusBar';
import { useUIStore } from '@/lib/store';
import { cn } from '@/lib/utils';

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { sidebarCollapsed, nocMode } = useUIStore();

  const isAuth = pathname.startsWith('/auth');
  if (isAuth) return <>{children}</>;

  return (
    <div className={cn('flex h-screen w-screen overflow-hidden bg-background', nocMode && 'noc-mode')}>
      {!nocMode && <Sidebar />}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {!nocMode && <Topbar />}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
        {!nocMode && <StatusBar />}
      </div>
    </div>
  );
}
