'use client';
import { Device } from '@/types';
import { cn, statusDotClass, truncate } from '@/lib/utils';
import Link from 'next/link';

interface DeviceStatusGridProps {
  devices: Device[];
}

const deviceTypeLabel: Record<string, string> = {
  proxmox_cluster: 'PVE',
  proxmox_node: 'Node',
  vm: 'VM',
  container: 'CT',
  flashsystem: 'Flash',
  juniper_switch: 'Juniper',
  cisco_sg300: 'SG300',
  cisco_catalyst: 'Cat',
  generic_snmp: 'SNMP',
  generic: 'Dev',
};

export function DeviceStatusGrid({ devices }: DeviceStatusGridProps) {
  if (devices.length === 0) {
    return (
      <div className="text-xs text-muted-foreground py-4 text-center">
        No devices configured
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-1.5">
      {devices.map(device => (
        <Link
          key={device.id}
          href={`/devices/${device.id}`}
          className="group flex flex-col items-center gap-1 p-2 rounded border border-border hover:border-primary hover:bg-accent transition-colors"
          title={`${device.name}\n${device.host}\nStatus: ${device.last_poll_status ?? 'unknown'}`}
        >
          <span className={cn('status-dot', statusDotClass(device.last_poll_status))} />
          <span className="text-2xs font-medium truncate w-full text-center">
            {truncate(device.display_name || device.name, 10)}
          </span>
          <span className="text-2xs text-muted-foreground">
            {deviceTypeLabel[device.device_type] || device.device_type}
          </span>
          {device.consecutive_failures > 0 && (
            <span className="text-2xs text-status-warning">
              ×{device.consecutive_failures}
            </span>
          )}
        </Link>
      ))}
    </div>
  );
}
