'use client';
import { X, GripVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { WidgetConfig } from '@/types';

interface WidgetCardProps {
  widget: WidgetConfig;
  editing: boolean;
  onRemove?: () => void;
  children: React.ReactNode;
}

export function WidgetCard({ widget, editing, onRemove, children }: WidgetCardProps) {
  return (
    <div className="h-full flex flex-col bg-card border border-border rounded-lg overflow-hidden group">
      {/* Header visible only in edit mode */}
      {editing && (
        <div className="flex items-center gap-1 px-2 py-1 bg-muted/50 border-b border-border shrink-0 cursor-move select-none">
          <GripVertical size={12} className="text-muted-foreground" />
          <span className="flex-1 text-2xs text-muted-foreground truncate capitalize">
            {widget.type.replace('_', ' ')}
          </span>
          {onRemove && (
            <button
              onClick={(e) => { e.stopPropagation(); onRemove(); }}
              className="p-0.5 rounded hover:bg-destructive/20 hover:text-destructive transition-colors"
              title="Remove widget"
            >
              <X size={10} />
            </button>
          )}
        </div>
      )}
      {/* Widget content */}
      <div className="flex-1 min-h-0 p-2">
        {children}
      </div>
    </div>
  );
}
