'use client';
import { useMemo } from 'react';
import type { WidgetConfig } from '@/types';
import { useMetrics, useIncidents, useDevices } from '@/lib/hooks/queries';
import { useUIStore } from '@/lib/store';
import { TIME_RANGES } from '@/types';
import { TimeseriesChart } from '@/components/charts/TimeseriesChart';
import { GaugeWidget } from '@/components/charts/GaugeWidget';
import { StatCard } from '@/components/widgets/StatCard';
import { AlertFeed } from '@/components/alerts/AlertFeed';
import { DeviceStatusGrid } from '@/components/devices/DeviceStatusGrid';
import { formatBytes, formatPercent } from '@/lib/utils';

interface WidgetRendererProps {
  widget: WidgetConfig;
  timeRange: string;
  refreshInterval?: number;
}

/**
 * Central widget dispatch — maps widget.type to the correct
 * component and feeds it data via React Query hooks.
 */
export function WidgetRenderer({ widget, timeRange, refreshInterval = 30 }: WidgetRendererProps) {
  const range = TIME_RANGES.find(r => r.value === timeRange) ?? TIME_RANGES[1];
  const { type, config } = widget;

  switch (type) {
    case 'timeseries':
      return <TimeseriesWidgetWrapper config={config} timeRangeSeconds={range.seconds} refreshInterval={refreshInterval} />;
    case 'gauge':
      return <GaugeWidgetWrapper config={config} />;
    case 'stat':
      return <StatWidgetWrapper config={config} />;
    case 'alert_list':
      return <AlertListWrapper config={config} />;
    case 'vm_status':
    case 'host_card':
      return <HostStatusWrapper config={config} />;
    case 'text':
      return <TextWidget config={config} />;
    default:
      return (
        <div className="h-full flex items-center justify-center text-xs text-muted-foreground">
          Unknown widget type: {type}
        </div>
      );
  }
}

// ── Timeseries widget ──────────────────────────────────────────────────────────
function TimeseriesWidgetWrapper({ config, timeRangeSeconds, refreshInterval }: {
  config: Record<string, unknown>;
  timeRangeSeconds: number;
  refreshInterval: number;
}) {
  const { data: series, isLoading } = useMetrics({
    device_id: config.device_id as string | undefined,
    metric: config.metric as string | undefined,
    metric_prefix: config.metric_prefix as string | undefined,
    timeRangeSeconds,
  });

  return (
    <TimeseriesChart
      series={series ?? []}
      title={config.title as string | undefined}
      unit={config.unit as string | undefined}
      height="100%"
      showLegend={(config.show_legend as boolean) ?? false}
      thresholdLine={config.threshold as number | undefined}
      loading={isLoading}
    />
  );
}

// ── Gauge widget ───────────────────────────────────────────────────────────────
function GaugeWidgetWrapper({ config }: { config: Record<string, unknown> }) {
  const { data: series } = useMetrics({
    device_id: config.device_id as string | undefined,
    metric: config.metric as string | undefined,
    timeRangeSeconds: 300, // 5 minutes for current value
  });

  const latestValue = useMemo(() => {
    if (!series?.length) return config.default_value as number ?? 0;
    const lastSeries = series[0];
    return lastSeries.data[lastSeries.data.length - 1]?.value ?? 0;
  }, [series, config]);

  return (
    <div className="h-full flex flex-col items-center justify-center">
      <GaugeWidget
        value={latestValue}
        min={config.min as number ?? 0}
        max={config.max as number ?? 100}
        unit={config.unit as string ?? '%'}
        label={config.label as string ?? ''}
        size={120}
      />
      {config.label && (
        <p className="text-xs text-muted-foreground mt-1">{config.label as string}</p>
      )}
    </div>
  );
}

// ── Stat widget ───────────────────────────────────────────────────────────────
function StatWidgetWrapper({ config }: { config: Record<string, unknown> }) {
  const { data: series } = useMetrics({
    device_id: config.device_id as string | undefined,
    metric: config.metric as string | undefined,
    timeRangeSeconds: 300,
  });

  const value = useMemo(() => {
    if (!series?.length) return '—';
    const s = series[0];
    const v = s.data[s.data.length - 1]?.value;
    if (v === undefined) return '—';
    const unit = config.unit as string ?? s.unit;
    if (unit === 'bytes') return formatBytes(v);
    if (unit === 'percent') return formatPercent(v);
    return v.toFixed(1);
  }, [series, config]);

  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <p className="text-xs text-muted-foreground mb-1">{config.label as string ?? config.metric as string}</p>
      <p className="text-2xl font-bold tabular-nums">{value}</p>
      {config.unit && <p className="text-xs text-muted-foreground mt-0.5">{config.unit as string}</p>}
    </div>
  );
}

// ── Alert list widget ─────────────────────────────────────────────────────────
function AlertListWrapper({ config }: { config: Record<string, unknown> }) {
  const { data } = useIncidents({ status: 'firing', page_size: config.max_items as number ?? 10 });
  return <AlertFeed incidents={data?.items ?? []} maxItems={config.max_items as number ?? 10} compact />;
}

// ── Host status widget ────────────────────────────────────────────────────────
function HostStatusWrapper({ config }: { config: Record<string, unknown> }) {
  const { data } = useDevices({
    device_type: config.device_type as string | undefined,
    enabled: true,
    page_size: 50,
  });
  return <DeviceStatusGrid devices={data?.items ?? []} />;
}

// ── Text/markdown widget ──────────────────────────────────────────────────────
function TextWidget({ config }: { config: Record<string, unknown> }) {
  return (
    <div className="h-full overflow-auto p-1 text-sm text-muted-foreground prose-sm prose-invert">
      {config.content as string ?? 'Add text in widget settings'}
    </div>
  );
}
