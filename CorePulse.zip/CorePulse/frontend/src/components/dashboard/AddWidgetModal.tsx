'use client';
import { useState } from 'react';
import { X } from 'lucide-react';
import type { WidgetConfig, WidgetType } from '@/types';
import { cn } from '@/lib/utils';
import { v4 as uuidv4 } from 'uuid';

interface WidgetTemplate {
  type: WidgetType;
  label: string;
  description: string;
  defaultConfig: Record<string, unknown>;
  defaultW: number;
  defaultH: number;
}

const WIDGET_REGISTRY: WidgetTemplate[] = [
  {
    type: 'timeseries',
    label: 'Time Series Chart',
    description: 'Line chart of any metric over time',
    defaultConfig: { metric: 'cpu.util', unit: 'percent', title: 'CPU Utilisation' },
    defaultW: 6, defaultH: 4,
  },
  {
    type: 'gauge',
    label: 'Gauge',
    description: 'Single-value gauge for current metric value',
    defaultConfig: { metric: 'cpu.util', unit: '%', min: 0, max: 100, label: 'CPU' },
    defaultW: 2, defaultH: 4,
  },
  {
    type: 'stat',
    label: 'Stat',
    description: 'Single large metric value',
    defaultConfig: { metric: 'storage.util', unit: 'percent', label: 'Storage' },
    defaultW: 2, defaultH: 2,
  },
  {
    type: 'alert_list',
    label: 'Alert Feed',
    description: 'Live feed of firing incidents',
    defaultConfig: { max_items: 10 },
    defaultW: 4, defaultH: 6,
  },
  {
    type: 'host_card',
    label: 'Device Status Grid',
    description: 'Grid of device health dots',
    defaultConfig: { device_type: undefined },
    defaultW: 6, defaultH: 4,
  },
  {
    type: 'text',
    label: 'Text',
    description: 'Static text or notes',
    defaultConfig: { content: 'Add your notes here' },
    defaultW: 4, defaultH: 2,
  },
];

interface AddWidgetModalProps {
  onClose: () => void;
  onAdd: (widget: WidgetConfig) => void;
  currentWidgetCount: number;
}

export function AddWidgetModal({ onClose, onAdd, currentWidgetCount }: AddWidgetModalProps) {
  const [selected, setSelected] = useState<WidgetTemplate | null>(null);

  const handleAdd = () => {
    if (!selected) return;
    const widget: WidgetConfig = {
      id: uuidv4(),
      type: selected.type,
      x: (currentWidgetCount * 2) % 12,
      y: Math.floor(currentWidgetCount / 6) * selected.defaultH,
      w: selected.defaultW,
      h: selected.defaultH,
      config: { ...selected.defaultConfig },
    };
    onAdd(widget);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-card border border-border rounded-lg w-full max-w-lg shadow-2xl animate-fade-in">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h2 className="text-sm font-semibold">Add Widget</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-foreground">
            <X size={14} />
          </button>
        </div>

        <div className="p-4 grid grid-cols-2 gap-2 max-h-96 overflow-y-auto">
          {WIDGET_REGISTRY.map(template => (
            <button
              key={template.type}
              onClick={() => setSelected(template)}
              className={cn(
                'text-left p-3 rounded border transition-colors',
                selected?.type === template.type
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:border-primary/50 hover:bg-accent'
              )}
            >
              <p className="text-xs font-medium">{template.label}</p>
              <p className="text-2xs text-muted-foreground mt-0.5">{template.description}</p>
              <p className="text-2xs text-muted-foreground/60 mt-1">
                {template.defaultW}×{template.defaultH} default
              </p>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 px-4 py-3 border-t border-border">
          <button
            onClick={onClose}
            className="flex-1 h-7 rounded border border-border text-xs hover:bg-accent"
          >
            Cancel
          </button>
          <button
            onClick={handleAdd}
            disabled={!selected}
            className="flex-1 h-7 rounded bg-primary text-primary-foreground text-xs hover:bg-primary/90 disabled:opacity-50"
          >
            Add {selected?.label ?? 'Widget'}
          </button>
        </div>
      </div>
    </div>
  );
}
