// StatCard widget
'use client';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
  delta?: number | null;
  unit?: string;
  valueClass?: string;
  subtitle?: string;
}

export function StatCard({ title, value, icon, delta, unit, valueClass, subtitle }: StatCardProps) {
  return (
    <div className="metric-card">
      <div className="flex items-center justify-between text-muted-foreground">
        <span className="text-xs font-medium truncate">{title}</span>
        {icon && <span className="opacity-60">{icon}</span>}
      </div>
      <div className={cn('text-2xl font-semibold tabular-nums mt-1', valueClass)}>
        {value}{unit && <span className="text-sm font-normal text-muted-foreground ml-1">{unit}</span>}
      </div>
      {subtitle && <p className="text-2xs text-muted-foreground">{subtitle}</p>}
      {delta !== null && delta !== undefined && (
        <p className={cn('text-2xs', delta >= 0 ? 'text-status-healthy' : 'text-status-critical')}>
          {delta >= 0 ? '+' : ''}{delta.toFixed(1)}% vs prev
        </p>
      )}
    </div>
  );
}
