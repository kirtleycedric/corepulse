'use client';
import { useRef, useEffect, useMemo } from 'react';
import * as echarts from 'echarts/core';
import {
  LineChart,
  BarChart,
  GaugeChart,
} from 'echarts/charts';
import {
  GridComponent,
  TooltipComponent,
  LegendComponent,
  DataZoomComponent,
  MarkLineComponent,
  VisualMapComponent,
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';
import type { MetricPoint, MetricSeries } from '@/types';
import { formatBytes, formatPercent, formatBps } from '@/lib/utils';

echarts.use([
  LineChart, BarChart, GaugeChart,
  GridComponent, TooltipComponent, LegendComponent,
  DataZoomComponent, MarkLineComponent, VisualMapComponent,
  CanvasRenderer,
]);

interface TimeseriesChartProps {
  series: MetricSeries[];
  title?: string;
  unit?: string;
  height?: number | string;
  showLegend?: boolean;
  showDataZoom?: boolean;
  thresholdLine?: number;
  loading?: boolean;
}

function formatValue(value: number, unit: string): string {
  if (unit === 'bytes') return formatBytes(value);
  if (unit === 'percent') return formatPercent(value);
  if (unit === 'bps') return formatBps(value);
  if (unit === 'ms') return `${value.toFixed(2)}ms`;
  if (unit === 'µs' || unit === 'us') return value < 1000 ? `${value.toFixed(0)}µs` : `${(value/1000).toFixed(2)}ms`;
  if (unit === 'iops') return value >= 1000 ? `${(value/1000).toFixed(1)}K` : value.toFixed(0);
  return value.toFixed(2);
}

const COLORS = [
  '#3b82f6', '#22c55e', '#f59e0b', '#ef4444',
  '#8b5cf6', '#06b6d4', '#ec4899', '#14b8a6',
];

export function TimeseriesChart({
  series,
  title,
  unit = '',
  height = 200,
  showLegend = false,
  showDataZoom = false,
  thresholdLine,
  loading = false,
}: TimeseriesChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<echarts.ECharts | null>(null);

  const option = useMemo<echarts.EChartsOption>(() => {
    const echartsData = series.map((s, i) => {
      const seriesLabel = s.metric.split('.').slice(-2).join('.') || s.metric;
      return {
        name: seriesLabel,
        type: 'line' as const,
        smooth: true,
        symbol: 'none',
        lineStyle: { width: 1.5, color: COLORS[i % COLORS.length] },
        areaStyle: series.length === 1 ? {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: `${COLORS[0]}30` },
            { offset: 1, color: `${COLORS[0]}05` },
          ]),
        } : undefined,
        color: COLORS[i % COLORS.length],
        data: s.data.map(p => [new Date(p.timestamp).getTime(), p.value]),
        markLine: thresholdLine !== undefined && i === 0 ? {
          silent: true,
          symbol: 'none',
          data: [{ yAxis: thresholdLine, label: { formatter: `${thresholdLine}`, position: 'end' } }],
          lineStyle: { color: '#ef4444', type: 'dashed', width: 1 },
        } : undefined,
      };
    });

    return {
      backgroundColor: 'transparent',
      animation: false,
      grid: {
        top: title ? 28 : 8,
        right: 8,
        bottom: showDataZoom ? 40 : 24,
        left: 48,
        containLabel: false,
      },
      title: title ? {
        text: title,
        textStyle: { color: '#9ca3af', fontSize: 11, fontWeight: 'normal' },
        top: 4, left: 4,
      } : undefined,
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'hsl(222, 47%, 11%)',
        borderColor: 'hsl(222, 47%, 18%)',
        textStyle: { color: '#e2e8f0', fontSize: 11 },
        axisPointer: { type: 'cross', crossStyle: { color: '#4b5563' } },
        formatter: (params: any[]) => {
          if (!params?.length) return '';
          const time = new Date(params[0].axisValue).toLocaleTimeString();
          const lines = params.map(p =>
            `<div style="display:flex;gap:8px;justify-content:space-between">
              <span style="color:${p.color}">${p.seriesName}</span>
              <strong>${formatValue(p.value[1], unit)}</strong>
            </div>`
          );
          return `<div style="min-width:120px"><div style="color:#6b7280;margin-bottom:4px">${time}</div>${lines.join('')}</div>`;
        },
      },
      legend: showLegend ? {
        show: true,
        bottom: showDataZoom ? 36 : 4,
        textStyle: { color: '#9ca3af', fontSize: 10 },
        icon: 'circle',
        itemWidth: 8,
        itemHeight: 8,
      } : { show: false },
      xAxis: {
        type: 'time',
        axisLine: { lineStyle: { color: '#374151' } },
        axisLabel: {
          color: '#6b7280', fontSize: 10,
          formatter: (val: number) => {
            const d = new Date(val);
            return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          },
        },
        splitLine: { show: false },
      },
      yAxis: {
        type: 'value',
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: {
          color: '#6b7280', fontSize: 10,
          formatter: (val: number) => formatValue(val, unit),
        },
        splitLine: { lineStyle: { color: '#1f2937', type: 'dashed' } },
      },
      dataZoom: showDataZoom ? [
        { type: 'inside', start: 0, end: 100 },
        { type: 'slider', height: 20, bottom: 4, handleStyle: { color: '#374151' }, textStyle: { color: '#6b7280' } },
      ] : [],
      series: echartsData,
    };
  }, [series, title, unit, showLegend, showDataZoom, thresholdLine]);

  useEffect(() => {
    if (!containerRef.current) return;
    if (!chartRef.current) {
      chartRef.current = echarts.init(containerRef.current, 'dark', { renderer: 'canvas' });
    }
    chartRef.current.setOption(option, { notMerge: true });
  }, [option]);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    chart.showLoading({ text: '', color: '#3b82f6', textColor: '#9ca3af', maskColor: 'transparent' });
    if (!loading) chart.hideLoading();
  }, [loading]);

  useEffect(() => {
    const obs = new ResizeObserver(() => chartRef.current?.resize());
    if (containerRef.current) obs.observe(containerRef.current);
    return () => {
      obs.disconnect();
      chartRef.current?.dispose();
      chartRef.current = null;
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{ width: '100%', height: typeof height === 'number' ? `${height}px` : height }}
    />
  );
}
