'use client';
import { useRef, useEffect, useMemo } from 'react';
import * as echarts from 'echarts/core';
import { GaugeChart } from 'echarts/charts';
import { CanvasRenderer } from 'echarts/renderers';
import { cn } from '@/lib/utils';

echarts.use([GaugeChart, CanvasRenderer]);

interface GaugeWidgetProps {
  value: number;
  min?: number;
  max?: number;
  unit?: string;
  label?: string;
  size?: number;
  thresholds?: { value: number; color: string }[];
}

const DEFAULT_THRESHOLDS = [
  { value: 70, color: '#22c55e' },
  { value: 85, color: '#f59e0b' },
  { value: 100, color: '#ef4444' },
];

export function GaugeWidget({
  value,
  min = 0,
  max = 100,
  unit = '%',
  label = '',
  size = 160,
  thresholds = DEFAULT_THRESHOLDS,
}: GaugeWidgetProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<echarts.ECharts | null>(null);

  const option = useMemo<echarts.EChartsOption>(() => {
    const pct = ((value - min) / (max - min)) * 100;
    const color = pct <= 70 ? '#22c55e' : pct <= 85 ? '#f59e0b' : '#ef4444';

    return {
      backgroundColor: 'transparent',
      animation: true,
      animationDuration: 500,
      series: [{
        type: 'gauge',
        startAngle: 200,
        endAngle: -20,
        min, max,
        radius: '90%',
        center: ['50%', '55%'],
        pointer: { show: false },
        progress: {
          show: true,
          width: 12,
          itemStyle: { color },
        },
        axisLine: {
          lineStyle: { width: 12, color: [[1, '#1f2937']] },
        },
        axisTick: { show: false },
        splitLine: { show: false },
        axisLabel: { show: false },
        title: {
          show: !!label,
          offsetCenter: [0, '70%'],
          fontSize: 10,
          color: '#6b7280',
        },
        detail: {
          valueAnimation: true,
          offsetCenter: [0, '0%'],
          fontSize: size < 140 ? 16 : 22,
          fontWeight: 'bold',
          color: '#e2e8f0',
          formatter: (val: number) => `${val.toFixed(1)}${unit}`,
        },
        data: [{ value, name: label }],
      }],
    };
  }, [value, min, max, unit, label, size]);

  useEffect(() => {
    if (!containerRef.current) return;
    if (!chartRef.current) {
      chartRef.current = echarts.init(containerRef.current, 'dark', { renderer: 'canvas' });
    }
    chartRef.current.setOption(option, { notMerge: false });
  }, [option]);

  useEffect(() => {
    return () => {
      chartRef.current?.dispose();
      chartRef.current = null;
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{ width: `${size}px`, height: `${size}px` }}
      className="mx-auto"
    />
  );
}
