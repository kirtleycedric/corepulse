'use client';
import { AlertIncident } from '@/types';
import { cn, severityColor, truncate } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { AlertTriangle, CheckCircle, Info } from 'lucide-react';

interface AlertFeedProps {
  incidents: AlertIncident[];
  maxItems?: number;
  compact?: boolean;
}

const SeverityIcon = ({ severity }: { severity: string }) => {
  if (severity === 'critical') return <AlertTriangle size={12} className="text-status-critical shrink-0" />;
  if (severity === 'warning') return <AlertTriangle size={12} className="text-status-warning shrink-0" />;
  return <Info size={12} className="text-status-info shrink-0" />;
};

export function AlertFeed({ incidents, maxItems = 20, compact = false }: AlertFeedProps) {
  const items = incidents.slice(0, maxItems);

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-muted-foreground gap-2">
        <CheckCircle size={24} className="text-status-healthy opacity-50" />
        <span className="text-xs">No active alerts</span>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      {items.map(incident => (
        <div
          key={incident.id}
          className={cn(
            'flex items-start gap-2 p-2 rounded border transition-colors',
            incident.status === 'firing'
              ? 'bg-card border-border'
              : 'bg-muted/40 border-transparent opacity-60',
            !compact && 'hover:bg-accent cursor-pointer'
          )}
        >
          <SeverityIcon severity={incident.severity} />
          <div className="flex-1 min-w-0">
            <p className="text-xs leading-snug truncate">{incident.message}</p>
            <div className="flex items-center gap-2 mt-0.5">
              <span className={cn('text-2xs font-medium', severityColor(incident.severity))}>
                {incident.severity}
              </span>
              <span className="text-2xs text-muted-foreground">
                {formatDistanceToNow(new Date(incident.triggered_at), { addSuffix: true })}
              </span>
              {incident.acknowledged && (
                <span className="text-2xs text-status-healthy">acked</span>
              )}
            </div>
          </div>
          {incident.status === 'firing' && !incident.acknowledged && (
            <span className="w-1.5 h-1.5 rounded-full bg-status-critical shrink-0 mt-1 animate-pulse" />
          )}
        </div>
      ))}
    </div>
  );
}
