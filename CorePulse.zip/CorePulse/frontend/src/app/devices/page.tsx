'use client';
import { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { useDevices, usePollDevice, useDeleteDevice } from '@/lib/hooks/queries';
import { Device } from '@/types';
import { cn, statusDotClass, formatBytes, statusColor } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { Plus, RefreshCw, Trash2, Zap } from 'lucide-react';
import { toast } from 'sonner';

const TYPE_BADGE: Record<string, string> = {
  proxmox_cluster: 'bg-purple-500/20 text-purple-300',
  juniper_switch: 'bg-emerald-500/20 text-emerald-300',
  cisco_sg300: 'bg-blue-500/20 text-blue-300',
  cisco_catalyst: 'bg-blue-500/20 text-blue-300',
  flashsystem: 'bg-orange-500/20 text-orange-300',
  generic_snmp: 'bg-muted text-muted-foreground',
};

export default function DevicesPage() {
  const [filter, setFilter] = useState<string>('');
  const { data, isLoading, refetch } = useDevices({ page_size: 200 });
  const pollDevice = usePollDevice();
  const deleteDevice = useDeleteDevice();

  const devices = (data?.items ?? []).filter(d =>
    !filter || d.name.toLowerCase().includes(filter.toLowerCase()) ||
    d.host.toLowerCase().includes(filter.toLowerCase()) ||
    d.device_type.includes(filter.toLowerCase())
  );

  const handlePoll = async (id: string, name: string) => {
    try {
      await pollDevice.mutateAsync(id);
      toast.success(`Poll queued for ${name}`);
    } catch {
      toast.error('Failed to queue poll');
    }
  };

  return (
    <AppShell>
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-semibold">Devices</h1>
            <p className="text-xs text-muted-foreground">{data?.total ?? 0} total</p>
          </div>
          <div className="flex items-center gap-2">
            <input
              value={filter}
              onChange={e => setFilter(e.target.value)}
              placeholder="Filter devices..."
              className="h-7 px-2.5 rounded border border-input bg-background text-xs outline-none focus:ring-1 focus:ring-ring w-44"
            />
            <button
              onClick={() => refetch()}
              className="h-7 px-2.5 rounded border border-border text-xs flex items-center gap-1.5 hover:bg-accent"
            >
              <RefreshCw size={12} />
              Refresh
            </button>
            <button className="h-7 px-2.5 rounded bg-primary text-primary-foreground text-xs flex items-center gap-1.5 hover:bg-primary/90">
              <Plus size={12} />
              Add Device
            </button>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-3 py-2 font-medium text-muted-foreground w-4"></th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Name</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Host</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Type</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Site</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Last Seen</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Status</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-muted-foreground">Loading...</td>
                </tr>
              )}
              {devices.map(device => (
                <tr key={device.id} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
                  <td className="px-3 py-2">
                    <span className={cn('status-dot', statusDotClass(device.last_poll_status))} />
                  </td>
                  <td className="px-3 py-2 font-medium">{device.display_name || device.name}</td>
                  <td className="px-3 py-2 text-muted-foreground font-mono">{device.host}</td>
                  <td className="px-3 py-2">
                    <span className={cn('px-1.5 py-0.5 rounded text-2xs font-medium', TYPE_BADGE[device.device_type] || 'bg-muted text-muted-foreground')}>
                      {device.device_type.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">{device.site || '—'}</td>
                  <td className="px-3 py-2 text-muted-foreground">
                    {device.last_seen_at
                      ? formatDistanceToNow(new Date(device.last_seen_at), { addSuffix: true })
                      : '—'}
                  </td>
                  <td className={cn('px-3 py-2 font-medium', statusColor(device.last_poll_status))}>
                    {device.last_poll_status ?? 'unknown'}
                    {device.consecutive_failures > 0 && (
                      <span className="ml-1 text-status-warning">({device.consecutive_failures})</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-1 justify-end">
                      <button
                        onClick={() => handlePoll(device.id, device.name)}
                        className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-foreground"
                        title="Poll now"
                      >
                        <Zap size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {!isLoading && devices.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-muted-foreground">
                    {filter ? 'No matching devices' : 'No devices configured'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
