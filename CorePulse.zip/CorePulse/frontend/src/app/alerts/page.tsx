'use client';
import { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { useIncidents, useAlertRules, useAcknowledgeIncident } from '@/lib/hooks/queries';
import { AlertIncident, AlertRule } from '@/types';
import { cn, severityColor, truncate } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { CheckSquare, ListFilter } from 'lucide-react';
import { toast } from 'sonner';

type Tab = 'incidents' | 'rules';

function SeverityBadge({ severity }: { severity: string }) {
  return (
    <span className={cn(
      'px-1.5 py-0.5 rounded text-2xs font-semibold uppercase',
      severity === 'critical' ? 'bg-red-500/20 text-red-400' :
      severity === 'warning' ? 'bg-amber-500/20 text-amber-400' :
      'bg-blue-500/20 text-blue-400'
    )}>
      {severity}
    </span>
  );
}

export default function AlertsPage() {
  const [tab, setTab] = useState<Tab>('incidents');
  const [statusFilter, setStatusFilter] = useState('firing');
  const { data: incidents, refetch } = useIncidents({ status: statusFilter || undefined, page_size: 100 });
  const { data: rules } = useAlertRules({ page_size: 100 });
  const ackMutation = useAcknowledgeIncident();

  const handleAck = async (id: string) => {
    try {
      await ackMutation.mutateAsync({ id });
      toast.success('Incident acknowledged');
      refetch();
    } catch {
      toast.error('Failed to acknowledge');
    }
  };

  return (
    <AppShell>
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h1 className="text-base font-semibold">Alerts</h1>
          <div className="flex gap-1 rounded border border-border overflow-hidden text-xs">
            {(['incidents', 'rules'] as Tab[]).map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn('px-3 py-1 capitalize', tab === t ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent')}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {tab === 'incidents' && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <ListFilter size={13} className="text-muted-foreground" />
              {['firing', 'resolved', ''].map(s => (
                <button
                  key={s || 'all'}
                  onClick={() => setStatusFilter(s)}
                  className={cn('px-2 py-0.5 rounded text-xs', statusFilter === s ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground border border-border')}
                >
                  {s || 'All'}
                </button>
              ))}
              <span className="ml-auto text-xs text-muted-foreground">{incidents?.total ?? 0} incidents</span>
            </div>

            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground">Severity</th>
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground">Message</th>
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground">Metric</th>
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground">Value</th>
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground">Status</th>
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground">Triggered</th>
                    <th className="px-3 py-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {(incidents?.items ?? []).map(incident => (
                    <tr key={incident.id} className="border-b border-border/50 hover:bg-accent/30">
                      <td className="px-3 py-2"><SeverityBadge severity={incident.severity} /></td>
                      <td className="px-3 py-2 max-w-xs">
                        <p className="truncate" title={incident.message}>{incident.message}</p>
                      </td>
                      <td className="px-3 py-2 font-mono text-muted-foreground">{incident.metric}</td>
                      <td className="px-3 py-2 tabular-nums">{incident.trigger_value.toFixed(2)}</td>
                      <td className="px-3 py-2">
                        <span className={cn('px-1.5 py-0.5 rounded text-2xs', incident.status === 'firing' ? 'bg-red-500/20 text-red-400' : 'bg-muted text-muted-foreground')}>
                          {incident.status}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">
                        {formatDistanceToNow(new Date(incident.triggered_at), { addSuffix: true })}
                      </td>
                      <td className="px-3 py-2">
                        {!incident.acknowledged && incident.status === 'firing' && (
                          <button
                            onClick={() => handleAck(incident.id)}
                            className="p-1 rounded hover:bg-accent text-muted-foreground hover:text-foreground"
                            title="Acknowledge"
                          >
                            <CheckSquare size={12} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {(incidents?.items ?? []).length === 0 && (
                    <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">No incidents</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'rules' && (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Name</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Metric</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Condition</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Severity</th>
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {(rules?.items ?? []).map(rule => (
                  <tr key={rule.id} className="border-b border-border/50 hover:bg-accent/30">
                    <td className="px-3 py-2 font-medium">{rule.name}</td>
                    <td className="px-3 py-2 font-mono text-muted-foreground">{rule.metric}</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      {rule.condition_config.operator} {String(rule.condition_config.threshold)}
                    </td>
                    <td className="px-3 py-2"><SeverityBadge severity={rule.severity} /></td>
                    <td className="px-3 py-2">
                      <span className={cn('text-2xs', rule.enabled ? 'text-status-healthy' : 'text-muted-foreground')}>
                        {rule.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </td>
                  </tr>
                ))}
                {(rules?.items ?? []).length === 0 && (
                  <tr><td colSpan={5} className="text-center py-8 text-muted-foreground">No alert rules</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
