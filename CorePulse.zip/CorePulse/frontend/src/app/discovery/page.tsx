'use client';
import { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { discoveryApi } from '@/lib/api/client';
import { Loader2, Search } from 'lucide-react';
import { toast } from 'sonner';

interface DiscoveredDevice {
  host: string;
  sys_name: string;
  sys_descr: string;
  vendor: string;
  device_type: string;
  sys_object_id: string;
}

export default function DiscoveryPage() {
  const [subnet, setSubnet] = useState('192.168.1.0/24');
  const [community, setCommunity] = useState('public');
  const [scanning, setScanning] = useState(false);
  const [taskId, setTaskId] = useState<string | null>(null);
  const [results, setResults] = useState<DiscoveredDevice[]>([]);

  const handleScan = async () => {
    if (!subnet) return;
    setScanning(true);
    setResults([]);
    try {
      const res = await discoveryApi.scan(subnet, community);
      setTaskId(res.task_id);
      toast.info(`Discovery scan queued for ${subnet}`);
      // Poll for results
      const interval = setInterval(async () => {
        try {
          const result = await discoveryApi.result(res.task_id);
          if (result.status === 'complete' && result.result) {
            const r = result.result as { discovered: DiscoveredDevice[] };
            setResults(r.discovered ?? []);
            setScanning(false);
            clearInterval(interval);
            toast.success(`Found ${r.discovered?.length ?? 0} devices`);
          } else if (result.status === 'failure') {
            setScanning(false);
            clearInterval(interval);
            toast.error('Discovery scan failed');
          }
        } catch { clearInterval(interval); setScanning(false); }
      }, 3000);
    } catch (err: any) {
      toast.error(err?.response?.data?.error?.message || 'Scan failed');
      setScanning(false);
    }
  };

  return (
    <AppShell>
      <div className="p-4 space-y-4 max-w-3xl">
        <h1 className="text-base font-semibold">Device Discovery</h1>
        <div className="bg-card border border-border rounded-lg p-4 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">SNMP Discovery Scan</h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium">Subnet (CIDR)</label>
              <input value={subnet} onChange={e => setSubnet(e.target.value)}
                className="w-full h-8 px-2.5 rounded border border-input bg-background text-xs outline-none focus:ring-1 focus:ring-ring"
                placeholder="192.168.1.0/24" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium">SNMP Community</label>
              <input value={community} onChange={e => setCommunity(e.target.value)}
                className="w-full h-8 px-2.5 rounded border border-input bg-background text-xs outline-none focus:ring-1 focus:ring-ring"
                placeholder="public" />
            </div>
          </div>
          <button onClick={handleScan} disabled={scanning}
            className="h-8 px-4 rounded bg-primary text-primary-foreground text-xs flex items-center gap-2 hover:bg-primary/90 disabled:opacity-50">
            {scanning ? <Loader2 size={12} className="animate-spin" /> : <Search size={12} />}
            {scanning ? 'Scanning...' : 'Start Scan'}
          </button>
          <p className="text-2xs text-muted-foreground">Scans up to /24 (254 hosts). Results appear after scan completes.</p>
        </div>

        {results.length > 0 && (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-3 py-2 border-b border-border text-xs font-semibold">
              Discovered: {results.length} devices
            </div>
            <table className="w-full text-xs">
              <thead><tr className="border-b border-border bg-muted/40">
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Host</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Name</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Vendor</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Type</th>
                <th className="text-left px-3 py-2 font-medium text-muted-foreground">Description</th>
              </tr></thead>
              <tbody>
                {results.map((d, i) => (
                  <tr key={i} className="border-b border-border/50 hover:bg-accent/30">
                    <td className="px-3 py-1.5 font-mono">{d.host}</td>
                    <td className="px-3 py-1.5">{d.sys_name || '—'}</td>
                    <td className="px-3 py-1.5 capitalize">{d.vendor}</td>
                    <td className="px-3 py-1.5 text-muted-foreground">{d.device_type}</td>
                    <td className="px-3 py-1.5 text-muted-foreground truncate max-w-48">{d.sys_descr || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
