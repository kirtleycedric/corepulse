'use client';
import { useDevices, useIncidents, useHealth } from '@/lib/hooks/queries';
import { useAlertStore, useUIStore } from '@/lib/store';
import { AppShell } from '@/components/layout/AppShell';
import { StatCard } from '@/components/widgets/StatCard';
import { AlertFeed } from '@/components/alerts/AlertFeed';
import { DeviceStatusGrid } from '@/components/devices/DeviceStatusGrid';
import { Activity, AlertTriangle, CheckCircle, Server } from 'lucide-react';

export default function DashboardPage() {
  const { data: devices } = useDevices({ page_size: 200 });
  const { data: incidents } = useIncidents({ status: 'firing', page_size: 20 });
  const { data: health } = useHealth();
  const unackCount = useAlertStore(s => s.unacknowledgedCount);
  const { timeRange } = useUIStore();

  const totalDevices = devices?.total ?? 0;
  const healthyDevices = devices?.items.filter(d => d.last_poll_status === 'success').length ?? 0;
  const firingCount = incidents?.items.filter(i => i.status === 'firing').length ?? 0;
  const criticalCount = incidents?.items.filter(i => i.severity === 'critical' && i.status === 'firing').length ?? 0;

  return (
    <AppShell>
      <div className="p-4 space-y-4">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-semibold">Overview</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {totalDevices} devices monitored · Last {timeRange}
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className={health?.status === 'healthy' ? 'text-status-healthy' : 'text-status-warning'}>
              Platform {health?.status ?? 'checking...'}
            </span>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard
            title="Total Devices"
            value={totalDevices}
            icon={<Server size={14} />}
            delta={null}
          />
          <StatCard
            title="Healthy"
            value={healthyDevices}
            icon={<CheckCircle size={14} />}
            valueClass="text-status-healthy"
            delta={null}
          />
          <StatCard
            title="Active Alerts"
            value={firingCount}
            icon={<AlertTriangle size={14} />}
            valueClass={firingCount > 0 ? 'text-status-warning' : undefined}
            delta={null}
          />
          <StatCard
            title="Critical"
            value={criticalCount}
            icon={<Activity size={14} />}
            valueClass={criticalCount > 0 ? 'text-status-critical' : undefined}
            delta={null}
          />
        </div>

        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          {/* Device status grid */}
          <div className="lg:col-span-2">
            <div className="bg-card border border-border rounded-lg p-3">
              <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                Device Status
              </h2>
              <DeviceStatusGrid devices={devices?.items ?? []} />
            </div>
          </div>

          {/* Alert feed */}
          <div>
            <div className="bg-card border border-border rounded-lg p-3">
              <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                Recent Alerts
              </h2>
              <AlertFeed incidents={incidents?.items ?? []} maxItems={10} />
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
