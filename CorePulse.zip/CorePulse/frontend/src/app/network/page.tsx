'use client';
import { AppShell } from '@/components/layout/AppShell';
import { useDevices, useDeviceInterfaces, useMetrics } from '@/lib/hooks/queries';
import { useUIStore } from '@/lib/store';
import { TIME_RANGES } from '@/types';
import { TimeseriesChart } from '@/components/charts/TimeseriesChart';
import { cn, statusDotClass, formatBps } from '@/lib/utils';
import { useState } from 'react';

export default function NetworkPage() {
  const { timeRange } = useUIStore();
  const range = TIME_RANGES.find(r => r.value === timeRange) ?? TIME_RANGES[1];
  const { data: switchesData } = useDevices({ device_type: 'juniper_switch', page_size: 50 });
  const { data: sg300Data } = useDevices({ device_type: 'cisco_sg300', page_size: 50 });
  const { data: catData } = useDevices({ device_type: 'cisco_catalyst', page_size: 50 });
  const allSwitches = [...(switchesData?.items ?? []), ...(sg300Data?.items ?? []), ...(catData?.items ?? [])];
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { data: interfaces } = useDeviceInterfaces(selectedId ?? '');
  const { data: bwSeries } = useMetrics({ device_id: selectedId ?? undefined, metric_prefix: 'if.', timeRangeSeconds: range.seconds, enabled: !!selectedId });

  return (
    <AppShell>
      <div className="p-4 space-y-4">
        <h1 className="text-base font-semibold">Network</h1>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-3">
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-3 py-2 border-b border-border text-xs font-semibold">Switches ({allSwitches.length})</div>
            <div className="divide-y divide-border">
              {allSwitches.map(sw => (
                <button key={sw.id} onClick={() => setSelectedId(sw.id === selectedId ? null : sw.id)}
                  className={cn('w-full text-left px-3 py-2 flex items-center gap-2 hover:bg-accent text-xs', sw.id === selectedId && 'bg-accent')}>
                  <span className={cn('status-dot', statusDotClass(sw.last_poll_status))} />
                  <span className="flex-1 truncate">{sw.display_name || sw.name}</span>
                  <span className="text-muted-foreground text-2xs">{sw.device_type.replace('_', ' ')}</span>
                </button>
              ))}
              {allSwitches.length === 0 && <p className="px-3 py-4 text-xs text-muted-foreground">No switches</p>}
            </div>
          </div>
          <div className="lg:col-span-3 space-y-3">
            {selectedId && (
              <>
                <div className="bg-card border border-border rounded-lg p-3">
                  <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Bandwidth</h2>
                  <TimeseriesChart series={(bwSeries ?? []).filter(s => s.metric.includes('octets'))} unit="bytes" height={160} showLegend />
                </div>
                <div className="bg-card border border-border rounded-lg overflow-hidden">
                  <div className="px-3 py-2 border-b border-border text-xs font-semibold">Interfaces ({interfaces?.length ?? 0})</div>
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-border bg-muted/40">
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Port</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Alias</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Speed</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Admin</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Oper</th>
                      <th className="text-left px-3 py-2 font-medium text-muted-foreground">Neighbor</th>
                    </tr></thead>
                    <tbody>
                      {(interfaces ?? []).map(iface => (
                        <tr key={iface.id} className="border-b border-border/50 hover:bg-accent/30">
                          <td className="px-3 py-1.5 font-mono">{iface.if_name}</td>
                          <td className="px-3 py-1.5 text-muted-foreground truncate max-w-32">{iface.if_alias || '—'}</td>
                          <td className="px-3 py-1.5">{iface.if_speed_bps > 0 ? formatBps(iface.if_speed_bps) : '—'}</td>
                          <td className="px-3 py-1.5"><span className={cn(iface.if_admin_status === 1 ? 'text-status-healthy' : 'text-status-unknown')}>{iface.if_admin_status === 1 ? 'Up' : 'Down'}</span></td>
                          <td className="px-3 py-1.5"><span className={cn(iface.if_oper_status === 1 ? 'text-status-healthy' : 'text-muted-foreground')}>{iface.if_oper_status === 1 ? 'Up' : 'Down'}</span></td>
                          <td className="px-3 py-1.5 text-muted-foreground text-2xs truncate max-w-32">{iface.lldp_neighbor || iface.cdp_neighbor || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
            {!selectedId && <div className="flex items-center justify-center h-32 text-xs text-muted-foreground">Select a switch to view interfaces</div>}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
