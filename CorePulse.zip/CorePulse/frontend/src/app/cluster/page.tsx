'use client';
import { AppShell } from '@/components/layout/AppShell';
import { useDevices, useMetrics } from '@/lib/hooks/queries';
import { useUIStore } from '@/lib/store';
import { TIME_RANGES } from '@/types';
import { StatCard } from '@/components/widgets/StatCard';
import { TimeseriesChart } from '@/components/charts/TimeseriesChart';
import { cn, statusDotClass } from '@/lib/utils';
import { Server } from 'lucide-react';

export default function ClusterPage() {
  const { timeRange } = useUIStore();
  const range = TIME_RANGES.find(r => r.value === timeRange) ?? TIME_RANGES[1];
  const { data: nodesData } = useDevices({ device_type: 'proxmox_node', page_size: 20 });
  const { data: vmsData } = useDevices({ device_type: 'vm', page_size: 200 });
  const { data: cpuSeries } = useMetrics({ metric_prefix: 'node.cpu', timeRangeSeconds: range.seconds });
  const nodes = nodesData?.items ?? [];
  const vms = vmsData?.items ?? [];

  return (
    <AppShell>
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-base font-semibold">Cluster</h1>
          <span className="text-xs text-muted-foreground">{nodes.length} nodes · {vms.length} VMs</span>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard title="Nodes" value={nodes.length} icon={<Server size={14} />} delta={null} />
          <StatCard title="VMs" value={vms.length} delta={null} />
          <StatCard title="Healthy" value={nodes.filter(n => n.last_poll_status === 'success').length} delta={null} valueClass="text-status-healthy" />
          <StatCard title="Failed" value={nodes.filter(n => n.last_poll_status === 'error').length} delta={null} valueClass="text-status-critical" />
        </div>
        <div className="bg-card border border-border rounded-lg p-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Node CPU</h2>
          <TimeseriesChart series={cpuSeries ?? []} unit="percent" height={180} showLegend thresholdLine={85} />
        </div>
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="px-3 py-2 border-b border-border"><h2 className="text-xs font-semibold">Nodes</h2></div>
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border bg-muted/40">
              <th className="text-left px-3 py-2 font-medium text-muted-foreground w-4"></th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Node</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Host</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Status</th>
            </tr></thead>
            <tbody>
              {nodes.map(node => (
                <tr key={node.id} className="border-b border-border/50 hover:bg-accent/30">
                  <td className="px-3 py-2"><span className={cn('status-dot', statusDotClass(node.last_poll_status))} /></td>
                  <td className="px-3 py-2 font-medium">{node.sys_name || node.name}</td>
                  <td className="px-3 py-2 font-mono text-muted-foreground">{node.host}</td>
                  <td className="px-3 py-2">{node.last_poll_status ?? '—'}</td>
                </tr>
              ))}
              {nodes.length === 0 && <tr><td colSpan={4} className="text-center py-6 text-muted-foreground">No Proxmox nodes configured</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
