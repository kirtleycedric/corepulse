'use client';
import { AppShell } from '@/components/layout/AppShell';
import { useUIStore, useAuthStore } from '@/lib/store';
import { Moon, Sun, Monitor, Bell, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function SettingsPage() {
  const { theme, setTheme } = useUIStore();
  const { username, role } = useAuthStore();

  return (
    <AppShell>
      <div className="p-4 space-y-4 max-w-2xl">
        <h1 className="text-base font-semibold">Settings</h1>

        {/* Account */}
        <section className="bg-card border border-border rounded-lg p-4 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Account</h2>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div><p className="text-muted-foreground">Username</p><p className="font-medium mt-0.5">{username}</p></div>
            <div><p className="text-muted-foreground">Role</p><p className="font-medium mt-0.5 capitalize">{role}</p></div>
          </div>
        </section>

        {/* Appearance */}
        <section className="bg-card border border-border rounded-lg p-4 space-y-3">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Appearance</h2>
          <div className="flex gap-2">
            {(['light', 'dark', 'system'] as const).map(t => (
              <button key={t} onClick={() => setTheme(t)}
                className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded border text-xs capitalize transition-colors',
                  theme === t ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:bg-accent')}>
                {t === 'light' && <Sun size={12} />}
                {t === 'dark' && <Moon size={12} />}
                {t === 'system' && <Monitor size={12} />}
                {t}
              </button>
            ))}
          </div>
        </section>

        {/* Platform info */}
        <section className="bg-card border border-border rounded-lg p-4 space-y-2 text-xs">
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Platform</h2>
          <div className="grid grid-cols-2 gap-2 text-muted-foreground">
            <span>Version</span><span className="text-foreground">1.0.0</span>
            <span>Default Credentials</span><span className="text-foreground font-mono">admin / corepulse</span>
          </div>
          <p className="text-2xs text-status-warning mt-2">⚠ Change the default admin password immediately in production.</p>
        </section>
      </div>
    </AppShell>
  );
}
