'use client';
import { useState, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { Responsive, WidthProvider, Layout } from 'react-grid-layout';
import type { Layouts } from 'react-grid-layout';
import { AppShell } from '@/components/layout/AppShell';
import { useDashboard, useUpdateDashboard } from '@/lib/hooks/queries';
import { useDashEditStore } from '@/lib/store';
import { WidgetCard } from '@/components/dashboard/WidgetCard';
import { WidgetRenderer } from '@/components/dashboard/WidgetRenderer';
import { AddWidgetModal } from '@/components/dashboard/AddWidgetModal';
import { WidgetConfig } from '@/types';
import { cn } from '@/lib/utils';
import { Edit2, Plus, Save, X } from 'lucide-react';
import { toast } from 'sonner';

const ResponsiveGrid = WidthProvider(Responsive);

export default function DashboardViewPage() {
  const params = useParams<{ id: string }>();
  const { data: dashboard, isLoading, refetch } = useDashboard(params.id);
  const updateMutation = useUpdateDashboard();
  const { editing, widgets, dirty, startEditing, stopEditing, updateWidgets, removeWidget } = useDashEditStore();
  const [showAddModal, setShowAddModal] = useState(false);

  const handleStartEdit = () => {
    if (!dashboard) return;
    startEditing(dashboard.id, dashboard.layout?.widgets ?? []);
  };

  const handleSave = async () => {
    if (!dashboard) return;
    try {
      await updateMutation.mutateAsync({
        id: dashboard.id,
        data: { widgets } as any,
      });
      stopEditing();
      refetch();
      toast.success('Dashboard saved');
    } catch {
      toast.error('Failed to save dashboard');
    }
  };

  const handleLayoutChange = useCallback(
    (_layout: Layout[], allLayouts: Layouts) => {
      if (!editing) return;
      const currentLayout = allLayouts['lg'] || allLayouts['md'] || _layout;
      const updatedWidgets = widgets.map(w => {
        const layoutItem = currentLayout.find(l => l.i === w.id);
        if (!layoutItem) return w;
        return { ...w, x: layoutItem.x, y: layoutItem.y, w: layoutItem.w, h: layoutItem.h };
      });
      updateWidgets(updatedWidgets);
    },
    [editing, widgets, updateWidgets]
  );

  if (isLoading) {
    return (
      <AppShell>
        <div className="flex items-center justify-center h-64 text-muted-foreground text-sm">
          Loading dashboard...
        </div>
      </AppShell>
    );
  }

  if (!dashboard) {
    return (
      <AppShell>
        <div className="flex items-center justify-center h-64 text-muted-foreground text-sm">
          Dashboard not found
        </div>
      </AppShell>
    );
  }

  const displayWidgets: WidgetConfig[] = editing
    ? widgets
    : (dashboard.layout?.widgets ?? []);

  const gridLayout = displayWidgets.map(w => ({
    i: w.id,
    x: w.x,
    y: w.y,
    w: w.w,
    h: w.h,
    minW: 2,
    minH: 2,
  }));

  return (
    <AppShell>
      <div className="flex flex-col h-full overflow-hidden">
        {/* Dashboard toolbar */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-border bg-card shrink-0">
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-semibold truncate">{dashboard.name}</h1>
            {dashboard.description && (
              <p className="text-2xs text-muted-foreground">{dashboard.description}</p>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {editing ? (
              <>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="h-7 px-2 rounded border border-border text-xs flex items-center gap-1.5 hover:bg-accent"
                >
                  <Plus size={12} />
                  Add Widget
                </button>
                <button
                  onClick={handleSave}
                  disabled={!dirty || updateMutation.isPending}
                  className="h-7 px-2 rounded bg-primary text-primary-foreground text-xs flex items-center gap-1.5 hover:bg-primary/90 disabled:opacity-50"
                >
                  <Save size={12} />
                  {updateMutation.isPending ? 'Saving...' : 'Save'}
                </button>
                <button
                  onClick={stopEditing}
                  className="h-7 px-2 rounded border border-border text-xs flex items-center gap-1.5 hover:bg-accent text-muted-foreground"
                >
                  <X size={12} />
                  Cancel
                </button>
              </>
            ) : (
              <button
                onClick={handleStartEdit}
                className="h-7 px-2 rounded border border-border text-xs flex items-center gap-1.5 hover:bg-accent"
              >
                <Edit2 size={12} />
                Edit
              </button>
            )}
          </div>
        </div>

        {/* Grid area */}
        <div className={cn('flex-1 overflow-auto p-3', editing && 'dashboard-grid')}>
          {displayWidgets.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-muted-foreground gap-3">
              <p className="text-sm">This dashboard has no widgets yet</p>
              {!editing && (
                <button
                  onClick={handleStartEdit}
                  className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs hover:bg-primary/90"
                >
                  Add widgets
                </button>
              )}
            </div>
          ) : (
            <ResponsiveGrid
              className={cn('dashboard-grid', !editing && 'pointer-events-none')}
              layouts={{ lg: gridLayout, md: gridLayout, sm: gridLayout }}
              breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
              cols={{ lg: 12, md: 12, sm: 6, xs: 4, xxs: 2 }}
              rowHeight={60}
              isDraggable={editing}
              isResizable={editing}
              onLayoutChange={handleLayoutChange}
              margin={[8, 8]}
              containerPadding={[0, 0]}
            >
              {displayWidgets.map(widget => (
                <div key={widget.id}>
                  <WidgetCard
                    widget={widget}
                    editing={editing}
                    onRemove={editing ? () => removeWidget(widget.id) : undefined}
                  >
                    <WidgetRenderer
                      widget={widget}
                      timeRange={dashboard.time_range}
                      refreshInterval={dashboard.refresh_interval_seconds}
                    />
                  </WidgetCard>
                </div>
              ))}
            </ResponsiveGrid>
          )}
        </div>
      </div>

      {showAddModal && (
        <AddWidgetModal
          onClose={() => setShowAddModal(false)}
          onAdd={(widget) => {
            useDashEditStore.getState().addWidget(widget);
            setShowAddModal(false);
          }}
          currentWidgetCount={widgets.length}
        />
      )}
    </AppShell>
  );
}
