'use client';
import Link from 'next/link';
import { AppShell } from '@/components/layout/AppShell';
import { useDashboards, useCreateDashboard, useDeleteDashboard } from '@/lib/hooks/queries';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { Grid, Plus, Star, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function DashboardsPage() {
  const { data, refetch } = useDashboards();
  const createMutation = useCreateDashboard();
  const deleteMutation = useDeleteDashboard();

  const handleCreate = async () => {
    try {
      const d = await createMutation.mutateAsync({
        name: `Dashboard ${new Date().toLocaleString()}`,
        description: '',
        is_public: false,
        widgets: [],
        time_range: '1h',
        refresh_interval_seconds: 30,
      } as any);
      toast.success('Dashboard created');
      refetch();
    } catch {
      toast.error('Failed to create dashboard');
    }
  };

  const dashboards = data?.items ?? [];

  return (
    <AppShell>
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-semibold">Dashboards</h1>
            <p className="text-xs text-muted-foreground">{data?.total ?? 0} dashboards</p>
          </div>
          <button
            onClick={handleCreate}
            className="h-7 px-2.5 rounded bg-primary text-primary-foreground text-xs flex items-center gap-1.5 hover:bg-primary/90"
          >
            <Plus size={12} />
            New Dashboard
          </button>
        </div>

        {dashboards.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-3">
            <Grid size={32} className="opacity-30" />
            <p className="text-sm">No dashboards yet</p>
            <button
              onClick={handleCreate}
              className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-xs hover:bg-primary/90"
            >
              Create your first dashboard
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {dashboards.map(dash => (
              <Link
                key={dash.id}
                href={`/dashboards/${dash.id}`}
                className="group bg-card border border-border rounded-lg p-3 hover:border-primary transition-colors flex flex-col gap-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-sm font-medium leading-snug group-hover:text-primary transition-colors">
                    {dash.name}
                  </h3>
                  {dash.is_starred && <Star size={12} className="text-amber-400 shrink-0" fill="currentColor" />}
                </div>
                {dash.description && (
                  <p className="text-2xs text-muted-foreground">{dash.description}</p>
                )}
                <div className="flex items-center gap-2 text-2xs text-muted-foreground mt-auto">
                  <span>{(dash.layout?.widgets ?? []).length} widgets</span>
                  <span>·</span>
                  <span>{formatDistanceToNow(new Date(dash.updated_at), { addSuffix: true })}</span>
                  {dash.is_public && <span className="ml-auto text-status-info">Public</span>}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
