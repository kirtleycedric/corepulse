'use client';
import { AppShell } from '@/components/layout/AppShell';
import { useUsers } from '@/lib/hooks/queries';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

const ROLE_COLORS: Record<string, string> = {
  admin: 'bg-purple-500/20 text-purple-300',
  engineer: 'bg-blue-500/20 text-blue-300',
  operator: 'bg-teal-500/20 text-teal-300',
  viewer: 'bg-muted text-muted-foreground',
};

export default function UsersPage() {
  const { data } = useUsers();
  const users = data?.items ?? [];

  return (
    <AppShell>
      <div className="p-4 space-y-3">
        <h1 className="text-base font-semibold">Users</h1>
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <table className="w-full text-xs">
            <thead><tr className="border-b border-border bg-muted/40">
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Username</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Name</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Email</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Role</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Status</th>
              <th className="text-left px-3 py-2 font-medium text-muted-foreground">Last Login</th>
            </tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="border-b border-border/50 hover:bg-accent/30">
                  <td className="px-3 py-2 font-medium font-mono">{u.username}</td>
                  <td className="px-3 py-2">{u.full_name || '—'}</td>
                  <td className="px-3 py-2 text-muted-foreground">{u.email}</td>
                  <td className="px-3 py-2">
                    <span className={cn('px-1.5 py-0.5 rounded text-2xs font-medium', ROLE_COLORS[u.role] || 'bg-muted text-muted-foreground')}>{u.role}</span>
                    {u.is_superuser && <span className="ml-1 px-1 py-0.5 rounded text-2xs bg-amber-500/20 text-amber-300">super</span>}
                  </td>
                  <td className="px-3 py-2"><span className={cn(u.is_active ? 'text-status-healthy' : 'text-muted-foreground')}>{u.is_active ? 'Active' : 'Disabled'}</span></td>
                  <td className="px-3 py-2 text-muted-foreground">{u.last_login_at ? formatDistanceToNow(new Date(u.last_login_at), { addSuffix: true }) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
