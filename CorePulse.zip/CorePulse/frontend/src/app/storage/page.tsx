'use client';
import { AppShell } from '@/components/layout/AppShell';
import { useDevices, useMetrics, useDeviceSummary } from '@/lib/hooks/queries';
import { useUIStore } from '@/lib/store';
import { TIME_RANGES } from '@/types';
import { StatCard } from '@/components/widgets/StatCard';
import { TimeseriesChart } from '@/components/charts/TimeseriesChart';
import { GaugeWidget } from '@/components/charts/GaugeWidget';
import { formatBytes, formatIops, formatLatency, cn, statusDotClass } from '@/lib/utils';
import { HardDrive } from 'lucide-react';
import { useState } from 'react';

export default function StoragePage() {
  const { timeRange } = useUIStore();
  const range = TIME_RANGES.find(r => r.value === timeRange) ?? TIME_RANGES[1];
  const { data: arraysData } = useDevices({ device_type: 'flashsystem', page_size: 20 });
  const arrays = arraysData?.items ?? [];
  const [selectedId, setSelectedId] = useState<string | null>(arrays[0]?.id ?? null);
  const { data: summary } = useDeviceSummary(selectedId ?? '');
  const { data: iopsSeries } = useMetrics({ device_id: selectedId ?? undefined, metric_prefix: 'storage.', timeRangeSeconds: range.seconds, enabled: !!selectedId });

  const totalCap = summary?.['storage.total_capacity']?.value ?? 0;
  const usedCap = summary?.['storage.used_capacity']?.value ?? 0;
  const utilPct = totalCap > 0 ? (usedCap / totalCap) * 100 : 0;
  const readIops = summary?.['node.read_iops']?.value ?? 0;
  const writeIops = summary?.['node.write_iops']?.value ?? 0;

  return (
    <AppShell>
      <div className="p-4 space-y-4">
        <h1 className="text-base font-semibold">Storage</h1>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-3">
          {/* Array selector */}
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-3 py-2 border-b border-border text-xs font-semibold">Arrays ({arrays.length})</div>
            {arrays.map(arr => (
              <button key={arr.id} onClick={() => setSelectedId(arr.id)}
                className={cn('w-full text-left px-3 py-2 flex items-center gap-2 hover:bg-accent text-xs border-b border-border/50', arr.id === selectedId && 'bg-accent')}>
                <HardDrive size={11} className="text-muted-foreground" />
                <span className="flex-1 truncate">{arr.display_name || arr.name}</span>
                <span className={cn('status-dot', statusDotClass(arr.last_poll_status))} />
              </button>
            ))}
            {arrays.length === 0 && <p className="px-3 py-4 text-xs text-muted-foreground">No FlashSystem arrays</p>}
          </div>

          {/* Detail view */}
          {selectedId && (
            <div className="lg:col-span-4 space-y-3">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="metric-card items-center">
                  <p className="text-xs text-muted-foreground">Utilisation</p>
                  <GaugeWidget value={utilPct} size={100} label="Used" />
                </div>
                <StatCard title="Total Capacity" value={formatBytes(totalCap)} delta={null} />
                <StatCard title="Read IOPS" value={formatIops(readIops)} delta={null} valueClass="text-status-info" />
                <StatCard title="Write IOPS" value={formatIops(writeIops)} delta={null} valueClass="text-status-info" />
              </div>
              <div className="bg-card border border-border rounded-lg p-3">
                <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">I/O Metrics</h2>
                <TimeseriesChart series={(iopsSeries ?? []).filter(s => s.metric.includes('iops') || s.metric.includes('bandwidth'))} height={180} showLegend />
              </div>
            </div>
          )}
          {!selectedId && arrays.length === 0 && (
            <div className="lg:col-span-4 flex items-center justify-center text-xs text-muted-foreground h-32">
              No FlashSystem arrays configured. Add a device with type &apos;flashsystem&apos;.
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
