"""
CorePulse — Metrics service: ingestion, query, and aggregation.
Wraps all TimescaleDB-specific SQL patterns.
"""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.models.db.base import MetricRecord
from app.models.schemas.all_schemas import MetricPoint, MetricSeries, MetricQueryRequest

log = get_logger(__name__)

# Interval string → seconds mapping for validation
VALID_INTERVALS = {
    "1m": 60, "5m": 300, "15m": 900, "30m": 1800,
    "1h": 3600, "6h": 21600, "1d": 86400,
}

VALID_AGGREGATIONS = {"avg", "max", "min", "sum", "last", "count"}


class MetricsService:

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def ingest_batch(self, records: list[dict[str, Any]]) -> int:
        """
        High-throughput batch insert using PostgreSQL COPY protocol via
        raw SQL unnest() — avoids ORM overhead for write-hot path.
        Returns number of rows inserted.
        """
        if not records:
            return 0

        # Use PostgreSQL unnest for batch insert — fastest method
        stmt = text("""
            INSERT INTO metric_records (timestamp, device_id, metric, value, metric_type, unit, labels)
            SELECT
                unnest(:timestamps::timestamptz[]),
                unnest(:device_ids::uuid[]),
                unnest(:metrics::text[]),
                unnest(:values::float8[]),
                unnest(:types::text[]),
                unnest(:units::text[]),
                unnest(:labels::jsonb[])
            ON CONFLICT DO NOTHING
        """)

        import json
        params = {
            "timestamps": [r["timestamp"] for r in records],
            "device_ids": [str(r["device_id"]) for r in records],
            "metrics": [r["metric"] for r in records],
            "values": [float(r["value"]) for r in records],
            "types": [r.get("metric_type", "gauge") for r in records],
            "units": [r.get("unit", "") for r in records],
            "labels": [json.dumps(r.get("labels", {})) for r in records],
        }

        result = await self._session.execute(stmt, params)
        return result.rowcount or len(records)

    async def query_series(self, request: MetricQueryRequest) -> list[MetricSeries]:
        """
        Query time-bucketed metric data from TimescaleDB.
        Uses time_bucket() for server-side aggregation.
        """
        if request.aggregation not in VALID_AGGREGATIONS:
            request.aggregation = "avg"

        bucket = request.bucket_interval
        agg_fn = {
            "avg": "AVG", "max": "MAX", "min": "MIN",
            "sum": "SUM", "last": "LAST", "count": "COUNT",
        }[request.aggregation]

        # Build dynamic WHERE clause
        where_parts = ["1=1"]
        params: dict[str, Any] = {
            "limit": request.limit,
            "bucket": bucket,
        }

        if request.device_id:
            where_parts.append("device_id = :device_id")
            params["device_id"] = str(request.device_id)
        if request.metric:
            where_parts.append("metric = :metric")
            params["metric"] = request.metric
        elif request.metric_prefix:
            where_parts.append("metric LIKE :metric_prefix")
            params["metric_prefix"] = f"{request.metric_prefix}%"
        if request.from_ts:
            where_parts.append("timestamp >= :from_ts")
            params["from_ts"] = request.from_ts
        if request.to_ts:
            where_parts.append("timestamp <= :to_ts")
            params["to_ts"] = request.to_ts

        where_clause = " AND ".join(where_parts)

        if agg_fn == "LAST":
            # TimescaleDB LAST() function
            agg_expr = "LAST(value, timestamp)"
        else:
            agg_expr = f"{agg_fn}(value)"

        stmt = text(f"""
            SELECT
                time_bucket(:bucket::interval, timestamp) AS bucket_time,
                device_id,
                metric,
                unit,
                {agg_expr} AS agg_value,
                labels
            FROM metric_records
            WHERE {where_clause}
            GROUP BY bucket_time, device_id, metric, unit, labels
            ORDER BY bucket_time ASC
            LIMIT :limit
        """)

        result = await self._session.execute(stmt, params)
        rows = result.fetchall()

        # Group into series by (device_id, metric, labels)
        series_map: dict[tuple, MetricSeries] = {}
        for row in rows:
            key = (row.device_id, row.metric, str(row.labels))
            if key not in series_map:
                series_map[key] = MetricSeries(
                    device_id=row.device_id,
                    metric=row.metric,
                    unit=row.unit or "",
                    data=[],
                )
            if row.agg_value is not None:
                series_map[key].data.append(MetricPoint(
                    timestamp=row.bucket_time,
                    value=round(float(row.agg_value), 6),
                    labels=row.labels if isinstance(row.labels, dict) else {},
                ))

        return list(series_map.values())

    async def get_last_value(
        self,
        device_id: UUID,
        metric: str,
    ) -> Optional[float]:
        """Get the most recent value for a metric."""
        stmt = text("""
            SELECT value FROM metric_records
            WHERE device_id = :device_id AND metric = :metric
            ORDER BY timestamp DESC
            LIMIT 1
        """)
        result = await self._session.execute(stmt, {
            "device_id": str(device_id),
            "metric": metric,
        })
        row = result.fetchone()
        return float(row.value) if row else None

    async def get_device_summary(self, device_id: UUID) -> dict[str, Any]:
        """
        Latest values for the key metrics of a device.
        Uses a single DISTINCT ON query for efficiency.
        """
        stmt = text("""
            SELECT DISTINCT ON (metric)
                metric, value, unit, timestamp, labels
            FROM metric_records
            WHERE device_id = :device_id
                AND timestamp > NOW() - INTERVAL '10 minutes'
            ORDER BY metric, timestamp DESC
        """)
        result = await self._session.execute(stmt, {"device_id": str(device_id)})
        rows = result.fetchall()
        return {
            row.metric: {
                "value": row.value,
                "unit": row.unit,
                "timestamp": row.timestamp.isoformat(),
                "labels": row.labels,
            }
            for row in rows
        }

    async def get_top_talkers(
        self,
        device_id: Optional[UUID],
        metric: str,
        limit: int = 10,
        window_minutes: int = 5,
    ) -> list[dict[str, Any]]:
        """Return top N interfaces/entities by metric value."""
        params: dict[str, Any] = {
            "metric": metric,
            "window": f"{window_minutes} minutes",
            "limit": limit,
        }
        device_filter = ""
        if device_id:
            device_filter = "AND device_id = :device_id"
            params["device_id"] = str(device_id)

        stmt = text(f"""
            SELECT
                device_id,
                metric,
                labels,
                AVG(value) AS avg_value,
                MAX(value) AS max_value
            FROM metric_records
            WHERE metric = :metric
                AND timestamp > NOW() - :window::interval
                {device_filter}
            GROUP BY device_id, metric, labels
            ORDER BY avg_value DESC
            LIMIT :limit
        """)
        result = await self._session.execute(stmt, params)
        rows = result.fetchall()
        return [
            {
                "device_id": str(row.device_id),
                "metric": row.metric,
                "labels": row.labels,
                "avg_value": round(float(row.avg_value), 4),
                "max_value": round(float(row.max_value), 4),
            }
            for row in rows
        ]

    async def get_stats(self) -> dict[str, Any]:
        """Database-side metric statistics for health monitoring."""
        stmt = text("""
            SELECT
                COUNT(*) AS total_rows,
                COUNT(DISTINCT device_id) AS device_count,
                COUNT(DISTINCT metric) AS metric_count,
                MIN(timestamp) AS oldest_record,
                MAX(timestamp) AS newest_record
            FROM metric_records
        """)
        result = await self._session.execute(stmt)
        row = result.fetchone()
        if not row:
            return {}
        return {
            "total_rows": row.total_rows,
            "device_count": row.device_count,
            "metric_count": row.metric_count,
            "oldest_record": row.oldest_record.isoformat() if row.oldest_record else None,
            "newest_record": row.newest_record.isoformat() if row.newest_record else None,
        }
