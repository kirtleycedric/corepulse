"""
CorePulse — Device service: CRUD, discovery, and credential management.
"""
from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

from sqlalchemy import and_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.exceptions import ConflictError, NotFoundError
from app.core.logging import get_logger
from app.models.db.base import (
    CredentialProfile, Device, DeviceInterface,
    FlashSystemArray, ProxmoxCluster, ProxmoxNode, VirtualMachine,
)
from app.models.schemas.all_schemas import (
    DeviceCreate, DeviceUpdate,
    CredentialProfileCreate,
)
from app.utils.encryption import encrypt_data, decrypt_data

log = get_logger(__name__)


class DeviceService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def list_devices(
        self,
        device_type: Optional[str] = None,
        enabled: Optional[bool] = None,
        site: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> tuple[list[Device], int]:
        query = select(Device)
        count_query = select(Device)

        filters = []
        if device_type:
            filters.append(Device.device_type == device_type)
        if enabled is not None:
            filters.append(Device.enabled == enabled)
        if site:
            filters.append(Device.site == site)

        if filters:
            query = query.where(and_(*filters))
            count_query = count_query.where(and_(*filters))

        query = query.order_by(Device.name).limit(limit).offset(offset)

        result = await self._session.execute(query)
        devices = list(result.scalars().all())

        count_result = await self._session.execute(count_query)
        total = len(count_result.scalars().all())

        return devices, total

    async def get_device(self, device_id: UUID) -> Device:
        result = await self._session.execute(
            select(Device)
            .where(Device.id == device_id)
            .options(selectinload(Device.interfaces))
        )
        device = result.scalar_one_or_none()
        if not device:
            raise NotFoundError(f"Device {device_id} not found")
        return device

    async def get_device_by_host(self, host: str, device_type: str) -> Optional[Device]:
        result = await self._session.execute(
            select(Device).where(
                and_(Device.host == host, Device.device_type == device_type)
            )
        )
        return result.scalar_one_or_none()

    async def create_device(self, data: DeviceCreate) -> Device:
        # Check for duplicate host+type
        existing = await self.get_device_by_host(data.host, data.device_type)
        if existing:
            raise ConflictError(
                f"Device with host '{data.host}' and type '{data.device_type}' already exists"
            )

        device = Device(
            id=uuid.uuid4(),
            name=data.name,
            display_name=data.display_name or data.name,
            device_type=data.device_type,
            host=data.host,
            port=data.port,
            enabled=data.enabled,
            poll_interval_seconds=data.poll_interval_seconds,
            credential_profile_id=data.credential_profile_id,
            location=data.location,
            site=data.site,
            tags=data.tags,
            metadata_=data.metadata_,
            parent_id=data.parent_id,
        )
        self._session.add(device)
        await self._session.flush()
        log.info("device.created", device_id=str(device.id), name=device.name, type=device.device_type)
        return device

    async def update_device(self, device_id: UUID, data: DeviceUpdate) -> Device:
        device = await self.get_device(device_id)
        update_data = data.model_dump(exclude_none=True)
        for field, value in update_data.items():
            setattr(device, field, value)
        await self._session.flush()
        log.info("device.updated", device_id=str(device_id))
        return device

    async def delete_device(self, device_id: UUID) -> None:
        device = await self.get_device(device_id)
        await self._session.delete(device)
        log.info("device.deleted", device_id=str(device_id))

    async def update_device_status(
        self,
        device_id: UUID,
        poll_status: str,
        last_seen: Optional[datetime] = None,
        failure_increment: bool = False,
    ) -> None:
        """Update poll status without fetching the full device object."""
        update_data: dict[str, Any] = {
            "last_poll_at": datetime.now(tz=timezone.utc),
            "last_poll_status": poll_status,
        }
        if last_seen:
            update_data["last_seen_at"] = last_seen
        if failure_increment:
            # Use SQL expression for atomic increment
            stmt = (
                update(Device)
                .where(Device.id == device_id)
                .values(**update_data, consecutive_failures=Device.consecutive_failures + 1)
            )
        else:
            update_data["consecutive_failures"] = 0
            stmt = update(Device).where(Device.id == device_id).values(**update_data)

        await self._session.execute(stmt)

    async def upsert_interface(self, device_id: UUID, if_data: dict[str, Any]) -> DeviceInterface:
        """Update or create a device interface record."""
        result = await self._session.execute(
            select(DeviceInterface).where(
                and_(
                    DeviceInterface.device_id == device_id,
                    DeviceInterface.if_index == if_data["if_index"],
                )
            )
        )
        iface = result.scalar_one_or_none()
        if iface:
            for k, v in if_data.items():
                setattr(iface, k, v)
        else:
            iface = DeviceInterface(id=uuid.uuid4(), device_id=device_id, **if_data)
            self._session.add(iface)
        await self._session.flush()
        return iface

    async def get_devices_for_polling(self) -> list[Device]:
        """Return all enabled devices that are due for polling."""
        result = await self._session.execute(
            select(Device)
            .options(selectinload(Device.credential_profile))
            .where(Device.enabled == True)
            .order_by(Device.last_poll_at.nullsfirst(), Device.name)
        )
        return list(result.scalars().all())


class CredentialService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create_profile(
        self, data: CredentialProfileCreate, created_by: UUID
    ) -> CredentialProfile:
        encrypted = encrypt_data(data.credentials)
        profile = CredentialProfile(
            id=uuid.uuid4(),
            name=data.name,
            description=data.description,
            protocol=data.protocol,
            credentials_enc=encrypted,
            created_by=created_by,
        )
        self._session.add(profile)
        await self._session.flush()
        log.info("credential_profile.created", profile_id=str(profile.id), name=profile.name)
        return profile

    async def get_profile(self, profile_id: UUID) -> CredentialProfile:
        result = await self._session.execute(
            select(CredentialProfile).where(CredentialProfile.id == profile_id)
        )
        profile = result.scalar_one_or_none()
        if not profile:
            raise NotFoundError(f"Credential profile {profile_id} not found")
        return profile

    async def get_decrypted_credentials(self, profile_id: UUID) -> dict[str, Any]:
        profile = await self.get_profile(profile_id)
        return decrypt_data(profile.credentials_enc)

    async def list_profiles(self) -> list[CredentialProfile]:
        result = await self._session.execute(
            select(CredentialProfile).order_by(CredentialProfile.name)
        )
        return list(result.scalars().all())

    async def delete_profile(self, profile_id: UUID) -> None:
        profile = await self.get_profile(profile_id)
        await self._session.delete(profile)
        log.info("credential_profile.deleted", profile_id=str(profile_id))
