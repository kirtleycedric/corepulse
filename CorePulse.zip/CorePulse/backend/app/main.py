"""
CorePulse — FastAPI application factory.
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from typing import Any, Callable
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.core.database import close_db, init_db
from app.core.exceptions import register_exception_handlers
from app.core.logging import configure_logging, get_logger
from app.core.redis import close_redis, init_redis

log = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    cfg = get_settings()
    configure_logging(level=cfg.LOG_LEVEL, fmt=cfg.LOG_FORMAT)
    log.info("corepulse.starting", version=cfg.APP_VERSION, env=cfg.ENV)

    await init_db()
    await init_redis()

    # Start WebSocket Redis listener
    from app.websocket.hub import hub
    await hub.start_redis_listener()

    import asyncio
    heartbeat_task = asyncio.create_task(hub.heartbeat_loop())

    log.info("corepulse.ready")
    yield

    # Shutdown
    heartbeat_task.cancel()
    await close_redis()
    await close_db()
    log.info("corepulse.shutdown")


def create_app() -> FastAPI:
    cfg = get_settings()

    app = FastAPI(
        title="CorePulse API",
        description="Enterprise Infrastructure Monitoring Platform",
        version=cfg.APP_VERSION,
        docs_url="/api/docs" if not cfg.is_production else None,
        redoc_url="/api/redoc" if not cfg.is_production else None,
        openapi_url="/api/openapi.json" if not cfg.is_production else None,
        lifespan=lifespan,
    )

    # ── Middleware ────────────────────────────────────────────────────────────

    app.add_middleware(GZipMiddleware, minimum_size=1000)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cfg.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID", "X-Process-Time"],
    )

    @app.middleware("http")
    async def request_timing_middleware(request: Request, call_next: Any) -> Response:
        import uuid
        request_id = str(uuid.uuid4())
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = (time.perf_counter() - start) * 1000
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Process-Time"] = f"{duration_ms:.1f}ms"
        log.info(
            "http.request",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            duration_ms=round(duration_ms, 1),
            request_id=request_id,
        )
        return response

    @app.middleware("http")
    async def rate_limit_middleware(request: Request, call_next: Any) -> Response:
        if not cfg.RATE_LIMIT_ENABLED:
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        path = request.url.path

        # Tighter limit on auth endpoints
        if "/auth/login" in path:
            from app.core.redis import rate_limit
            key = f"rl:auth:{client_ip}"
            count = await rate_limit.incr(key, ttl=60)
            if count > 10:
                return JSONResponse(
                    status_code=429,
                    content={"error": {"code": "RATE_LIMIT_EXCEEDED", "message": "Too many login attempts"}},
                )

        return await call_next(request)

    # ── Exception handlers ────────────────────────────────────────────────────
    register_exception_handlers(app)

    # ── Routes ────────────────────────────────────────────────────────────────
    from app.api.v1.router import api_router
    app.include_router(api_router)

    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {"service": "CorePulse API", "version": cfg.APP_VERSION, "status": "online"}

    return app


app = create_app()
