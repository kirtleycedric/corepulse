"""
CorePulse — Alerting engine.

Evaluates alert rules against current metrics, manages incident lifecycle
(firing → resolved), and dispatches notifications through configured channels.

Key features:
  - Threshold and state-based alerting
  - Cooldown / deduplication
  - Maintenance windows
  - Multi-channel notification (email, Slack, Teams, Telegram, webhook)
  - Escalation-ready state machine
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

from sqlalchemy import and_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.core.redis import cache
from app.models.db.base import AlertIncident, AlertRule, Device, NotificationChannel
from app.utils.encryption import decrypt_data

log = get_logger(__name__)


class AlertEvaluator:
    """
    Evaluates a single alert rule against a metric value.
    Supports threshold, rate-of-change, and state conditions.
    """

    OPERATORS = {
        ">":  lambda v, t: v > t,
        ">=": lambda v, t: v >= t,
        "<":  lambda v, t: v < t,
        "<=": lambda v, t: v <= t,
        "==": lambda v, t: v == t,
        "!=": lambda v, t: v != t,
    }

    @classmethod
    def evaluate(cls, rule: AlertRule, current_value: float, labels: dict[str, str]) -> bool:
        """
        Returns True if the rule condition is currently met.
        """
        config = rule.condition_config
        condition_type = rule.condition_type

        if condition_type == "threshold":
            operator = config.get("operator", ">")
            threshold = float(config.get("threshold", 0))
            op_fn = cls.OPERATORS.get(operator)
            if op_fn is None:
                log.warning("alert.unknown_operator", operator=operator)
                return False
            return op_fn(current_value, threshold)

        elif condition_type == "state":
            # State matching — value is 0 or 1
            expected = config.get("expected_state", 0)
            return int(current_value) != int(expected)

        elif condition_type == "absent":
            # Handled by a separate stale-data check
            return False

        log.warning("alert.unknown_condition_type", type=condition_type)
        return False

    @classmethod
    def format_message(cls, rule: AlertRule, value: float, device_name: str) -> str:
        config = rule.condition_config
        op = config.get("operator", ">")
        threshold = config.get("threshold", "")
        metric = rule.metric
        return (
            f"[{rule.severity.upper()}] {rule.name}: "
            f"{device_name} — {metric} {op} {threshold} (current: {round(value, 2)})"
        )


class AlertDeduplicator:
    """
    Prevents alert storm by tracking cooldown state in Redis.
    Key pattern: alert_cooldown:{rule_id}:{device_id}
    """

    @staticmethod
    async def is_in_cooldown(rule_id: UUID, device_id: UUID) -> bool:
        key = f"alert_cooldown:{rule_id}:{device_id}"
        return await cache.exists(key)

    @staticmethod
    async def set_cooldown(rule_id: UUID, device_id: UUID, cooldown_seconds: int) -> None:
        key = f"alert_cooldown:{rule_id}:{device_id}"
        await cache.set(key, 1, ttl=cooldown_seconds)

    @staticmethod
    async def clear_cooldown(rule_id: UUID, device_id: UUID) -> None:
        key = f"alert_cooldown:{rule_id}:{device_id}"
        await cache.delete(key)


class AlertManager:
    """
    Orchestrates the full alert lifecycle.
    Called by the Celery alert evaluation task.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def evaluate_all_rules(self) -> dict[str, int]:
        """
        Evaluate all enabled alert rules against current metrics.
        Returns summary of {fired: N, resolved: N, suppressed: N}.
        """
        stats = {"fired": 0, "resolved": 0, "suppressed": 0}

        # Load all enabled rules with devices
        result = await self._session.execute(
            select(AlertRule).where(AlertRule.enabled == True)
        )
        rules = list(result.scalars().all())

        log.info("alert.evaluation.start", rule_count=len(rules))

        for rule in rules:
            try:
                fired, resolved, suppressed = await self._evaluate_rule(rule)
                stats["fired"] += fired
                stats["resolved"] += resolved
                stats["suppressed"] += suppressed
            except Exception as exc:
                log.error("alert.rule_evaluation_failed", rule_id=str(rule.id), error=str(exc))

        log.info("alert.evaluation.complete", **stats)
        return stats

    async def _evaluate_rule(self, rule: AlertRule) -> tuple[int, int, int]:
        """Returns (fired, resolved, suppressed) counts for this rule."""
        fired = resolved = suppressed = 0

        # Maintenance window check
        if rule.maintenance_until and rule.maintenance_until > datetime.now(tz=timezone.utc):
            return 0, 0, 0

        # Determine target devices
        device_ids = await self._get_target_device_ids(rule)
        if not device_ids:
            return 0, 0, 0

        for device_id in device_ids:
            # Get current metric value from Redis (set by collectors)
            metric_key = f"last_metric:{device_id}:{rule.metric}"
            cached = await cache.get(metric_key)
            if cached is None:
                continue

            current_value = float(cached.get("value", 0))
            labels = cached.get("labels", {})
            device_name = cached.get("device_name", str(device_id))

            condition_met = AlertEvaluator.evaluate(rule, current_value, labels)

            # Find existing firing incident
            existing = await self._get_firing_incident(rule.id, device_id)

            if condition_met and existing is None:
                # Check cooldown
                if await AlertDeduplicator.is_in_cooldown(rule.id, device_id):
                    suppressed += 1
                    continue

                # Fire new incident
                await self._fire_incident(rule, device_id, current_value, labels, device_name)
                await AlertDeduplicator.set_cooldown(rule.id, device_id, rule.cooldown_seconds)
                fired += 1

            elif not condition_met and existing is not None:
                # Resolve existing incident
                await self._resolve_incident(existing.id)
                resolved += 1

        return fired, resolved, suppressed

    async def _get_target_device_ids(self, rule: AlertRule) -> list[UUID]:
        """Determine which device IDs this rule applies to."""
        if rule.device_id:
            return [rule.device_id]

        # Apply device_type and tag filters
        query = select(Device.id).where(Device.enabled == True)
        if rule.device_type_filter:
            query = query.where(Device.device_type == rule.device_type_filter)
        if rule.tag_filter:
            for key, value in rule.tag_filter.items():
                query = query.where(Device.tags[key].astext == value)

        result = await self._session.execute(query)
        return [row[0] for row in result.fetchall()]

    async def _get_firing_incident(self, rule_id: UUID, device_id: UUID) -> Optional[AlertIncident]:
        result = await self._session.execute(
            select(AlertIncident).where(
                and_(
                    AlertIncident.rule_id == rule_id,
                    AlertIncident.device_id == device_id,
                    AlertIncident.status == "firing",
                )
            )
        )
        return result.scalar_one_or_none()

    async def _fire_incident(
        self,
        rule: AlertRule,
        device_id: UUID,
        value: float,
        labels: dict[str, str],
        device_name: str,
    ) -> AlertIncident:
        message = AlertEvaluator.format_message(rule, value, device_name)
        incident = AlertIncident(
            id=uuid.uuid4(),
            rule_id=rule.id,
            device_id=device_id,
            metric=rule.metric,
            severity=rule.severity,
            status="firing",
            trigger_value=value,
            trigger_labels=labels,
            message=message,
        )
        self._session.add(incident)
        await self._session.flush()

        log.info(
            "alert.incident.fired",
            incident_id=str(incident.id),
            rule=rule.name,
            device_id=str(device_id),
            value=value,
            severity=rule.severity,
        )

        # Publish to Redis for WebSocket broadcasting
        await cache.publish("alerts", {
            "event": "incident_fired",
            "incident_id": str(incident.id),
            "rule_name": rule.name,
            "device_id": str(device_id),
            "severity": rule.severity,
            "message": message,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        })

        # Dispatch notifications
        asyncio.create_task(
            self._dispatch_notifications(incident, rule)
        )

        return incident

    async def _resolve_incident(self, incident_id: UUID) -> None:
        await self._session.execute(
            update(AlertIncident)
            .where(AlertIncident.id == incident_id)
            .values(status="resolved", resolved_at=datetime.now(tz=timezone.utc))
        )
        log.info("alert.incident.resolved", incident_id=str(incident_id))

        # Publish resolution event
        await cache.publish("alerts", {
            "event": "incident_resolved",
            "incident_id": str(incident_id),
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        })

    async def _dispatch_notifications(
        self, incident: AlertIncident, rule: AlertRule
    ) -> None:
        """Dispatch notifications to all configured channels for this rule."""
        if not rule.notification_channel_ids:
            return

        channel_ids = [UUID(cid) if isinstance(cid, str) else cid
                       for cid in rule.notification_channel_ids]

        result = await self._session.execute(
            select(NotificationChannel).where(
                and_(
                    NotificationChannel.id.in_(channel_ids),
                    NotificationChannel.enabled == True,
                )
            )
        )
        channels = list(result.scalars().all())

        for channel in channels:
            try:
                config = decrypt_data(channel.config_enc)
                await NotificationDispatcher.dispatch(
                    channel_type=channel.channel_type,
                    config=config,
                    incident=incident,
                )
                await self._session.execute(
                    update(AlertIncident)
                    .where(AlertIncident.id == incident.id)
                    .values(notification_sent=True, notification_attempts=AlertIncident.notification_attempts + 1)
                )
            except Exception as exc:
                log.error(
                    "alert.notification.failed",
                    channel_id=str(channel.id),
                    channel_type=channel.channel_type,
                    error=str(exc),
                )

    async def acknowledge_incident(
        self, incident_id: UUID, user_id: UUID
    ) -> AlertIncident:
        result = await self._session.execute(
            select(AlertIncident).where(AlertIncident.id == incident_id)
        )
        incident = result.scalar_one_or_none()
        if not incident:
            from app.core.exceptions import NotFoundError
            raise NotFoundError(f"Incident {incident_id} not found")

        incident.acknowledged = True
        incident.acknowledged_by = user_id
        incident.acknowledged_at = datetime.now(tz=timezone.utc)
        await self._session.flush()
        return incident


class NotificationDispatcher:
    """Routes notifications to the correct channel handler."""

    @classmethod
    async def dispatch(
        cls,
        channel_type: str,
        config: dict[str, Any],
        incident: AlertIncident,
    ) -> None:
        handlers = {
            "email":   cls._send_email,
            "slack":   cls._send_slack,
            "teams":   cls._send_teams,
            "telegram": cls._send_telegram,
            "webhook": cls._send_webhook,
        }
        handler = handlers.get(channel_type)
        if handler:
            await handler(config, incident)
        else:
            log.warning("notification.unknown_channel_type", type=channel_type)

    @staticmethod
    async def _send_email(config: dict, incident: AlertIncident) -> None:
        import aiosmtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[CorePulse] {incident.severity.upper()} Alert: {incident.message[:100]}"
        msg["From"] = config.get("from_email", "alerts@corepulse.local")
        msg["To"] = config.get("to_email", "")

        html_body = f"""
        <html><body>
        <h2 style="color: {'#dc3545' if incident.severity == 'critical' else '#fd7e14'}">
        CorePulse Alert — {incident.severity.upper()}</h2>
        <p><strong>Message:</strong> {incident.message}</p>
        <p><strong>Metric:</strong> {incident.metric}</p>
        <p><strong>Value:</strong> {incident.trigger_value}</p>
        <p><strong>Device:</strong> {incident.device_id}</p>
        <p><strong>Time:</strong> {incident.triggered_at.isoformat()}</p>
        <hr><p><em>CorePulse Infrastructure Monitoring</em></p>
        </body></html>
        """
        msg.attach(MIMEText(html_body, "html"))

        try:
            await aiosmtplib.send(
                msg,
                hostname=config.get("smtp_host", "localhost"),
                port=int(config.get("smtp_port", 587)),
                username=config.get("smtp_user"),
                password=config.get("smtp_password"),
                use_tls=config.get("use_tls", True),
                timeout=10,
            )
            log.info("notification.email.sent", to=config.get("to_email"))
        except Exception as exc:
            log.error("notification.email.failed", error=str(exc))
            raise

    @staticmethod
    async def _send_slack(config: dict, incident: AlertIncident) -> None:
        import aiohttp
        webhook_url = config.get("webhook_url", "")
        if not webhook_url:
            return

        color = "#dc3545" if incident.severity == "critical" else "#fd7e14" if incident.severity == "warning" else "#0dcaf0"
        payload = {
            "attachments": [{
                "color": color,
                "title": f"CorePulse Alert — {incident.severity.upper()}",
                "text": incident.message,
                "fields": [
                    {"title": "Metric", "value": incident.metric, "short": True},
                    {"title": "Value",  "value": str(round(incident.trigger_value, 4)), "short": True},
                    {"title": "Device", "value": str(incident.device_id), "short": True},
                    {"title": "Time",   "value": incident.triggered_at.isoformat(), "short": True},
                ],
                "footer": "CorePulse",
                "ts": int(incident.triggered_at.timestamp()),
            }]
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"Slack API error: {resp.status}")

    @staticmethod
    async def _send_teams(config: dict, incident: AlertIncident) -> None:
        import aiohttp
        webhook_url = config.get("webhook_url", "")
        if not webhook_url:
            return

        color = "FF0000" if incident.severity == "critical" else "FFA500"
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": color,
            "summary": incident.message,
            "sections": [{
                "activityTitle": f"CorePulse Alert — {incident.severity.upper()}",
                "activitySubtitle": incident.message,
                "facts": [
                    {"name": "Metric",   "value": incident.metric},
                    {"name": "Value",    "value": str(round(incident.trigger_value, 4))},
                    {"name": "Device",   "value": str(incident.device_id)},
                    {"name": "Severity", "value": incident.severity},
                    {"name": "Time",     "value": incident.triggered_at.isoformat()},
                ],
            }],
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"Teams API error: {resp.status}")

    @staticmethod
    async def _send_telegram(config: dict, incident: AlertIncident) -> None:
        import aiohttp
        bot_token = config.get("bot_token", "")
        chat_id   = config.get("chat_id", "")
        if not bot_token or not chat_id:
            return

        emoji = "🔴" if incident.severity == "critical" else "🟡" if incident.severity == "warning" else "🔵"
        text = (
            f"{emoji} *CorePulse Alert — {incident.severity.upper()}*\n\n"
            f"{incident.message}\n\n"
            f"📊 Metric: `{incident.metric}`\n"
            f"📈 Value: `{round(incident.trigger_value, 4)}`\n"
            f"🖥️ Device: `{incident.device_id}`\n"
            f"🕐 Time: `{incident.triggered_at.isoformat()}`"
        )
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                json={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                data = await resp.json()
                if not data.get("ok"):
                    raise RuntimeError(f"Telegram error: {data.get('description')}")

    @staticmethod
    async def _send_webhook(config: dict, incident: AlertIncident) -> None:
        import aiohttp
        webhook_url = config.get("url", "")
        if not webhook_url:
            return

        payload = {
            "event": "alert",
            "incident_id": str(incident.id),
            "rule_id": str(incident.rule_id),
            "device_id": str(incident.device_id),
            "metric": incident.metric,
            "severity": incident.severity,
            "status": incident.status,
            "value": incident.trigger_value,
            "message": incident.message,
            "labels": incident.trigger_labels,
            "triggered_at": incident.triggered_at.isoformat(),
        }
        headers = config.get("headers", {})
        async with aiohttp.ClientSession() as session:
            async with session.post(
                webhook_url, json=payload, headers=headers,
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status not in (200, 201, 202, 204):
                    raise RuntimeError(f"Webhook error: HTTP {resp.status}")
