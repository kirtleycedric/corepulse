"""
CorePulse — SNMP vendor-specific drivers.
Each driver extends AbstractSNMPDriver and implements
collect_system(), collect_cpu(), collect_memory(), collect_interfaces().
"""
from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

from app.collectors.snmp.transport import OIDs, SNMPCredentials, SNMPTransport, _coerce_str, _coerce_value
from app.core.exceptions import CollectorError
from app.core.logging import get_logger

log = get_logger(__name__)


def _metric(
    device_id: UUID,
    metric: str,
    value: float,
    labels: Optional[dict[str, str]] = None,
    metric_type: str = "gauge",
    unit: str = "",
) -> dict[str, Any]:
    return {
        "timestamp": datetime.now(tz=timezone.utc),
        "device_id": device_id,
        "metric": metric,
        "value": value,
        "metric_type": metric_type,
        "unit": unit,
        "labels": labels or {},
    }


class AbstractSNMPDriver(ABC):
    vendor: str = "generic"

    def __init__(self, device_id: UUID, host: str, credentials: SNMPCredentials) -> None:
        self._device_id = device_id
        self._host = host
        self._creds = credentials
        self._transport = SNMPTransport(host, credentials)
        self._log = log.bind(driver=self.vendor, host=host, device_id=str(device_id))

    @abstractmethod
    async def collect_system(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def collect_cpu(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def collect_memory(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def collect_interfaces(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Returns (metric_records, interface_state_records)."""
        ...

    async def collect(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """
        Full collection: system + cpu + memory + interfaces.
        Partial failure returns what succeeded.
        """
        t0 = time.perf_counter()
        self._log.info("snmp.collect.start")

        results = await asyncio.gather(
            self.collect_system(),
            self.collect_cpu(),
            self.collect_memory(),
            self.collect_interfaces(),
            return_exceptions=True,
        )

        metrics: list[dict[str, Any]] = []
        iface_states: list[dict[str, Any]] = []

        for label, result in zip(["system", "cpu", "memory", "interfaces"], results):
            if isinstance(result, Exception):
                self._log.warning(f"snmp.collect.{label}_failed", error=str(result))
            elif label == "interfaces":
                iface_metrics, states = result
                metrics.extend(iface_metrics)
                iface_states.extend(states)
            else:
                metrics.extend(result)

        duration_ms = (time.perf_counter() - t0) * 1000
        self._log.info("snmp.collect.complete", metrics=len(metrics), duration_ms=round(duration_ms, 1))
        return metrics, iface_states

    def _m(self, metric: str, value: float, labels: Optional[dict] = None,
           metric_type: str = "gauge", unit: str = "") -> dict[str, Any]:
        return _metric(self._device_id, metric, value, labels, metric_type, unit)

    async def _collect_standard_interfaces(self) -> tuple[list[dict], list[dict]]:
        """
        Standard IF-MIB + HC extension interface collection.
        Used by all drivers. Returns (metrics, interface_states).
        """
        oid_bases = [
            OIDs.IF_DESCR, OIDs.IF_TYPE, OIDs.IF_SPEED,
            OIDs.IF_ADMIN_STATUS, OIDs.IF_OPER_STATUS,
            OIDs.IF_IN_ERRORS, OIDs.IF_IN_DISCARDS,
            OIDs.IF_OUT_ERRORS, OIDs.IF_OUT_DISCARDS,
            OIDs.IF_HC_IN_OCTETS, OIDs.IF_HC_OUT_OCTETS,
            OIDs.IF_HC_IN_UCAST, OIDs.IF_HC_OUT_UCAST,
            OIDs.IF_HIGH_SPEED, OIDs.IF_ALIAS,
        ]

        walks = await self._transport.multi_walk(oid_bases, max_repetitions=self._creds.bulk_max_repetitions)

        # Fall back to 32-bit counters if HC not available
        hc_in = self._transport._index_map(walks, OIDs.IF_HC_IN_OCTETS)
        hc_out = self._transport._index_map(walks, OIDs.IF_HC_OUT_OCTETS)
        if not hc_in:
            extra = await self._transport.multi_walk([OIDs.IF_IN_OCTETS, OIDs.IF_OUT_OCTETS])
            hc_in = self._transport._index_map(extra, OIDs.IF_IN_OCTETS)
            hc_out = self._transport._index_map(extra, OIDs.IF_OUT_OCTETS)

        descr_map     = self._transport._index_map(walks, OIDs.IF_DESCR)
        admin_map     = self._transport._index_map(walks, OIDs.IF_ADMIN_STATUS)
        oper_map      = self._transport._index_map(walks, OIDs.IF_OPER_STATUS)
        speed_map     = self._transport._index_map(walks, OIDs.IF_HIGH_SPEED)
        alias_map     = self._transport._index_map(walks, OIDs.IF_ALIAS)
        in_err_map    = self._transport._index_map(walks, OIDs.IF_IN_ERRORS)
        out_err_map   = self._transport._index_map(walks, OIDs.IF_OUT_ERRORS)
        in_dis_map    = self._transport._index_map(walks, OIDs.IF_IN_DISCARDS)
        out_dis_map   = self._transport._index_map(walks, OIDs.IF_OUT_DISCARDS)
        in_ucast_map  = self._transport._index_map(walks, OIDs.IF_HC_IN_UCAST)
        out_ucast_map = self._transport._index_map(walks, OIDs.IF_HC_OUT_UCAST)

        metrics: list[dict] = []
        iface_states: list[dict] = []

        for idx, descr_raw in descr_map.items():
            if_idx = int(idx) if idx.isdigit() else 0
            if_name = _coerce_str(descr_raw)
            if_alias = _coerce_str(alias_map.get(idx, ""))
            speed_mbps = _coerce_value(speed_map.get(idx, 0)) or 0
            speed_bps = int(speed_mbps) * 1_000_000
            admin_st = int(_coerce_value(admin_map.get(idx, 2)) or 2)
            oper_st  = int(_coerce_value(oper_map.get(idx, 2)) or 2)

            lbl = {
                "if_index": idx,
                "if_name": if_name,
                "if_alias": if_alias,
                "vendor": self.vendor,
            }

            metrics.append(self._m("if.oper_status", float(oper_st), lbl, "status"))
            metrics.append(self._m("if.admin_status", float(admin_st), lbl, "status"))

            in_oct = int(_coerce_value(hc_in.get(idx, 0)) or 0)
            out_oct = int(_coerce_value(hc_out.get(idx, 0)) or 0)
            metrics.append(self._m("if.in_octets", float(in_oct), lbl, "counter", "bytes"))
            metrics.append(self._m("if.out_octets", float(out_oct), lbl, "counter", "bytes"))

            for src, metric_name in [
                (in_err_map, "if.in_errors"), (out_err_map, "if.out_errors"),
                (in_dis_map, "if.in_discards"), (out_dis_map, "if.out_discards"),
            ]:
                val = _coerce_value(src.get(idx, 0))
                if val is not None:
                    metrics.append(self._m(metric_name, val, lbl, "counter"))

            for src, metric_name in [
                (in_ucast_map, "if.in_ucast_pkts"), (out_ucast_map, "if.out_ucast_pkts"),
            ]:
                val = _coerce_value(src.get(idx, 0))
                if val is not None:
                    metrics.append(self._m(metric_name, val, lbl, "counter", "packets"))

            # Utilisation (requires previous value for rate — stored by normaliser)
            if speed_bps > 0:
                in_util = min(float(in_oct) * 8 / speed_bps * 100, 100.0)
                out_util = min(float(out_oct) * 8 / speed_bps * 100, 100.0)
                metrics.append(self._m("if.in_util", round(in_util, 2), lbl, unit="percent"))
                metrics.append(self._m("if.out_util", round(out_util, 2), lbl, unit="percent"))

            iface_states.append({
                "if_index": if_idx,
                "if_name": if_name,
                "if_alias": if_alias,
                "if_descr": if_name,
                "if_speed_bps": speed_bps,
                "if_admin_status": admin_st,
                "if_oper_status": oper_st,
            })

        return metrics, iface_states


class JuniperDriver(AbstractSNMPDriver):
    vendor = "juniper"

    async def collect_system(self) -> list[dict[str, Any]]:
        raw = await self._transport.get_scalars([OIDs.SYS_DESCR, OIDs.SYS_NAME, OIDs.SYS_UPTIME])
        metrics: list[dict] = []
        metrics.append(self._m("sys.up", 1.0, metric_type="status"))
        uptime_raw = raw.get(OIDs.SYS_UPTIME)
        if uptime_raw:
            cs = _coerce_value(uptime_raw)
            if cs:
                metrics.append(self._m("sys.uptime", cs / 100.0, unit="seconds"))
        return metrics

    async def collect_cpu(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        walks = await self._transport.multi_walk([
            OIDs.JNX_OPERATING_CPU, OIDs.JNX_OPERATING_TEMP,
            OIDs.JNX_OPERATING_BUF, OIDs.JNX_RE_CPU_IDLE,
        ])
        cpu_map  = self._transport._index_map(walks, OIDs.JNX_OPERATING_CPU)
        temp_map = self._transport._index_map(walks, OIDs.JNX_OPERATING_TEMP)
        buf_map  = self._transport._index_map(walks, OIDs.JNX_OPERATING_BUF)
        idle_map = self._transport._index_map(walks, OIDs.JNX_RE_CPU_IDLE)

        for idx, raw_val in cpu_map.items():
            v = _coerce_value(raw_val)
            if v is not None:
                parts = idx.split(".")
                slot = f"fpc{parts[1]}" if len(parts) > 2 else "re"
                lbl = {"slot": slot, "vendor": "juniper"}
                metrics.append(self._m("cpu.util", v, lbl, unit="percent"))

        for idx, raw_val in temp_map.items():
            v = _coerce_value(raw_val)
            if v and v > 0:
                metrics.append(self._m("sensor.temp", v, {"slot": idx}, unit="celsius"))

        for idx, raw_val in idle_map.items():
            idle = _coerce_value(raw_val)
            if idle is not None:
                metrics.append(self._m("re.cpu_util", 100.0 - idle, {"re_slot": idx}, unit="percent"))

        return metrics

    async def collect_memory(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        walks = await self._transport.multi_walk([OIDs.JNX_RE_MEM_TOTAL, OIDs.JNX_RE_MEM_USED])
        total_map = self._transport._index_map(walks, OIDs.JNX_RE_MEM_TOTAL)
        used_map  = self._transport._index_map(walks, OIDs.JNX_RE_MEM_USED)

        for idx, total_raw in total_map.items():
            total_kb = _coerce_value(total_raw)
            if not total_kb or total_kb <= 0:
                continue
            used_kb = _coerce_value(used_map.get(idx, 0)) or 0
            lbl = {"re_slot": idx}
            total_b = total_kb * 1024
            used_b  = used_kb  * 1024
            metrics.append(self._m("mem.total", total_b, lbl, unit="bytes"))
            metrics.append(self._m("mem.used",  used_b,  lbl, unit="bytes"))
            metrics.append(self._m("mem.free",  total_b - used_b, lbl, unit="bytes"))
            metrics.append(self._m("mem.util",  round(used_kb / total_kb * 100, 2), lbl, unit="percent"))

        return metrics

    async def collect_interfaces(self) -> tuple[list[dict], list[dict]]:
        return await self._collect_standard_interfaces()


class CiscoSG300Driver(AbstractSNMPDriver):
    vendor = "cisco_sg300"

    async def collect_system(self) -> list[dict[str, Any]]:
        raw = await self._transport.get_scalars([OIDs.SYS_UPTIME, OIDs.SYS_DESCR])
        metrics: list[dict] = [self._m("sys.up", 1.0, metric_type="status")]
        uptime_raw = raw.get(OIDs.SYS_UPTIME)
        if uptime_raw:
            cs = _coerce_value(uptime_raw)
            if cs:
                metrics.append(self._m("sys.uptime", cs / 100.0, unit="seconds"))
        return metrics

    async def collect_cpu(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        try:
            raw = await self._transport.get_scalars([OIDs.SG300_CPU_UTIL])
            cpu_val = _coerce_value(raw.get(OIDs.SG300_CPU_UTIL))
            if cpu_val is not None:
                metrics.append(self._m("cpu.util", cpu_val, {"vendor": "cisco_sg300"}, unit="percent"))
        except CollectorError:
            # SG300 firmware variations — fall back to hrProcessorLoad
            try:
                walks = await self._transport.bulk_walk(OIDs.HR_PROCESSOR_LOAD)
                if walks:
                    vals = [_coerce_value(v) for _, v in walks if _coerce_value(v) is not None]
                    if vals:
                        avg_cpu = sum(vals) / len(vals)
                        metrics.append(self._m("cpu.util", round(avg_cpu, 2), unit="percent"))
            except Exception:
                pass
        return metrics

    async def collect_memory(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        try:
            raw = await self._transport.get_scalars([OIDs.SG300_MEM_TOTAL, OIDs.SG300_MEM_FREE])
            total = _coerce_value(raw.get(OIDs.SG300_MEM_TOTAL))
            free  = _coerce_value(raw.get(OIDs.SG300_MEM_FREE))
            if total and total > 0:
                metrics.append(self._m("mem.total", total, unit="bytes"))
                if free is not None:
                    used = total - free
                    metrics.append(self._m("mem.free", free, unit="bytes"))
                    metrics.append(self._m("mem.used", used, unit="bytes"))
                    metrics.append(self._m("mem.util", round(used / total * 100, 2), unit="percent"))
        except CollectorError:
            pass
        return metrics

    async def collect_interfaces(self) -> tuple[list[dict], list[dict]]:
        return await self._collect_standard_interfaces()


class CiscoCatalystDriver(AbstractSNMPDriver):
    vendor = "cisco_catalyst"

    async def collect_system(self) -> list[dict[str, Any]]:
        raw = await self._transport.get_scalars([OIDs.SYS_UPTIME, OIDs.SYS_DESCR])
        metrics: list[dict] = [self._m("sys.up", 1.0, metric_type="status")]
        uptime_raw = raw.get(OIDs.SYS_UPTIME)
        if uptime_raw:
            cs = _coerce_value(uptime_raw)
            if cs:
                metrics.append(self._m("sys.uptime", cs / 100.0, unit="seconds"))
        return metrics

    async def collect_cpu(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        walks = await self._transport.multi_walk([OIDs.CISCO_CPU_5S, OIDs.CISCO_CPU_1M, OIDs.CISCO_CPU_5M])
        for base, metric_name in [
            (OIDs.CISCO_CPU_5S, "cpu.util_5s"),
            (OIDs.CISCO_CPU_1M, "cpu.util_1m"),
            (OIDs.CISCO_CPU_5M, "cpu.util_5m"),
        ]:
            rows = walks.get(base, [])
            for oid_str, raw_val in rows:
                v = _coerce_value(raw_val)
                if v is not None:
                    idx = oid_str.rsplit(".", 1)[-1]
                    lbl = {"cpu_id": idx, "vendor": "cisco_catalyst"}
                    metrics.append(self._m(metric_name, v, lbl, unit="percent"))
        # Use 1-minute average as canonical cpu.util
        for _, raw_val in walks.get(OIDs.CISCO_CPU_1M, [])[:1]:
            v = _coerce_value(raw_val)
            if v is not None:
                metrics.append(self._m("cpu.util", v, {"vendor": "cisco_catalyst"}, unit="percent"))
                break
        return metrics

    async def collect_memory(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        walks = await self._transport.multi_walk([OIDs.CISCO_MEM_USED, OIDs.CISCO_MEM_FREE])
        used_map = self._transport._index_map(walks, OIDs.CISCO_MEM_USED)
        free_map = self._transport._index_map(walks, OIDs.CISCO_MEM_FREE)

        for idx, used_raw in used_map.items():
            used = _coerce_value(used_raw)
            free = _coerce_value(free_map.get(idx))
            if used is None:
                continue
            lbl = {"pool_id": idx}
            metrics.append(self._m("mem.used", used, lbl, unit="bytes"))
            if free is not None:
                total = used + free
                metrics.append(self._m("mem.free", free, lbl, unit="bytes"))
                metrics.append(self._m("mem.total", total, lbl, unit="bytes"))
                if total > 0:
                    metrics.append(self._m("mem.util", round(used / total * 100, 2), lbl, unit="percent"))
        return metrics

    async def collect_interfaces(self) -> tuple[list[dict], list[dict]]:
        iface_metrics, iface_states = await self._collect_standard_interfaces()
        # Add CDP neighbor discovery
        try:
            cdp_metrics = await self._collect_cdp()
            iface_metrics.extend(cdp_metrics)
        except Exception:
            pass
        return iface_metrics, iface_states

    async def _collect_cdp(self) -> list[dict[str, Any]]:
        """Collect CDP neighbor information for topology mapping."""
        metrics: list[dict] = []
        walks = await self._transport.multi_walk([OIDs.CDP_CACHE_DEVICE_ID, OIDs.CDP_CACHE_DEVICE_PORT])
        device_map = self._transport._index_map(walks, OIDs.CDP_CACHE_DEVICE_ID)
        port_map   = self._transport._index_map(walks, OIDs.CDP_CACHE_DEVICE_PORT)

        for idx, dev_raw in device_map.items():
            neighbor = _coerce_str(dev_raw)
            port = _coerce_str(port_map.get(idx, ""))
            if neighbor:
                lbl = {"if_index": idx, "cdp_neighbor": neighbor, "cdp_neighbor_port": port}
                metrics.append(self._m("cdp.neighbor", 1.0, lbl, "status"))
        return metrics


class GenericSNMPDriver(AbstractSNMPDriver):
    """Fallback driver using only standard MIBs."""
    vendor = "generic"

    async def collect_system(self) -> list[dict[str, Any]]:
        raw = await self._transport.get_scalars([OIDs.SYS_UPTIME])
        metrics: list[dict] = [self._m("sys.up", 1.0, metric_type="status")]
        cs = _coerce_value(raw.get(OIDs.SYS_UPTIME))
        if cs:
            metrics.append(self._m("sys.uptime", cs / 100.0, unit="seconds"))
        return metrics

    async def collect_cpu(self) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        try:
            walks = await self._transport.bulk_walk(OIDs.HR_PROCESSOR_LOAD)
            vals = [_coerce_value(v) for _, v in walks if _coerce_value(v) is not None]
            if vals:
                metrics.append(self._m("cpu.util", round(sum(vals) / len(vals), 2), unit="percent"))
        except Exception:
            pass
        return metrics

    async def collect_memory(self) -> list[dict[str, Any]]:
        return []

    async def collect_interfaces(self) -> tuple[list[dict], list[dict]]:
        return await self._collect_standard_interfaces()


# ── Driver registry ──────────────────────────────────────────────────────────

DRIVER_MAP: dict[str, type[AbstractSNMPDriver]] = {
    "juniper_switch": JuniperDriver,
    "cisco_sg300": CiscoSG300Driver,
    "cisco_catalyst": CiscoCatalystDriver,
    "generic_snmp": GenericSNMPDriver,
    "generic": GenericSNMPDriver,
}


def get_driver(
    device_type: str,
    device_id: UUID,
    host: str,
    credentials: SNMPCredentials,
) -> AbstractSNMPDriver:
    """Instantiate the correct vendor driver for a device type."""
    driver_cls = DRIVER_MAP.get(device_type, GenericSNMPDriver)
    return driver_cls(device_id=device_id, host=host, credentials=credentials)
