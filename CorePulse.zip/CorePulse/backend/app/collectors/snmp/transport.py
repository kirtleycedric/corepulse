"""
CorePulse — Async SNMP polling engine.
Supports SNMPv2c and SNMPv3 with bulk walking and vendor abstraction.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any, Optional
from uuid import UUID

from pysnmp.hlapi.asyncio import (
    CommunityData,
    ContextData,
    ObjectIdentity,
    ObjectType,
    SnmpEngine,
    UdpTransportTarget,
    UsmUserData,
    bulkCmd,
    getCmd,
    usmAesCfb128Protocol,
    usmDESPrivProtocol,
    usmHMACSHAAuthProtocol,
    usmHMACSHA256AuthProtocol,
    usmNoAuthProtocol,
    usmNoPrivProtocol,
)
from pysnmp.proto import rfc1902

from app.core.exceptions import CollectorError
from app.core.logging import get_logger

log = get_logger(__name__)

# Shared SNMP engine — one per process
_SNMP_ENGINE = SnmpEngine()


# ── OID Registry ──────────────────────────────────────────────────────────────

class OIDs:
    # System
    SYS_DESCR     = "1.3.6.1.2.1.1.1.0"
    SYS_OBJECT_ID = "1.3.6.1.2.1.1.2.0"
    SYS_UPTIME    = "1.3.6.1.2.1.1.3.0"
    SYS_NAME      = "1.3.6.1.2.1.1.5.0"

    # IF-MIB
    IF_DESCR         = "1.3.6.1.2.1.2.2.1.2"
    IF_TYPE          = "1.3.6.1.2.1.2.2.1.3"
    IF_SPEED         = "1.3.6.1.2.1.2.2.1.5"
    IF_PHYS_ADDR     = "1.3.6.1.2.1.2.2.1.6"
    IF_ADMIN_STATUS  = "1.3.6.1.2.1.2.2.1.7"
    IF_OPER_STATUS   = "1.3.6.1.2.1.2.2.1.8"
    IF_IN_OCTETS     = "1.3.6.1.2.1.2.2.1.10"
    IF_IN_UCAST      = "1.3.6.1.2.1.2.2.1.11"
    IF_IN_DISCARDS   = "1.3.6.1.2.1.2.2.1.13"
    IF_IN_ERRORS     = "1.3.6.1.2.1.2.2.1.14"
    IF_OUT_OCTETS    = "1.3.6.1.2.1.2.2.1.16"
    IF_OUT_UCAST     = "1.3.6.1.2.1.2.2.1.17"
    IF_OUT_DISCARDS  = "1.3.6.1.2.1.2.2.1.19"
    IF_OUT_ERRORS    = "1.3.6.1.2.1.2.2.1.20"

    # IF-MIB Extensions (64-bit HC counters)
    IF_HC_IN_OCTETS  = "1.3.6.1.2.1.31.1.1.1.6"
    IF_HC_IN_UCAST   = "1.3.6.1.2.1.31.1.1.1.7"
    IF_HC_OUT_OCTETS = "1.3.6.1.2.1.31.1.1.1.10"
    IF_HC_OUT_UCAST  = "1.3.6.1.2.1.31.1.1.1.11"
    IF_HIGH_SPEED    = "1.3.6.1.2.1.31.1.1.1.15"
    IF_ALIAS         = "1.3.6.1.2.1.31.1.1.1.18"

    # Host Resources MIB
    HR_PROCESSOR_LOAD = "1.3.6.1.2.1.25.3.3.1.2"
    HR_STORAGE_SIZE   = "1.3.6.1.2.1.25.2.3.1.5"
    HR_STORAGE_USED   = "1.3.6.1.2.1.25.2.3.1.6"
    HR_STORAGE_ALLOC  = "1.3.6.1.2.1.25.2.3.1.4"

    # Juniper
    JNX_OPERATING_CPU  = "1.3.6.1.4.1.2636.3.1.13.1.8"
    JNX_OPERATING_TEMP = "1.3.6.1.4.1.2636.3.1.13.1.7"
    JNX_OPERATING_BUF  = "1.3.6.1.4.1.2636.3.1.13.1.11"
    JNX_OPERATING_HEAP = "1.3.6.1.4.1.2636.3.1.13.1.12"
    JNX_RE_MEM_TOTAL   = "1.3.6.1.4.1.2636.3.1.3.1.5"
    JNX_RE_MEM_USED    = "1.3.6.1.4.1.2636.3.1.3.1.7"
    JNX_RE_CPU_IDLE    = "1.3.6.1.4.1.2636.3.1.3.1.4"

    # Cisco Process MIB
    CISCO_CPU_5S   = "1.3.6.1.4.1.9.9.109.1.1.1.1.6"
    CISCO_CPU_1M   = "1.3.6.1.4.1.9.9.109.1.1.1.1.7"
    CISCO_CPU_5M   = "1.3.6.1.4.1.9.9.109.1.1.1.1.8"
    CISCO_MEM_USED = "1.3.6.1.4.1.9.9.48.1.1.1.5"
    CISCO_MEM_FREE = "1.3.6.1.4.1.9.9.48.1.1.1.6"

    # Cisco SG300
    SG300_CPU_UTIL  = "1.3.6.1.4.1.9.6.1.84.1.1.0"
    SG300_MEM_TOTAL = "1.3.6.1.4.1.9.6.1.84.1.4.0"
    SG300_MEM_FREE  = "1.3.6.1.4.1.9.6.1.84.1.5.0"

    # LLDP MIB
    LLDP_REM_SYS_NAME  = "1.0.8802.1.1.2.1.4.1.1.9"
    LLDP_REM_PORT_DESCR= "1.0.8802.1.1.2.1.4.1.1.8"

    # CDP MIB (Cisco)
    CDP_CACHE_DEVICE_ID   = "1.3.6.1.4.1.9.9.23.1.2.1.1.6"
    CDP_CACHE_DEVICE_PORT = "1.3.6.1.4.1.9.9.23.1.2.1.1.7"


def _coerce_value(val: Any) -> Optional[float]:
    """Convert pysnmp value types to float. Returns None for non-numeric."""
    type_name = type(val).__name__
    if type_name in ("Integer", "Integer32", "Gauge32", "Counter32",
                     "Counter64", "TimeTicks", "Unsigned32"):
        return float(int(val))
    if type_name == "OctetString":
        try:
            return float(val.prettyPrint().strip())
        except (ValueError, TypeError):
            return None
    if isinstance(val, (int, float)):
        return float(val)
    return None


def _coerce_str(val: Any) -> str:
    try:
        if hasattr(val, "prettyPrint"):
            return val.prettyPrint().strip()
        return str(val).strip()
    except Exception:
        return ""


def _build_auth(version: str, community: str, username: str, auth_proto: str,
                auth_key: str, priv_proto: str, priv_key: str) -> CommunityData | UsmUserData:
    if version == "2c" or version == "v2c":
        return CommunityData(community, mpModel=1)
    if version == "1":
        return CommunityData(community, mpModel=0)

    # v3
    ap = {"SHA": usmHMACSHAAuthProtocol, "SHA256": usmHMACSHA256AuthProtocol}.get(
        auth_proto.upper(), usmHMACSHAAuthProtocol
    )
    pp = {"AES": usmAesCfb128Protocol, "DES": usmDESPrivProtocol}.get(
        priv_proto.upper(), usmAesCfb128Protocol
    )
    if not auth_key:
        return UsmUserData(username, authProtocol=usmNoAuthProtocol, privProtocol=usmNoPrivProtocol)
    if not priv_key:
        return UsmUserData(username, authKey=auth_key, authProtocol=ap, privProtocol=usmNoPrivProtocol)
    return UsmUserData(username, authKey=auth_key, authProtocol=ap, privKey=priv_key, privProtocol=pp)


@dataclass
class SNMPCredentials:
    version: str = "2c"
    community: str = "public"
    username: str = ""
    auth_protocol: str = "SHA"
    auth_key: str = ""
    priv_protocol: str = "AES"
    priv_key: str = ""
    port: int = 161
    timeout: float = 10.0
    retries: int = 2
    bulk_max_repetitions: int = 25


class SNMPTransport:
    """Low-level async SNMP transport using pysnmp asyncio."""

    def __init__(self, host: str, credentials: SNMPCredentials) -> None:
        self._host = host
        self._creds = credentials
        self._auth = _build_auth(
            credentials.version, credentials.community,
            credentials.username, credentials.auth_protocol, credentials.auth_key,
            credentials.priv_protocol, credentials.priv_key,
        )
        self._log = log.bind(host=host)

    def _transport(self) -> UdpTransportTarget:
        per_retry = max(1.0, self._creds.timeout / max(self._creds.retries, 1))
        return UdpTransportTarget(
            (self._host, self._creds.port),
            timeout=per_retry,
            retries=self._creds.retries,
        )

    async def get_scalars(self, oids: list[str]) -> dict[str, Any]:
        """SNMP GET for scalar OIDs. Returns {oid: raw_value}."""
        if not oids:
            return {}
        object_types = [ObjectType(ObjectIdentity(oid)) for oid in oids]
        err_indication, err_status, err_index, var_binds = await getCmd(
            _SNMP_ENGINE, self._auth, self._transport(), ContextData(), *object_types
        )
        if err_indication:
            raise CollectorError(f"SNMP GET error: {err_indication}", retryable=True)
        if err_status:
            raise CollectorError(f"SNMP GET status: {err_status.prettyPrint()}", retryable=False)
        return {str(oid): val for oid, val in var_binds}

    async def bulk_walk(
        self,
        base_oid: str,
        max_rows: int = 2000,
        max_repetitions: int = 25,
    ) -> list[tuple[str, Any]]:
        """SNMP GETBULK walk. Returns list of (oid_str, raw_value)."""
        results: list[tuple[str, Any]] = []
        count = 0
        async for (err_indication, err_status, _, var_bind_table) in bulkCmd(
            _SNMP_ENGINE, self._auth, self._transport(), ContextData(),
            0, max_repetitions,
            ObjectType(ObjectIdentity(base_oid)),
            lexicographicMode=False,
        ):
            if err_indication:
                self._log.warning("snmp.bulk_walk.error", oid=base_oid, error=str(err_indication))
                break
            if err_status:
                self._log.warning("snmp.bulk_walk.status_error", error=err_status.prettyPrint())
                break
            for var_binds in var_bind_table:
                oid_str, val = var_binds
                results.append((str(oid_str), val))
                count += 1
                if count >= max_rows:
                    return results
        return results

    async def multi_walk(self, base_oids: list[str], max_repetitions: int = 25) -> dict[str, list[tuple[str, Any]]]:
        """Walk multiple OID trees concurrently."""
        tasks = [self.bulk_walk(oid, max_repetitions=max_repetitions) for oid in base_oids]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        out: dict[str, list[tuple[str, Any]]] = {}
        for oid, result in zip(base_oids, results):
            if isinstance(result, Exception):
                self._log.warning("snmp.multi_walk.partial_fail", oid=oid, error=str(result))
                out[oid] = []
            else:
                out[oid] = result
        return out

    async def ping(self) -> bool:
        """Quick reachability check via sysDescr GET."""
        try:
            await self.get_scalars([OIDs.SYS_DESCR])
            return True
        except Exception:
            return False

    @staticmethod
    def _index_from_oid(oid_str: str, base_oid: str) -> Optional[str]:
        if oid_str.startswith(base_oid + "."):
            return oid_str[len(base_oid) + 1:]
        return None

    @staticmethod
    def _index_map(walks: dict, base_oid: str) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for oid_str, val in walks.get(base_oid, []):
            idx = SNMPTransport._index_from_oid(oid_str, base_oid)
            if idx:
                result[idx] = val
        return result
