"""
CorePulse — Proxmox VE collector.

Targets Proxmox REST API v2 with API token auth.
Collects: cluster status, node resources, VM/LXC metrics, storage.

API token format: USER@REALM!TOKENID:SECRET
"""
from __future__ import annotations

import asyncio
import ssl
import time
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

import aiohttp
from aiohttp import ClientTimeout, TCPConnector

from app.core.config import get_settings
from app.core.exceptions import CollectorError
from app.core.logging import get_logger

log = get_logger(__name__)

cfg = get_settings()


class ProxmoxAPIClient:
    """
    Async Proxmox VE REST API client.
    Supports API token and password authentication.
    """

    def __init__(
        self,
        host: str,
        port: int = 8006,
        token_id: str = "",
        token_secret: str = "",
        username: str = "",
        password: str = "",
        verify_ssl: bool = False,
        timeout: float = 15.0,
    ) -> None:
        self._base_url = f"https://{host}:{port}/api2/json"
        self._token_id = token_id
        self._token_secret = token_secret
        self._username = username
        self._password = password
        self._verify_ssl = verify_ssl
        self._timeout = timeout
        self._session: Optional[aiohttp.ClientSession] = None
        self._ticket: Optional[str] = None
        self._csrf_token: Optional[str] = None
        self._log = log.bind(host=host, port=port)

    def _auth_headers(self) -> dict[str, str]:
        if self._token_id and self._token_secret:
            return {"Authorization": f"PVEAPIToken={self._token_id}={self._token_secret}"}
        if self._ticket:
            return {
                "Cookie": f"PVEAuthCookie={self._ticket}",
                "CSRFPreventionToken": self._csrf_token or "",
            }
        return {}

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            ssl_ctx: Any = ssl.create_default_context() if self._verify_ssl else False
            connector = TCPConnector(ssl=ssl_ctx, limit=20)
            timeout = ClientTimeout(total=self._timeout, connect=5)
            self._session = aiohttp.ClientSession(
                connector=connector,
                timeout=timeout,
            )
        return self._session

    async def authenticate_password(self) -> None:
        """Authenticate with username/password to get a ticket."""
        session = await self._get_session()
        try:
            async with session.post(
                f"{self._base_url}/access/ticket",
                data={"username": self._username, "password": self._password},
                ssl=self._verify_ssl or False,
            ) as resp:
                if resp.status != 200:
                    raise CollectorError(f"Proxmox auth failed: HTTP {resp.status}", retryable=False)
                data = await resp.json()
                self._ticket = data["data"]["ticket"]
                self._csrf_token = data["data"]["CSRFPreventionToken"]
        except CollectorError:
            raise
        except Exception as exc:
            raise CollectorError(f"Proxmox auth error: {exc}", retryable=True) from exc

    async def _get(self, path: str) -> Any:
        session = await self._get_session()
        url = f"{self._base_url}{path}"
        try:
            async with session.get(url, headers=self._auth_headers(), ssl=self._verify_ssl or False) as resp:
                if resp.status == 401:
                    raise CollectorError("Proxmox: Unauthorized — check credentials", retryable=False)
                if resp.status == 403:
                    raise CollectorError("Proxmox: Forbidden — insufficient permissions", retryable=False)
                if resp.status not in (200, 201):
                    raise CollectorError(f"Proxmox API HTTP {resp.status} at {path}", retryable=True)
                payload = await resp.json()
                return payload.get("data", [])
        except CollectorError:
            raise
        except asyncio.TimeoutError:
            raise CollectorError(f"Proxmox timeout at {path}", retryable=True)
        except aiohttp.ClientConnectionError as exc:
            raise CollectorError(f"Proxmox connection error: {exc}", retryable=True) from exc
        except Exception as exc:
            raise CollectorError(f"Proxmox unexpected error: {exc}", retryable=True) from exc

    async def get_cluster_status(self) -> list[dict[str, Any]]:
        return await self._get("/cluster/status")

    async def get_cluster_resources(self) -> list[dict[str, Any]]:
        return await self._get("/cluster/resources")

    async def get_nodes(self) -> list[dict[str, Any]]:
        return await self._get("/nodes")

    async def get_node_status(self, node: str) -> dict[str, Any]:
        return await self._get(f"/nodes/{node}/status")

    async def get_node_vms(self, node: str) -> list[dict[str, Any]]:
        return await self._get(f"/nodes/{node}/qemu")

    async def get_node_containers(self, node: str) -> list[dict[str, Any]]:
        return await self._get(f"/nodes/{node}/lxc")

    async def get_node_storage(self, node: str) -> list[dict[str, Any]]:
        return await self._get(f"/nodes/{node}/storage")

    async def get_vm_current(self, node: str, vmid: int) -> dict[str, Any]:
        return await self._get(f"/nodes/{node}/qemu/{vmid}/status/current")

    async def get_container_current(self, node: str, vmid: int) -> dict[str, Any]:
        return await self._get(f"/nodes/{node}/lxc/{vmid}/status/current")

    async def get_cluster_ha_status(self) -> dict[str, Any]:
        try:
            return await self._get("/cluster/ha/status/current")
        except CollectorError:
            return {}

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def __aenter__(self) -> "ProxmoxAPIClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


class ProxmoxCollector:
    """
    Polls a Proxmox cluster and returns normalized MetricPoint dicts.
    """

    def __init__(
        self,
        device_id: UUID,
        host: str,
        credentials: dict[str, Any],
        port: int = 8006,
        timeout: float = 15.0,
    ) -> None:
        self._device_id = device_id
        self._host = host
        self._port = port
        self._timeout = timeout
        self._log = log.bind(device_id=str(device_id), host=host)

        self._client = ProxmoxAPIClient(
            host=host,
            port=port,
            token_id=credentials.get("token_id", ""),
            token_secret=credentials.get("token_secret", ""),
            username=credentials.get("username", ""),
            password=credentials.get("password", ""),
            verify_ssl=credentials.get("verify_ssl", False),
            timeout=timeout,
        )

    def _metric(
        self,
        metric: str,
        value: float,
        labels: Optional[dict[str, str]] = None,
        metric_type: str = "gauge",
        unit: str = "",
    ) -> dict[str, Any]:
        return {
            "timestamp": datetime.now(tz=timezone.utc),
            "device_id": self._device_id,
            "metric": metric,
            "value": value,
            "metric_type": metric_type,
            "unit": unit,
            "labels": labels or {},
        }

    async def collect(self) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """
        Full collection run. Returns (metric_records, cluster_state).
        cluster_state contains structured data for upsert to ORM tables.
        """
        t0 = time.perf_counter()
        self._log.info("proxmox.collect.start")
        metrics: list[dict[str, Any]] = []
        cluster_state: dict[str, Any] = {}

        try:
            # Parallel collection
            cluster_data, resources, nodes_data, ha_data = await asyncio.gather(
                self._client.get_cluster_status(),
                self._client.get_cluster_resources(),
                self._client.get_nodes(),
                self._client.get_cluster_ha_status(),
                return_exceptions=True,
            )

            # Cluster-level metrics
            if isinstance(cluster_data, list):
                cluster_state.update(self._parse_cluster_status(cluster_data, metrics))

            # Node-level metrics
            if isinstance(nodes_data, list):
                for node in nodes_data:
                    node_name = node.get("node", "unknown")
                    node_metrics = self._parse_node(node, node_name)
                    metrics.extend(node_metrics)

            # Resource list (VMs, containers, storage)
            if isinstance(resources, list):
                vm_metrics, vm_states = self._parse_resources(resources)
                metrics.extend(vm_metrics)
                cluster_state["vms"] = vm_states

            # HA metrics
            if isinstance(ha_data, dict) and ha_data:
                ha_metrics = self._parse_ha(ha_data)
                metrics.extend(ha_metrics)

            duration = (time.perf_counter() - t0) * 1000
            self._log.info(
                "proxmox.collect.complete",
                metrics=len(metrics),
                duration_ms=round(duration, 1),
            )

        except Exception as exc:
            self._log.error("proxmox.collect.failed", error=str(exc))
            raise CollectorError(str(exc), retryable=True) from exc

        return metrics, cluster_state

    def _parse_cluster_status(
        self, data: list[dict], metrics: list[dict]
    ) -> dict[str, Any]:
        state: dict[str, Any] = {}
        for item in data:
            if item.get("type") == "cluster":
                quorate = int(item.get("quorate", 0))
                node_count = int(item.get("nodes", 0))
                metrics.append(self._metric("cluster.quorate", float(quorate), metric_type="status"))
                metrics.append(self._metric("cluster.node_count", float(node_count)))
                state["cluster_name"] = item.get("name", "")
                state["quorate"] = bool(quorate)
                state["node_count"] = node_count
        return state

    def _parse_node(self, node: dict, node_name: str) -> list[dict[str, Any]]:
        metrics: list[dict[str, Any]] = []
        lbl = {"node": node_name}
        status_val = 1.0 if node.get("status") == "online" else 0.0
        metrics.append(self._metric("node.status", status_val, lbl, "status"))

        cpu = node.get("cpu")
        if cpu is not None:
            metrics.append(self._metric("node.cpu_util", round(float(cpu) * 100, 2), lbl, unit="percent"))

        mem = node.get("mem")
        maxmem = node.get("maxmem")
        if mem is not None:
            metrics.append(self._metric("node.mem_used", float(mem), lbl, unit="bytes"))
        if maxmem is not None:
            metrics.append(self._metric("node.mem_total", float(maxmem), lbl, unit="bytes"))
        if mem and maxmem and maxmem > 0:
            metrics.append(self._metric("node.mem_util", round(mem / maxmem * 100, 2), lbl, unit="percent"))

        disk = node.get("disk")
        maxdisk = node.get("maxdisk")
        if disk is not None:
            metrics.append(self._metric("node.disk_used", float(disk), lbl, unit="bytes"))
        if maxdisk is not None:
            metrics.append(self._metric("node.disk_total", float(maxdisk), lbl, unit="bytes"))

        uptime = node.get("uptime")
        if uptime is not None:
            metrics.append(self._metric("node.uptime", float(uptime), lbl, unit="seconds"))

        netin = node.get("netin")
        netout = node.get("netout")
        if netin is not None:
            metrics.append(self._metric("node.netin", float(netin), lbl, "counter", "bytes"))
        if netout is not None:
            metrics.append(self._metric("node.netout", float(netout), lbl, "counter", "bytes"))

        return metrics

    def _parse_resources(self, resources: list[dict]) -> tuple[list[dict], list[dict]]:
        metrics: list[dict[str, Any]] = []
        vm_states: list[dict[str, Any]] = []

        for res in resources:
            rtype = res.get("type", "")
            if rtype not in ("qemu", "lxc"):
                continue

            vmid = res.get("vmid", 0)
            name = res.get("name", str(vmid))
            node = res.get("node", "")
            lbl = {"vmid": str(vmid), "name": name, "node": node, "type": rtype}

            status_val = 1.0 if res.get("status") == "running" else 0.0
            metrics.append(self._metric(f"{rtype}.status", status_val, lbl, "status"))

            cpu = res.get("cpu")
            if cpu is not None:
                metrics.append(self._metric(f"{rtype}.cpu_util", round(float(cpu) * 100, 2), lbl, unit="percent"))

            mem = res.get("mem")
            maxmem = res.get("maxmem")
            if mem is not None:
                metrics.append(self._metric(f"{rtype}.mem_used", float(mem), lbl, unit="bytes"))
            if maxmem is not None:
                metrics.append(self._metric(f"{rtype}.mem_total", float(maxmem), lbl, unit="bytes"))
            if mem and maxmem and maxmem > 0:
                metrics.append(self._metric(f"{rtype}.mem_util", round(mem / maxmem * 100, 2), lbl, unit="percent"))

            disk = res.get("disk")
            maxdisk = res.get("maxdisk")
            if disk is not None:
                metrics.append(self._metric(f"{rtype}.disk_used", float(disk), lbl, unit="bytes"))
            if maxdisk is not None:
                metrics.append(self._metric(f"{rtype}.disk_total", float(maxdisk), lbl, unit="bytes"))

            for field, metric_name, unit in [
                ("netin", f"{rtype}.netin", "bytes"),
                ("netout", f"{rtype}.netout", "bytes"),
                ("diskread", f"{rtype}.disk_read", "bytes"),
                ("diskwrite", f"{rtype}.disk_write", "bytes"),
            ]:
                val = res.get(field)
                if val is not None:
                    metrics.append(self._metric(metric_name, float(val), lbl, "counter", unit))

            vm_states.append({
                "vmid": vmid,
                "vm_name": name,
                "vm_type": rtype,
                "status": res.get("status", "unknown"),
                "node": node,
                "cpu_util": float(cpu or 0) * 100,
                "mem_total_bytes": maxmem or 0,
                "mem_used_bytes": mem or 0,
                "disk_total_bytes": maxdisk or 0,
                "disk_used_bytes": disk or 0,
                "uptime_seconds": res.get("uptime", 0) or 0,
                "ha_managed": bool(res.get("hastate")),
                "ha_state": res.get("hastate"),
            })

        return metrics, vm_states

    def _parse_ha(self, ha_data: dict) -> list[dict[str, Any]]:
        metrics: list[dict[str, Any]] = []
        quorum_ok = ha_data.get("quorum", {}).get("quorate", 0)
        metrics.append(self._metric("ha.quorate", float(quorum_ok), metric_type="status"))
        return metrics

    async def close(self) -> None:
        await self._client.close()
