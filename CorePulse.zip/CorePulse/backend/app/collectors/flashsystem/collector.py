"""
CorePulse — IBM FlashSystem 9100 REST API collector.

IBM FlashSystem 9100 exposes a RESTful management API on port 7443.
Auth: username/password → session token (reused until expiry).
API base: /rest/v1/

Key collections:
  - system stats (overall I/O)
  - mdiskgroups (storage pools)
  - volumes
  - drives
  - nodes (controllers)
"""
from __future__ import annotations

import asyncio
import ssl
import time
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

import aiohttp

from app.core.exceptions import CollectorError
from app.core.logging import get_logger

log = get_logger(__name__)


class FlashSystemAPIClient:
    """
    Async client for IBM FlashSystem 9100 REST API.
    Handles session-based authentication and automatic re-auth.
    """

    API_BASE = "/rest/v1"

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int = 7443,
        verify_ssl: bool = False,
        timeout: float = 15.0,
    ) -> None:
        self._host = host
        self._port = port
        self._username = username
        self._password = password
        self._verify_ssl = verify_ssl
        self._timeout = timeout
        self._token: Optional[str] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._log = log.bind(host=host, port=port)

    @property
    def _base_url(self) -> str:
        return f"https://{self._host}:{self._port}{self.API_BASE}"

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            ssl_ctx: Any = ssl.create_default_context() if self._verify_ssl else False
            connector = aiohttp.TCPConnector(ssl=ssl_ctx, limit=10)
            timeout = aiohttp.ClientTimeout(total=self._timeout, connect=5)
            self._session = aiohttp.ClientSession(connector=connector, timeout=timeout)
        return self._session

    async def authenticate(self) -> None:
        """Authenticate and store session token."""
        session = await self._get_session()
        try:
            async with session.post(
                f"{self._base_url}/auth",
                json={"username": self._username, "password": self._password},
                ssl=self._verify_ssl or False,
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self._token = data.get("token") or resp.headers.get("X-Auth-Token")
                    if not self._token:
                        raise CollectorError("FlashSystem: No auth token in response", retryable=False)
                elif resp.status == 401:
                    raise CollectorError("FlashSystem: Invalid credentials", retryable=False)
                else:
                    raise CollectorError(f"FlashSystem: Auth failed HTTP {resp.status}", retryable=True)
        except CollectorError:
            raise
        except Exception as exc:
            raise CollectorError(f"FlashSystem auth error: {exc}", retryable=True) from exc

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        session = await self._get_session()
        if not self._token:
            await self.authenticate()

        headers = {"X-Auth-Token": self._token or "", "Content-Type": "application/json"}
        url = f"{self._base_url}{path}"

        for attempt in range(2):
            try:
                async with session.request(
                    method, url, headers=headers, ssl=self._verify_ssl or False, **kwargs
                ) as resp:
                    if resp.status == 401 and attempt == 0:
                        # Token expired — re-authenticate
                        self._token = None
                        await self.authenticate()
                        headers["X-Auth-Token"] = self._token or ""
                        continue
                    if resp.status == 404:
                        return []
                    if resp.status not in (200, 201, 204):
                        raise CollectorError(
                            f"FlashSystem HTTP {resp.status} at {path}", retryable=resp.status >= 500
                        )
                    if resp.status == 204:
                        return {}
                    return await resp.json()
            except CollectorError:
                raise
            except asyncio.TimeoutError:
                raise CollectorError(f"FlashSystem timeout: {path}", retryable=True)
            except aiohttp.ClientConnectionError as exc:
                raise CollectorError(f"FlashSystem connection: {exc}", retryable=True) from exc
        return []

    async def get_system_stats(self) -> dict[str, Any]:
        return await self._request("GET", "/iostats/drive/0")

    async def get_system_info(self) -> dict[str, Any]:
        return await self._request("GET", "/system")

    async def get_mdiskgroups(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/mdiskgroup")

    async def get_volumes(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/vdisk")

    async def get_volume_stats(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/iostats/vdisk/0")

    async def get_drives(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/drive")

    async def get_nodes(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/node")

    async def get_node_stats(self) -> list[dict[str, Any]]:
        return await self._request("GET", "/iostats/node/0")

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()


class FlashSystemCollector:
    """
    Collects metrics from IBM FlashSystem 9100 and returns normalized records.
    """

    def __init__(
        self,
        device_id: UUID,
        host: str,
        credentials: dict[str, Any],
        port: int = 7443,
        timeout: float = 15.0,
    ) -> None:
        self._device_id = device_id
        self._host = host
        self._log = log.bind(device_id=str(device_id), host=host)

        self._client = FlashSystemAPIClient(
            host=host,
            username=credentials.get("username", ""),
            password=credentials.get("password", ""),
            port=port,
            verify_ssl=credentials.get("verify_ssl", False),
            timeout=timeout,
        )

    def _metric(
        self,
        metric: str,
        value: float,
        labels: Optional[dict[str, str]] = None,
        metric_type: str = "gauge",
        unit: str = "",
    ) -> dict[str, Any]:
        return {
            "timestamp": datetime.now(tz=timezone.utc),
            "device_id": self._device_id,
            "metric": metric,
            "value": value,
            "metric_type": metric_type,
            "unit": unit,
            "labels": labels or {},
        }

    async def collect(self) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """
        Full collection run. Returns (metric_records, array_state).
        """
        t0 = time.perf_counter()
        self._log.info("flashsystem.collect.start")
        metrics: list[dict[str, Any]] = []
        array_state: dict[str, Any] = {}

        try:
            # Parallel data collection
            sys_info, pool_data, vol_data, vol_stats, drive_data, node_data, node_stats = (
                await asyncio.gather(
                    self._client.get_system_info(),
                    self._client.get_mdiskgroups(),
                    self._client.get_volumes(),
                    self._client.get_volume_stats(),
                    self._client.get_drives(),
                    self._client.get_nodes(),
                    self._client.get_node_stats(),
                    return_exceptions=True,
                )
            )

            # System-level metrics
            if isinstance(sys_info, dict) and sys_info:
                sys_metrics = self._parse_system_info(sys_info)
                metrics.extend(sys_metrics)
                array_state["system"] = self._extract_system_state(sys_info)

            # Pool metrics
            if isinstance(pool_data, list):
                pool_metrics, pool_states = self._parse_pools(pool_data)
                metrics.extend(pool_metrics)
                array_state["pools"] = pool_states

            # Volume metrics
            if isinstance(vol_data, list):
                vol_metrics = self._parse_volumes(vol_data)
                metrics.extend(vol_metrics)

            # Volume I/O stats
            if isinstance(vol_stats, list):
                vstats_metrics = self._parse_volume_stats(vol_stats)
                metrics.extend(vstats_metrics)

            # Drive health
            if isinstance(drive_data, list):
                drive_metrics = self._parse_drives(drive_data)
                metrics.extend(drive_metrics)

            # Node/controller metrics
            if isinstance(node_data, list):
                node_metrics = self._parse_nodes(node_data)
                metrics.extend(node_metrics)

            if isinstance(node_stats, list):
                node_stat_metrics = self._parse_node_stats(node_stats)
                metrics.extend(node_stat_metrics)

            duration_ms = (time.perf_counter() - t0) * 1000
            self._log.info("flashsystem.collect.complete", metrics=len(metrics), duration_ms=round(duration_ms, 1))

        except Exception as exc:
            self._log.error("flashsystem.collect.failed", error=str(exc))
            raise CollectorError(str(exc), retryable=True) from exc

        return metrics, array_state

    def _parse_system_info(self, info: dict) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        # Capacity
        total_cap = self._to_bytes(info.get("total_mdisk_capacity", "0"))
        used_cap  = self._to_bytes(info.get("used_capacity", "0"))
        free_cap  = total_cap - used_cap
        metrics.append(self._metric("storage.total_capacity", float(total_cap), unit="bytes"))
        metrics.append(self._metric("storage.used_capacity",  float(used_cap),  unit="bytes"))
        metrics.append(self._metric("storage.free_capacity",  float(free_cap),  unit="bytes"))
        if total_cap > 0:
            util = round(used_cap / total_cap * 100, 2)
            metrics.append(self._metric("storage.util", util, unit="percent"))

        # Virtual capacity
        virt_total = self._to_bytes(info.get("total_vdiskcopy_capacity", "0"))
        virt_used  = self._to_bytes(info.get("total_used_capacity", "0"))
        metrics.append(self._metric("storage.virtual_total",  float(virt_total), unit="bytes"))
        metrics.append(self._metric("storage.virtual_used",   float(virt_used),  unit="bytes"))

        # Compression/dedupe savings
        savings = self._safe_float(info.get("data_reduction_savings"))
        if savings:
            metrics.append(self._metric("storage.data_reduction_savings", savings, unit="bytes"))

        return metrics

    def _extract_system_state(self, info: dict) -> dict[str, Any]:
        return {
            "array_name": info.get("name", ""),
            "model": info.get("product_name", ""),
            "code_level": info.get("code_level", ""),
            "total_capacity_bytes": self._to_bytes(info.get("total_mdisk_capacity", "0")),
            "used_capacity_bytes":  self._to_bytes(info.get("used_capacity", "0")),
            "status": "degraded" if info.get("degraded", "no") == "yes" else "online",
        }

    def _parse_pools(self, pools: list[dict]) -> tuple[list[dict], list[dict]]:
        metrics: list[dict] = []
        states: list[dict] = []
        for pool in pools:
            name = pool.get("name", "")
            pid  = pool.get("id", "")
            lbl  = {"pool_name": name, "pool_id": pid}
            status = pool.get("status", "offline")

            metrics.append(self._metric("pool.status", 1.0 if status == "online" else 0.0, lbl, "status"))

            total   = self._to_bytes(pool.get("capacity", "0"))
            used    = self._to_bytes(pool.get("used_capacity", "0"))
            free    = self._to_bytes(pool.get("free_capacity", "0"))

            if total > 0:
                metrics.append(self._metric("pool.capacity",      float(total), lbl, unit="bytes"))
                metrics.append(self._metric("pool.used_capacity", float(used),  lbl, unit="bytes"))
                metrics.append(self._metric("pool.free_capacity", float(free),  lbl, unit="bytes"))
                metrics.append(self._metric("pool.util",          round(used / total * 100, 2), lbl, unit="percent"))

            comp_ratio = self._safe_float(pool.get("compression_ratio", "1.0")) or 1.0
            metrics.append(self._metric("pool.compression_ratio", comp_ratio, lbl))

            states.append({
                "pool_id": str(pid),
                "pool_name": name,
                "status": status,
                "capacity_bytes":      total,
                "used_capacity_bytes": used,
                "free_capacity_bytes": free,
                "compression_ratio":   comp_ratio,
                "drive_count":         int(pool.get("drive_count", 0) or 0),
                "mdisk_count":         int(pool.get("mdisk_count", 0) or 0),
            })

        return metrics, states

    def _parse_volumes(self, volumes: list[dict]) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        for vol in volumes:
            name = vol.get("name", "")
            vid  = vol.get("id", "")
            lbl  = {"volume_name": name, "volume_id": vid}
            status = vol.get("status", "offline")
            metrics.append(self._metric("volume.status", 1.0 if status == "online" else 0.0, lbl, "status"))

            capacity = self._to_bytes(vol.get("capacity", "0"))
            used     = self._to_bytes(vol.get("used_capacity", "0"))
            if capacity > 0:
                metrics.append(self._metric("volume.capacity",      float(capacity), lbl, unit="bytes"))
                metrics.append(self._metric("volume.used_capacity", float(used),     lbl, unit="bytes"))
                metrics.append(self._metric("volume.util",          round(used / capacity * 100, 2), lbl, unit="percent"))

        return metrics

    def _parse_volume_stats(self, stats: list[dict]) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        for stat in stats:
            vid  = str(stat.get("id", ""))
            name = str(stat.get("name", vid))
            lbl  = {"volume_id": vid, "volume_name": name}

            for field, metric_name, unit in [
                ("ro_bytes",    "volume.read_bytes",    "bytes"),
                ("wo_bytes",    "volume.write_bytes",   "bytes"),
                ("ro_ios",      "volume.read_iops",     "iops"),
                ("wo_ios",      "volume.write_iops",    "iops"),
                ("r_ms",        "volume.read_latency",  "ms"),
                ("w_ms",        "volume.write_latency", "ms"),
            ]:
                v = self._safe_float(stat.get(field))
                if v is not None:
                    metrics.append(self._metric(metric_name, v, lbl, unit=unit))

        return metrics

    def _parse_drives(self, drives: list[dict]) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        total = len(drives)
        degraded = sum(1 for d in drives if d.get("status", "") not in ("online", "member"))
        metrics.append(self._metric("drive.total_count",   float(total),   unit="count"))
        metrics.append(self._metric("drive.degraded_count", float(degraded), unit="count"))

        for drive in drives:
            did  = str(drive.get("id", ""))
            lbl  = {"drive_id": did, "drive_class": drive.get("drive_class", ""), "mdisk_id": str(drive.get("mdisk_id", ""))}
            status = drive.get("status", "offline")
            metrics.append(self._metric("drive.status", 1.0 if status in ("online", "member") else 0.0, lbl, "status"))

            temp = self._safe_float(drive.get("temperature"))
            if temp and temp > 0:
                metrics.append(self._metric("drive.temperature", temp, lbl, unit="celsius"))

        return metrics

    def _parse_nodes(self, nodes: list[dict]) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        for node in nodes:
            nid   = str(node.get("id", ""))
            name  = node.get("name", nid)
            lbl   = {"node_id": nid, "node_name": name}
            status = node.get("status", "offline")
            metrics.append(self._metric("node.status", 1.0 if status == "online" else 0.0, lbl, "status"))

        return metrics

    def _parse_node_stats(self, stats: list[dict]) -> list[dict[str, Any]]:
        metrics: list[dict] = []
        for stat in stats:
            nid  = str(stat.get("node_id", ""))
            lbl  = {"node_id": nid}
            for field, metric_name, unit in [
                ("ro_bytes",     "node.read_bytes",       "bytes"),
                ("wo_bytes",     "node.write_bytes",      "bytes"),
                ("ro_ios",       "node.read_iops",        "iops"),
                ("wo_ios",       "node.write_iops",       "iops"),
                ("r_ms",         "node.read_latency",     "ms"),
                ("w_ms",         "node.write_latency",    "ms"),
                ("cpu_pc",       "node.cpu_util",         "percent"),
                ("fc_mbps",      "node.fc_bandwidth",     "mbps"),
            ]:
                v = self._safe_float(stat.get(field))
                if v is not None:
                    metrics.append(self._metric(metric_name, v, lbl, unit=unit))

        return metrics

    @staticmethod
    def _to_bytes(value: Any) -> int:
        """Convert IBM capacity strings (e.g. '1.50 TB') to bytes."""
        if not value:
            return 0
        s = str(value).strip().upper()
        multipliers = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3,
                       "TB": 1024**4, "PB": 1024**5}
        for suffix, mult in sorted(multipliers.items(), key=lambda x: -len(x[0])):
            if s.endswith(suffix):
                try:
                    num = float(s[:-len(suffix)].strip())
                    return int(num * mult)
                except ValueError:
                    return 0
        try:
            return int(float(s))
        except ValueError:
            return 0

    @staticmethod
    def _safe_float(value: Any) -> Optional[float]:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    async def close(self) -> None:
        await self._client.close()
