"""
CorePulse — Complete SQLAlchemy ORM models.
All tables defined here with full relationships.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    BigInteger, Boolean, DateTime, Double, Enum, Float,
    ForeignKey, Index, Integer, Numeric, SmallInteger,
    String, Text, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.core.database import Base


# ── Users & Auth ──────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(256), nullable=False, default="")
    hashed_password: Mapped[str] = mapped_column(String(256), nullable=False)
    role: Mapped[str] = mapped_column(String(32), nullable=False, default="viewer")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    is_superuser: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    dashboards: Mapped[list["Dashboard"]] = relationship("Dashboard", back_populates="owner", passive_deletes=True)
    audit_logs: Mapped[list["AuditLog"]] = relationship("AuditLog", back_populates="user", passive_deletes=True)
    notification_channels: Mapped[list["NotificationChannel"]] = relationship(
        "NotificationChannel", back_populates="created_by_user", passive_deletes=True
    )


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    jti: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


# ── Credentials ───────────────────────────────────────────────────────────────

class CredentialProfile(Base):
    """Encrypted credential store for device access."""
    __tablename__ = "credential_profiles"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    protocol: Mapped[str] = mapped_column(String(32), nullable=False)  # snmp_v2c, snmp_v3, api_token, ssh, rest
    # Encrypted credential data (AES-256 encrypted JSON blob)
    credentials_enc: Mapped[str] = mapped_column(Text, nullable=False)
    created_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    devices: Mapped[list["Device"]] = relationship("Device", back_populates="credential_profile")


# ── Devices ───────────────────────────────────────────────────────────────────

class Device(Base):
    __tablename__ = "devices"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    device_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    # Types: proxmox_cluster, proxmox_node, vm, container, flashsystem,
    #        juniper_switch, cisco_sg300, cisco_catalyst, generic_snmp
    host: Mapped[str] = mapped_column(String(255), nullable=False)
    port: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, index=True)
    poll_interval_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=60)
    credential_profile_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("credential_profiles.id", ondelete="SET NULL"), nullable=True
    )
    location: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    site: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    tags: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    metadata_: Mapped[dict] = mapped_column("metadata", JSONB, nullable=False, default=dict)
    # Discovery info
    sys_descr: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    sys_object_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    sys_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    firmware_version: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    model: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    vendor: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    serial_number: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    # Status tracking
    last_seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_poll_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_poll_status: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    consecutive_failures: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # Hierarchy
    parent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    credential_profile: Mapped[Optional[CredentialProfile]] = relationship(
        "CredentialProfile", back_populates="devices"
    )
    children: Mapped[list["Device"]] = relationship("Device", back_populates="parent")
    parent: Mapped[Optional["Device"]] = relationship("Device", back_populates="children", remote_side=[id])
    interfaces: Mapped[list["DeviceInterface"]] = relationship("DeviceInterface", back_populates="device", passive_deletes=True)
    alert_rules: Mapped[list["AlertRule"]] = relationship("AlertRule", back_populates="device", passive_deletes=True)

    __table_args__ = (
        UniqueConstraint("host", "device_type", name="uq_device_host_type"),
        Index("ix_devices_type_enabled", "device_type", "enabled"),
    )


class DeviceInterface(Base):
    """Network interface / port discovered on a device."""
    __tablename__ = "device_interfaces"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, index=True
    )
    if_index: Mapped[int] = mapped_column(Integer, nullable=False)
    if_name: Mapped[str] = mapped_column(String(128), nullable=False)
    if_alias: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    if_descr: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    if_type: Mapped[int] = mapped_column(Integer, nullable=False, default=6)  # 6=ethernetCsmacd
    if_speed_bps: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    if_phys_addr: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    if_admin_status: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=1)
    if_oper_status: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=2)
    vlan_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    lldp_neighbor: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    lldp_neighbor_port: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    cdp_neighbor: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    enabled_monitoring: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    device: Mapped[Device] = relationship("Device", back_populates="interfaces")

    __table_args__ = (
        UniqueConstraint("device_id", "if_index", name="uq_interface_device_ifindex"),
    )


# ── Metrics (TimescaleDB hypertable) ─────────────────────────────────────────

class MetricRecord(Base):
    """
    Time-series metric storage. This table is converted to a TimescaleDB
    hypertable partitioned on `timestamp`. Do NOT add composite unique
    constraints — they conflict with TimescaleDB chunk creation.
    """
    __tablename__ = "metric_records"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False
    )
    metric: Mapped[str] = mapped_column(String(255), nullable=False)
    value: Mapped[float] = mapped_column(Double, nullable=False)
    metric_type: Mapped[str] = mapped_column(String(32), nullable=False, default="gauge")
    unit: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    labels: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)

    __table_args__ = (
        Index("ix_metric_records_device_metric_time", "device_id", "metric", "timestamp"),
    )


# ── Proxmox ───────────────────────────────────────────────────────────────────

class ProxmoxCluster(Base):
    __tablename__ = "proxmox_clusters"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    cluster_name: Mapped[str] = mapped_column(String(128), nullable=False)
    quorate: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    node_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    ha_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    pve_version: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )


class ProxmoxNode(Base):
    __tablename__ = "proxmox_nodes"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    cluster_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("proxmox_clusters.id", ondelete="SET NULL"), nullable=True
    )
    node_name: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="unknown")
    # Current resource state
    cpu_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    cpu_util: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    mem_total_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    mem_used_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    disk_total_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    disk_used_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    uptime_seconds: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    pve_version: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )


class VirtualMachine(Base):
    __tablename__ = "virtual_machines"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    node_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("proxmox_nodes.id", ondelete="SET NULL"), nullable=True
    )
    vmid: Mapped[int] = mapped_column(Integer, nullable=False)
    vm_name: Mapped[str] = mapped_column(String(255), nullable=False)
    vm_type: Mapped[str] = mapped_column(String(16), nullable=False, default="qemu")  # qemu | lxc
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="unknown")
    cpu_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    cpu_util: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    mem_total_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    mem_used_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    disk_total_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    disk_used_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    netin_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    netout_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    uptime_seconds: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    ha_managed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    ha_state: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    template: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    tags: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )


# ── IBM FlashSystem ───────────────────────────────────────────────────────────

class FlashSystemArray(Base):
    __tablename__ = "flashsystem_arrays"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    array_name: Mapped[str] = mapped_column(String(128), nullable=False)
    model: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    code_level: Mapped[str] = mapped_column(String(32), nullable=False, default="")
    location: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    # Aggregate capacity
    total_capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    used_capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    free_capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    # I/O stats (latest)
    read_iops: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    write_iops: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    read_bandwidth_mbps: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    write_bandwidth_mbps: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    read_latency_us: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    write_latency_us: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="unknown")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    pools: Mapped[list["FlashSystemPool"]] = relationship("FlashSystemPool", back_populates="array", passive_deletes=True)
    volumes: Mapped[list["FlashSystemVolume"]] = relationship("FlashSystemVolume", back_populates="array", passive_deletes=True)


class FlashSystemPool(Base):
    __tablename__ = "flashsystem_pools"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    array_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("flashsystem_arrays.id", ondelete="CASCADE"), nullable=False, index=True
    )
    pool_id: Mapped[str] = mapped_column(String(64), nullable=False)
    pool_name: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="online")
    capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    used_capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    free_capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    overallocation_pct: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    compression_ratio: Mapped[float] = mapped_column(Double, nullable=False, default=1.0)
    dedupe_ratio: Mapped[float] = mapped_column(Double, nullable=False, default=1.0)
    drive_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    mdisk_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    array: Mapped[FlashSystemArray] = relationship("FlashSystemArray", back_populates="pools")

    __table_args__ = (
        UniqueConstraint("array_id", "pool_id", name="uq_pool_array_poolid"),
    )


class FlashSystemVolume(Base):
    __tablename__ = "flashsystem_volumes"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    array_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("flashsystem_arrays.id", ondelete="CASCADE"), nullable=False, index=True
    )
    pool_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("flashsystem_pools.id", ondelete="SET NULL"), nullable=True
    )
    volume_id: Mapped[str] = mapped_column(String(64), nullable=False)
    volume_name: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="online")
    capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    used_capacity_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    read_iops: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    write_iops: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    read_bandwidth_mbps: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    write_bandwidth_mbps: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    read_latency_us: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    write_latency_us: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    throttle_pct: Mapped[float] = mapped_column(Double, nullable=False, default=0.0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    array: Mapped[FlashSystemArray] = relationship("FlashSystemArray", back_populates="volumes")

    __table_args__ = (
        UniqueConstraint("array_id", "volume_id", name="uq_volume_array_volid"),
    )


# ── Alerting ──────────────────────────────────────────────────────────────────

class AlertRule(Base):
    __tablename__ = "alert_rules"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    device_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("devices.id", ondelete="CASCADE"), nullable=True
    )
    # Selector — can target by device_type or tag
    device_type_filter: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    tag_filter: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    # Condition
    metric: Mapped[str] = mapped_column(String(255), nullable=False)
    condition_type: Mapped[str] = mapped_column(String(32), nullable=False)  # threshold | anomaly | state
    condition_config: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    # e.g. {"operator": ">", "threshold": 90, "for_seconds": 120}
    severity: Mapped[str] = mapped_column(String(16), nullable=False, default="warning")  # info|warning|critical
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    cooldown_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=300)
    notification_channel_ids: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    # Maintenance windows
    maintenance_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    device: Mapped[Optional[Device]] = relationship("Device", back_populates="alert_rules")
    incidents: Mapped[list["AlertIncident"]] = relationship("AlertIncident", back_populates="rule", passive_deletes=True)


class AlertIncident(Base):
    __tablename__ = "alert_incidents"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("alert_rules.id", ondelete="CASCADE"), nullable=False, index=True
    )
    device_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    metric: Mapped[str] = mapped_column(String(255), nullable=False)
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="firing")  # firing|resolved|suppressed
    trigger_value: Mapped[float] = mapped_column(Double, nullable=False)
    trigger_labels: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    message: Mapped[str] = mapped_column(Text, nullable=False, default="")
    triggered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledged: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    acknowledged_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notification_sent: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    notification_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    rule: Mapped[AlertRule] = relationship("AlertRule", back_populates="incidents")

    __table_args__ = (
        Index("ix_incidents_status_time", "status", "triggered_at"),
    )


# ── Notifications ─────────────────────────────────────────────────────────────

class NotificationChannel(Base):
    __tablename__ = "notification_channels"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    channel_type: Mapped[str] = mapped_column(String(32), nullable=False)  # email|slack|teams|telegram|webhook
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    config_enc: Mapped[str] = mapped_column(Text, nullable=False)  # encrypted config
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    created_by_user: Mapped[Optional[User]] = relationship("User", back_populates="notification_channels")


# ── Dashboards ────────────────────────────────────────────────────────────────

class Dashboard(Base):
    __tablename__ = "dashboards"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    owner_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    is_public: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_template: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_starred: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # react-grid-layout compatible JSON
    layout: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    # {widgets: [{id, type, x, y, w, h, config: {...}}]}
    variables: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    time_range: Mapped[str] = mapped_column(String(32), nullable=False, default="1h")
    refresh_interval_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=30)
    tags: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    slug: Mapped[str] = mapped_column(String(128), nullable=False, unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    owner: Mapped[Optional[User]] = relationship("User", back_populates="dashboards")


# ── Audit Log ─────────────────────────────────────────────────────────────────

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    action: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    resource_type: Mapped[str] = mapped_column(String(64), nullable=False)
    resource_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    old_value: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    new_value: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    result: Mapped[str] = mapped_column(String(16), nullable=False, default="success")
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )

    user: Mapped[Optional[User]] = relationship("User", back_populates="audit_logs")
