"""
CorePulse — Pydantic v2 schemas for all API endpoints.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


# ── Shared ────────────────────────────────────────────────────────────────────

class OrmBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class PaginatedResponse(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[Any]


# ── Auth ──────────────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class RefreshRequest(BaseModel):
    refresh_token: str


# ── Users ─────────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[a-zA-Z0-9_-]+$")
    email: EmailStr
    full_name: str = Field(default="", max_length=256)
    password: str = Field(min_length=8, max_length=128)
    role: str = Field(default="viewer")
    is_superuser: bool = False

    @field_validator("role")
    @classmethod
    def validate_role(cls, v: str) -> str:
        valid = {"viewer", "operator", "engineer", "admin"}
        if v not in valid:
            raise ValueError(f"Role must be one of: {valid}")
        return v


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, max_length=256)
    email: Optional[EmailStr] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None
    password: Optional[str] = Field(default=None, min_length=8, max_length=128)


class UserResponse(OrmBase):
    id: uuid.UUID
    username: str
    email: str
    full_name: str
    role: str
    is_active: bool
    is_superuser: bool
    last_login_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime


# ── Devices ───────────────────────────────────────────────────────────────────

class DeviceCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    display_name: str = Field(default="", max_length=255)
    device_type: str
    host: str = Field(min_length=1, max_length=255)
    port: Optional[int] = Field(default=None, ge=1, le=65535)
    enabled: bool = True
    poll_interval_seconds: int = Field(default=60, ge=10, le=86400)
    credential_profile_id: Optional[uuid.UUID] = None
    location: str = Field(default="", max_length=255)
    site: str = Field(default="", max_length=128)
    tags: dict[str, str] = Field(default_factory=dict)
    metadata_: dict[str, Any] = Field(default_factory=dict, alias="metadata")
    parent_id: Optional[uuid.UUID] = None

    @field_validator("device_type")
    @classmethod
    def validate_device_type(cls, v: str) -> str:
        valid = {
            "proxmox_cluster", "proxmox_node", "vm", "container",
            "flashsystem", "juniper_switch", "cisco_sg300",
            "cisco_catalyst", "generic_snmp", "generic",
        }
        if v not in valid:
            raise ValueError(f"device_type must be one of: {valid}")
        return v


class DeviceUpdate(BaseModel):
    name: Optional[str] = Field(default=None, max_length=255)
    display_name: Optional[str] = Field(default=None, max_length=255)
    host: Optional[str] = None
    port: Optional[int] = Field(default=None, ge=1, le=65535)
    enabled: Optional[bool] = None
    poll_interval_seconds: Optional[int] = Field(default=None, ge=10, le=86400)
    credential_profile_id: Optional[uuid.UUID] = None
    location: Optional[str] = None
    site: Optional[str] = None
    tags: Optional[dict[str, str]] = None


class DeviceResponse(OrmBase):
    id: uuid.UUID
    name: str
    display_name: str
    device_type: str
    host: str
    port: Optional[int]
    enabled: bool
    poll_interval_seconds: int
    location: str
    site: str
    tags: dict
    vendor: Optional[str]
    model: Optional[str]
    firmware_version: Optional[str]
    sys_name: Optional[str]
    last_seen_at: Optional[datetime]
    last_poll_at: Optional[datetime]
    last_poll_status: Optional[str]
    consecutive_failures: int
    created_at: datetime
    updated_at: datetime


class DeviceInterfaceResponse(OrmBase):
    id: uuid.UUID
    device_id: uuid.UUID
    if_index: int
    if_name: str
    if_alias: str
    if_descr: str
    if_speed_bps: int
    if_phys_addr: str
    if_admin_status: int
    if_oper_status: int
    vlan_id: Optional[int]
    lldp_neighbor: Optional[str]
    lldp_neighbor_port: Optional[str]
    enabled_monitoring: bool
    updated_at: datetime


# ── Metrics ───────────────────────────────────────────────────────────────────

class MetricQueryRequest(BaseModel):
    device_id: Optional[uuid.UUID] = None
    metric: Optional[str] = None
    metric_prefix: Optional[str] = None
    from_ts: Optional[datetime] = None
    to_ts: Optional[datetime] = None
    labels: Optional[dict[str, str]] = None
    aggregation: str = Field(default="avg")  # avg|max|min|sum|last
    bucket_interval: str = Field(default="5m")  # 1m|5m|1h|1d
    limit: int = Field(default=1000, le=10000)


class MetricPoint(BaseModel):
    timestamp: datetime
    value: float
    labels: dict[str, str] = Field(default_factory=dict)


class MetricSeries(BaseModel):
    device_id: uuid.UUID
    metric: str
    unit: str
    data: list[MetricPoint]


class DeviceSummaryMetrics(BaseModel):
    device_id: uuid.UUID
    timestamp: datetime
    cpu_util: Optional[float] = None
    mem_util: Optional[float] = None
    disk_util: Optional[float] = None
    uptime_seconds: Optional[int] = None
    status: str = "unknown"


# ── Credential Profiles ───────────────────────────────────────────────────────

class CredentialProfileCreate(BaseModel):
    name: str = Field(min_length=1, max_length=128)
    description: str = Field(default="", max_length=1024)
    protocol: str
    credentials: dict[str, Any]  # Will be encrypted before storage

    @field_validator("protocol")
    @classmethod
    def validate_protocol(cls, v: str) -> str:
        valid = {"snmp_v2c", "snmp_v3", "api_token", "ssh", "rest_basic", "rest_bearer"}
        if v not in valid:
            raise ValueError(f"protocol must be one of: {valid}")
        return v


class CredentialProfileResponse(OrmBase):
    id: uuid.UUID
    name: str
    description: str
    protocol: str
    created_at: datetime
    updated_at: datetime
    # Note: credentials_enc is never exposed


# ── Alert Rules ───────────────────────────────────────────────────────────────

class AlertRuleCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str = Field(default="", max_length=1024)
    device_id: Optional[uuid.UUID] = None
    device_type_filter: Optional[str] = None
    tag_filter: dict[str, str] = Field(default_factory=dict)
    metric: str
    condition_type: str = Field(default="threshold")
    condition_config: dict[str, Any]
    # Example: {"operator": ">", "threshold": 90.0, "for_seconds": 120}
    severity: str = Field(default="warning")
    enabled: bool = True
    cooldown_seconds: int = Field(default=300, ge=0)
    notification_channel_ids: list[uuid.UUID] = Field(default_factory=list)

    @field_validator("severity")
    @classmethod
    def validate_severity(cls, v: str) -> str:
        if v not in {"info", "warning", "critical"}:
            raise ValueError("severity must be info, warning, or critical")
        return v


class AlertRuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
    severity: Optional[str] = None
    condition_config: Optional[dict[str, Any]] = None
    cooldown_seconds: Optional[int] = None
    notification_channel_ids: Optional[list[uuid.UUID]] = None
    maintenance_until: Optional[datetime] = None


class AlertRuleResponse(OrmBase):
    id: uuid.UUID
    name: str
    description: str
    device_id: Optional[uuid.UUID]
    device_type_filter: Optional[str]
    tag_filter: dict
    metric: str
    condition_type: str
    condition_config: dict
    severity: str
    enabled: bool
    cooldown_seconds: int
    notification_channel_ids: list
    maintenance_until: Optional[datetime]
    created_at: datetime
    updated_at: datetime


class AlertIncidentResponse(OrmBase):
    id: uuid.UUID
    rule_id: uuid.UUID
    device_id: uuid.UUID
    metric: str
    severity: str
    status: str
    trigger_value: float
    trigger_labels: dict
    message: str
    triggered_at: datetime
    resolved_at: Optional[datetime]
    acknowledged: bool
    acknowledged_by: Optional[uuid.UUID]
    acknowledged_at: Optional[datetime]


class AcknowledgeIncidentRequest(BaseModel):
    note: str = Field(default="", max_length=1024)


# ── Notification Channels ─────────────────────────────────────────────────────

class NotificationChannelCreate(BaseModel):
    name: str = Field(min_length=1, max_length=128)
    channel_type: str
    enabled: bool = True
    config: dict[str, Any]  # Encrypted before storage

    @field_validator("channel_type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        if v not in {"email", "slack", "teams", "telegram", "webhook"}:
            raise ValueError("Invalid channel_type")
        return v


class NotificationChannelResponse(OrmBase):
    id: uuid.UUID
    name: str
    channel_type: str
    enabled: bool
    created_at: datetime


# ── Dashboards ────────────────────────────────────────────────────────────────

class WidgetConfig(BaseModel):
    id: str
    type: str
    x: int = Field(ge=0)
    y: int = Field(ge=0)
    w: int = Field(ge=1, le=12)
    h: int = Field(ge=1)
    config: dict[str, Any] = Field(default_factory=dict)


class DashboardCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str = Field(default="", max_length=1024)
    is_public: bool = False
    is_template: bool = False
    widgets: list[WidgetConfig] = Field(default_factory=list)
    variables: dict[str, Any] = Field(default_factory=dict)
    time_range: str = Field(default="1h")
    refresh_interval_seconds: int = Field(default=30, ge=5)
    tags: list[str] = Field(default_factory=list)


class DashboardUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_public: Optional[bool] = None
    widgets: Optional[list[WidgetConfig]] = None
    variables: Optional[dict[str, Any]] = None
    time_range: Optional[str] = None
    refresh_interval_seconds: Optional[int] = None
    tags: Optional[list[str]] = None


class DashboardResponse(OrmBase):
    id: uuid.UUID
    name: str
    description: str
    owner_id: Optional[uuid.UUID]
    is_public: bool
    is_template: bool
    is_starred: bool
    layout: dict
    variables: dict
    time_range: str
    refresh_interval_seconds: int
    tags: list
    version: int
    slug: str
    created_at: datetime
    updated_at: datetime


# ── Proxmox ───────────────────────────────────────────────────────────────────

class ProxmoxClusterResponse(OrmBase):
    id: uuid.UUID
    device_id: uuid.UUID
    cluster_name: str
    quorate: bool
    node_count: int
    ha_enabled: bool
    pve_version: str
    updated_at: datetime


class ProxmoxNodeResponse(OrmBase):
    id: uuid.UUID
    device_id: uuid.UUID
    node_name: str
    status: str
    cpu_count: int
    cpu_util: float
    mem_total_bytes: int
    mem_used_bytes: int
    disk_total_bytes: int
    disk_used_bytes: int
    uptime_seconds: int
    pve_version: str
    updated_at: datetime


class VMResponse(OrmBase):
    id: uuid.UUID
    device_id: uuid.UUID
    vmid: int
    vm_name: str
    vm_type: str
    status: str
    cpu_count: int
    cpu_util: float
    mem_total_bytes: int
    mem_used_bytes: int
    disk_total_bytes: int
    disk_used_bytes: int
    uptime_seconds: int
    ha_managed: bool
    ha_state: Optional[str]
    updated_at: datetime


# ── FlashSystem ───────────────────────────────────────────────────────────────

class FlashSystemArrayResponse(OrmBase):
    id: uuid.UUID
    device_id: uuid.UUID
    array_name: str
    model: str
    code_level: str
    total_capacity_bytes: int
    used_capacity_bytes: int
    free_capacity_bytes: int
    read_iops: float
    write_iops: float
    read_bandwidth_mbps: float
    write_bandwidth_mbps: float
    read_latency_us: float
    write_latency_us: float
    status: str
    updated_at: datetime


class FlashSystemPoolResponse(OrmBase):
    id: uuid.UUID
    array_id: uuid.UUID
    pool_id: str
    pool_name: str
    status: str
    capacity_bytes: int
    used_capacity_bytes: int
    free_capacity_bytes: int
    overallocation_pct: float
    compression_ratio: float
    dedupe_ratio: float
    drive_count: int
    updated_at: datetime


# ── Health ────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    version: str
    timestamp: datetime
    services: dict[str, str]


# ── Audit ─────────────────────────────────────────────────────────────────────

class AuditLogResponse(OrmBase):
    id: uuid.UUID
    user_id: Optional[uuid.UUID]
    action: str
    resource_type: str
    resource_id: Optional[str]
    ip_address: Optional[str]
    result: str
    timestamp: datetime
