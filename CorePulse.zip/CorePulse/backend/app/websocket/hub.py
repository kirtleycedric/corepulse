"""
CorePulse — WebSocket hub with room-based subscriptions and Redis fan-out.

Architecture:
  - Each WebSocket connection is assigned to a ConnectionState.
  - Rooms: "device:{uuid}", "alerts:global", "dashboard:{uuid}", "cluster:global"
  - Redis pub/sub listener runs as a background asyncio task per worker.
  - Messages published to Redis are fanned out to all subscribed WS clients.
"""
from __future__ import annotations

import asyncio
import json
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Optional, TYPE_CHECKING

import structlog
from fastapi import WebSocket, WebSocketDisconnect

if TYPE_CHECKING:
    pass

log = structlog.get_logger(__name__)


class ConnectionState:
    """Tracks a single WebSocket connection."""

    def __init__(self, ws: WebSocket, user_id: Optional[uuid.UUID], conn_id: str) -> None:
        self.ws = ws
        self.user_id = user_id
        self.conn_id = conn_id
        self.rooms: set[str] = set()
        self.connected_at = datetime.now(tz=timezone.utc)
        self.last_ping = datetime.now(tz=timezone.utc)

    async def send(self, message: dict[str, Any]) -> bool:
        """Send a JSON message. Returns False if connection is dead."""
        try:
            await self.ws.send_text(json.dumps(message, default=str))
            return True
        except Exception:
            return False


class WebSocketHub:
    """
    Central WebSocket connection manager.
    Singleton — one instance per ASGI worker process.
    """

    def __init__(self) -> None:
        # conn_id → ConnectionState
        self._connections: dict[str, ConnectionState] = {}
        # room → set of conn_ids
        self._rooms: dict[str, set[str]] = defaultdict(set)
        # user_id → set of conn_ids
        self._user_connections: dict[str, set[str]] = defaultdict(set)
        self._lock = asyncio.Lock()
        self._redis_listener_task: Optional[asyncio.Task] = None  # type: ignore

    async def connect(self, ws: WebSocket, user_id: Optional[uuid.UUID] = None) -> ConnectionState:
        """Accept a WebSocket connection and register it."""
        await ws.accept()
        conn_id = str(uuid.uuid4())
        state = ConnectionState(ws=ws, user_id=user_id, conn_id=conn_id)

        async with self._lock:
            self._connections[conn_id] = state
            if user_id:
                self._user_connections[str(user_id)].add(conn_id)

        log.info("ws.connected", conn_id=conn_id, user_id=str(user_id) if user_id else None)
        await state.send({"type": "connected", "conn_id": conn_id, "timestamp": datetime.now(tz=timezone.utc).isoformat()})
        return state

    async def disconnect(self, conn_id: str) -> None:
        async with self._lock:
            state = self._connections.pop(conn_id, None)
            if state:
                for room in state.rooms:
                    self._rooms[room].discard(conn_id)
                if state.user_id:
                    self._user_connections[str(state.user_id)].discard(conn_id)
        log.info("ws.disconnected", conn_id=conn_id)

    async def subscribe(self, conn_id: str, room: str) -> None:
        async with self._lock:
            state = self._connections.get(conn_id)
            if state:
                state.rooms.add(room)
                self._rooms[room].add(conn_id)
        log.debug("ws.subscribed", conn_id=conn_id, room=room)

    async def unsubscribe(self, conn_id: str, room: str) -> None:
        async with self._lock:
            state = self._connections.get(conn_id)
            if state:
                state.rooms.discard(room)
            self._rooms[room].discard(conn_id)

    async def broadcast_to_room(self, room: str, message: dict[str, Any]) -> int:
        """Send a message to all connections in a room. Returns delivery count."""
        async with self._lock:
            conn_ids = list(self._rooms.get(room, set()))

        dead: list[str] = []
        count = 0
        for conn_id in conn_ids:
            state = self._connections.get(conn_id)
            if state:
                ok = await state.send(message)
                if ok:
                    count += 1
                else:
                    dead.append(conn_id)

        for dead_id in dead:
            await self.disconnect(dead_id)

        return count

    async def broadcast_global(self, message: dict[str, Any]) -> int:
        """Send a message to ALL connected clients."""
        async with self._lock:
            conn_ids = list(self._connections.keys())
        count = 0
        dead: list[str] = []
        for conn_id in conn_ids:
            state = self._connections.get(conn_id)
            if state:
                ok = await state.send(message)
                if ok:
                    count += 1
                else:
                    dead.append(conn_id)
        for dead_id in dead:
            await self.disconnect(dead_id)
        return count

    async def send_to_user(self, user_id: uuid.UUID, message: dict[str, Any]) -> int:
        async with self._lock:
            conn_ids = list(self._user_connections.get(str(user_id), set()))
        count = 0
        for conn_id in conn_ids:
            state = self._connections.get(conn_id)
            if state:
                ok = await state.send(message)
                if ok:
                    count += 1
        return count

    async def handle_client_message(self, conn_id: str, raw: str) -> None:
        """Process incoming messages from a WebSocket client."""
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return

        msg_type = msg.get("type", "")
        state = self._connections.get(conn_id)
        if not state:
            return

        if msg_type == "subscribe":
            room = msg.get("room", "")
            if room:
                await self.subscribe(conn_id, room)
                await state.send({"type": "subscribed", "room": room})

        elif msg_type == "unsubscribe":
            room = msg.get("room", "")
            if room:
                await self.unsubscribe(conn_id, room)
                await state.send({"type": "unsubscribed", "room": room})

        elif msg_type == "ping":
            state.last_ping = datetime.now(tz=timezone.utc)
            await state.send({"type": "pong", "timestamp": state.last_ping.isoformat()})

    async def start_redis_listener(self) -> None:
        """Start background task to relay Redis pub/sub messages to WS clients."""
        if self._redis_listener_task and not self._redis_listener_task.done():
            return
        self._redis_listener_task = asyncio.create_task(self._redis_listener_loop())
        log.info("ws.redis_listener.started")

    async def _redis_listener_loop(self) -> None:
        """Subscribes to corepulse:* Redis channels and fans out to WS rooms."""
        from app.core.redis import get_redis
        import redis.asyncio as aioredis

        while True:
            try:
                redis = await get_redis()
                pubsub = redis.pubsub()
                await pubsub.psubscribe("corepulse:*")
                log.info("ws.redis_listener.subscribed")

                async for message in pubsub.listen():
                    if message["type"] not in ("message", "pmessage"):
                        continue
                    try:
                        channel: str = message.get("channel", "")
                        # Strip prefix: "corepulse:alerts" → "alerts"
                        topic = channel.replace("corepulse:", "", 1)
                        data = json.loads(message["data"])

                        # Route to appropriate WS room
                        if topic == "alerts":
                            await self.broadcast_to_room("alerts:global", {
                                "type": "alert_event", **data
                            })
                        elif topic.startswith("device:"):
                            room = topic
                            await self.broadcast_to_room(room, {"type": "metric_update", **data})
                        elif topic.startswith("dashboard:"):
                            room = topic
                            await self.broadcast_to_room(room, {"type": "dashboard_update", **data})
                        else:
                            await self.broadcast_global({"type": topic, **data})
                    except Exception as exc:
                        log.warning("ws.relay.error", error=str(exc))

            except asyncio.CancelledError:
                log.info("ws.redis_listener.cancelled")
                break
            except Exception as exc:
                log.error("ws.redis_listener.error", error=str(exc))
                await asyncio.sleep(5)  # Reconnect backoff

    async def heartbeat_loop(self) -> None:
        """Send periodic pings to detect dead connections."""
        while True:
            await asyncio.sleep(30)
            now = datetime.now(tz=timezone.utc)
            dead: list[str] = []
            async with self._lock:
                conn_ids = list(self._connections.keys())
            for conn_id in conn_ids:
                state = self._connections.get(conn_id)
                if state:
                    age = (now - state.last_ping).total_seconds()
                    if age > 90:
                        dead.append(conn_id)
                    else:
                        await state.send({"type": "heartbeat", "timestamp": now.isoformat()})
            for dead_id in dead:
                await self.disconnect(dead_id)

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "total_connections": len(self._connections),
            "total_rooms": len(self._rooms),
            "rooms": {room: len(conns) for room, conns in self._rooms.items() if conns},
        }


# Global singleton
hub = WebSocketHub()
