"""
CorePulse — JWT auth and RBAC system.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Annotated, Optional
from uuid import UUID

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from app.core.config import get_settings
from app.core.logging import get_logger

log = get_logger(__name__)
_bearer = HTTPBearer(auto_error=True)


class TokenPayload(BaseModel):
    sub: str           # user UUID
    jti: str           # JWT ID for revocation
    exp: int
    iat: int
    type: str          # "access" | "refresh"
    role: str
    permissions: list[str]
    is_superuser: bool


class UserContext(BaseModel):
    user_id: UUID
    username: str
    email: str
    role: str
    is_superuser: bool
    permissions: frozenset[str]

    def has_permission(self, perm: str) -> bool:
        if self.is_superuser:
            return True
        return perm in self.permissions

    def assert_permission(self, perm: str) -> None:
        if not self.has_permission(perm):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission required: '{perm}'",
            )


# ── Permission constants ────────────────────────────────────────────────────

class Permissions:
    # Devices
    DEVICES_READ   = "devices:read"
    DEVICES_WRITE  = "devices:write"
    DEVICES_DELETE = "devices:delete"

    # Metrics
    METRICS_READ = "metrics:read"

    # Dashboards
    DASHBOARDS_READ   = "dashboards:read"
    DASHBOARDS_WRITE  = "dashboards:write"
    DASHBOARDS_DELETE = "dashboards:delete"

    # Alerts
    ALERTS_READ       = "alerts:read"
    ALERTS_WRITE      = "alerts:write"
    ALERTS_ACK        = "alerts:acknowledge"

    # Users
    USERS_READ   = "users:read"
    USERS_WRITE  = "users:write"
    USERS_DELETE = "users:delete"

    # System
    SYSTEM_READ  = "system:read"
    SYSTEM_WRITE = "system:write"

    # Audit
    AUDIT_READ = "audit:read"


ROLE_PERMISSIONS: dict[str, list[str]] = {
    "viewer": [
        Permissions.DEVICES_READ,
        Permissions.METRICS_READ,
        Permissions.DASHBOARDS_READ,
        Permissions.ALERTS_READ,
    ],
    "operator": [
        Permissions.DEVICES_READ,
        Permissions.METRICS_READ,
        Permissions.DASHBOARDS_READ,
        Permissions.DASHBOARDS_WRITE,
        Permissions.ALERTS_READ,
        Permissions.ALERTS_ACK,
    ],
    "engineer": [
        Permissions.DEVICES_READ,
        Permissions.DEVICES_WRITE,
        Permissions.METRICS_READ,
        Permissions.DASHBOARDS_READ,
        Permissions.DASHBOARDS_WRITE,
        Permissions.DASHBOARDS_DELETE,
        Permissions.ALERTS_READ,
        Permissions.ALERTS_WRITE,
        Permissions.ALERTS_ACK,
        Permissions.SYSTEM_READ,
    ],
    "admin": [
        Permissions.DEVICES_READ,
        Permissions.DEVICES_WRITE,
        Permissions.DEVICES_DELETE,
        Permissions.METRICS_READ,
        Permissions.DASHBOARDS_READ,
        Permissions.DASHBOARDS_WRITE,
        Permissions.DASHBOARDS_DELETE,
        Permissions.ALERTS_READ,
        Permissions.ALERTS_WRITE,
        Permissions.ALERTS_ACK,
        Permissions.USERS_READ,
        Permissions.USERS_WRITE,
        Permissions.USERS_DELETE,
        Permissions.SYSTEM_READ,
        Permissions.SYSTEM_WRITE,
        Permissions.AUDIT_READ,
    ],
}


# ── Token utilities ─────────────────────────────────────────────────────────

def create_access_token(
    user_id: UUID,
    username: str,
    email: str,
    role: str,
    is_superuser: bool,
    permissions: list[str],
) -> str:
    cfg = get_settings()
    now = datetime.now(tz=timezone.utc)
    payload = {
        "sub": str(user_id),
        "jti": str(uuid.uuid4()),
        "type": "access",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=cfg.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)).timestamp()),
        "username": username,
        "email": email,
        "role": role,
        "permissions": permissions,
        "is_superuser": is_superuser,
    }
    return jwt.encode(payload, cfg.SECRET_KEY, algorithm=cfg.JWT_ALGORITHM)


def create_refresh_token(user_id: UUID) -> str:
    cfg = get_settings()
    now = datetime.now(tz=timezone.utc)
    payload = {
        "sub": str(user_id),
        "jti": str(uuid.uuid4()),
        "type": "refresh",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(days=cfg.JWT_REFRESH_TOKEN_EXPIRE_DAYS)).timestamp()),
        "role": "",
        "permissions": [],
        "is_superuser": False,
    }
    return jwt.encode(payload, cfg.SECRET_KEY, algorithm=cfg.JWT_ALGORITHM)


def decode_token(token: str) -> TokenPayload:
    cfg = get_settings()
    try:
        raw = jwt.decode(
            token,
            cfg.SECRET_KEY,
            algorithms=[cfg.JWT_ALGORITHM],
            options={"require": ["sub", "exp", "iat", "type", "jti"]},
        )
        return TokenPayload(**raw)
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {exc}",
            headers={"WWW-Authenticate": "Bearer"},
        )


# ── Password utilities ────────────────────────────────────────────────────────

def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


# ── FastAPI dependencies ──────────────────────────────────────────────────────

async def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(_bearer)],
) -> UserContext:
    payload = decode_token(credentials.credentials)
    if payload.type != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token cannot be used for API access",
        )
    return UserContext(
        user_id=UUID(payload.sub),
        username=payload.model_extra.get("username", "") if hasattr(payload, "model_extra") else "",
        email=payload.model_extra.get("email", "") if hasattr(payload, "model_extra") else "",
        role=payload.role,
        is_superuser=payload.is_superuser,
        permissions=frozenset(payload.permissions),
    )


def require_permission(perm: str):
    """Dependency factory for permission-based access control."""
    async def _check(
        user: Annotated[UserContext, Depends(get_current_user)],
    ) -> UserContext:
        user.assert_permission(perm)
        return user
    _check.__name__ = f"require_{perm.replace(':', '_')}"
    return _check


async def require_superuser(
    user: Annotated[UserContext, Depends(get_current_user)],
) -> UserContext:
    if not user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Superuser access required",
        )
    return user
