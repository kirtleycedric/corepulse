"""
CorePulse — Central configuration.
All values sourced from environment variables. No hardcoded secrets.
"""
from __future__ import annotations

import secrets
from functools import lru_cache
from typing import Any, Literal

from pydantic import AnyHttpUrl, Field, PostgresDsn, RedisDsn, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ──────────────────────────────────────────────────────────
    APP_NAME: str = "CorePulse"
    APP_VERSION: str = "1.0.0"
    ENV: Literal["development", "staging", "production"] = "development"
    DEBUG: bool = False
    SECRET_KEY: str = Field(default_factory=lambda: secrets.token_hex(32))
    API_V1_PREFIX: str = "/api/v1"

    # ── Server ────────────────────────────────────────────────────────────────
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 4
    RELOAD: bool = False
    ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://localhost:8080",
    ]

    # ── Database ──────────────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://corepulse:corepulse@localhost:5432/corepulse"
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10
    DATABASE_POOL_TIMEOUT: int = 30
    DATABASE_ECHO: bool = False

    # ── Redis ─────────────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_DB: int = 1
    REDIS_CACHE_TTL: int = 300

    # ── Celery ────────────────────────────────────────────────────────────────
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/0"
    CELERY_TASK_SERIALIZER: str = "json"
    CELERY_RESULT_SERIALIZER: str = "json"
    CELERY_TIMEZONE: str = "UTC"
    CELERY_BEAT_SCHEDULE_FILENAME: str = "/tmp/celerybeat-schedule"

    # ── JWT Auth ──────────────────────────────────────────────────────────────
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # ── Rate limiting ─────────────────────────────────────────────────────────
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_AUTH: str = "10/minute"
    RATE_LIMIT_API: str = "1000/minute"

    # ── Collectors ────────────────────────────────────────────────────────────
    COLLECTOR_DEFAULT_INTERVAL_SECONDS: int = 60
    COLLECTOR_TIMEOUT_SECONDS: int = 15
    COLLECTOR_MAX_CONCURRENCY: int = 50
    COLLECTOR_MAX_RETRIES: int = 3
    COLLECTOR_RETRY_BACKOFF_BASE: float = 1.0

    # ── SNMP ──────────────────────────────────────────────────────────────────
    SNMP_DEFAULT_COMMUNITY: str = "public"
    SNMP_DEFAULT_VERSION: str = "2c"
    SNMP_DEFAULT_PORT: int = 161
    SNMP_TRAP_PORT: int = 162
    SNMP_BULK_MAX_REPETITIONS: int = 25
    SNMP_TIMEOUT_SECONDS: float = 10.0

    # ── Proxmox ───────────────────────────────────────────────────────────────
    PROXMOX_DEFAULT_PORT: int = 8006
    PROXMOX_VERIFY_SSL: bool = False
    PROXMOX_POLL_INTERVAL: int = 30

    # ── IBM FlashSystem ───────────────────────────────────────────────────────
    FLASHSYSTEM_DEFAULT_PORT: int = 7443
    FLASHSYSTEM_VERIFY_SSL: bool = False
    FLASHSYSTEM_POLL_INTERVAL: int = 60

    # ── Alerting ──────────────────────────────────────────────────────────────
    ALERT_EVALUATION_INTERVAL: int = 30
    ALERT_DEDUP_WINDOW_SECONDS: int = 300
    ALERT_COOLDOWN_SECONDS: int = 300

    # ── Email ─────────────────────────────────────────────────────────────────
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_TLS: bool = True
    SMTP_FROM: str = "alerts@corepulse.local"
    SMTP_FROM_NAME: str = "CorePulse Alerts"

    # ── Slack ─────────────────────────────────────────────────────────────────
    SLACK_DEFAULT_WEBHOOK_URL: str = ""

    # ── Teams ─────────────────────────────────────────────────────────────────
    TEAMS_DEFAULT_WEBHOOK_URL: str = ""

    # ── Telegram ─────────────────────────────────────────────────────────────
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_DEFAULT_CHAT_ID: str = ""

    # ── Logging ───────────────────────────────────────────────────────────────
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: Literal["json", "console"] = "json"
    LOG_FILE: str = ""

    # ── TimescaleDB ───────────────────────────────────────────────────────────
    METRICS_RETENTION_DAYS: int = 90
    METRICS_CHUNK_INTERVAL: str = "4 hours"
    METRICS_COMPRESSION_AFTER: str = "7 days"

    # ── WebSocket ─────────────────────────────────────────────────────────────
    WS_HEARTBEAT_INTERVAL: int = 30
    WS_MAX_CONNECTIONS_PER_USER: int = 10

    # ── Security ──────────────────────────────────────────────────────────────
    VAULT_ENABLED: bool = False
    VAULT_URL: str = ""
    VAULT_TOKEN: str = ""

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def parse_origins(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [o.strip() for o in v.split(",") if o.strip()]
        return v

    @property
    def is_production(self) -> bool:
        return self.ENV == "production"

    @property
    def database_url_sync(self) -> str:
        """Synchronous URL for Alembic migrations."""
        return self.DATABASE_URL.replace("+asyncpg", "")

    @property
    def database_url_async(self) -> str:
        url = self.DATABASE_URL
        if not url.startswith("postgresql+asyncpg"):
            url = url.replace("postgresql://", "postgresql+asyncpg://")
            url = url.replace("postgresql+psycopg2://", "postgresql+asyncpg://")
        return url


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
