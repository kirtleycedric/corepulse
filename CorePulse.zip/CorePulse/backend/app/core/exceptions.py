"""
CorePulse — Application exception hierarchy and FastAPI handlers.
"""
from __future__ import annotations

from typing import Any, Optional

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse


class CorePulseError(Exception):
    """Base exception for all application errors."""
    status_code: int = 500
    error_code: str = "INTERNAL_ERROR"

    def __init__(
        self,
        message: str,
        detail: Optional[Any] = None,
        error_code: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.detail = detail
        if error_code:
            self.error_code = error_code


class NotFoundError(CorePulseError):
    status_code = 404
    error_code = "NOT_FOUND"


class ConflictError(CorePulseError):
    status_code = 409
    error_code = "CONFLICT"


class ValidationError(CorePulseError):
    status_code = 422
    error_code = "VALIDATION_ERROR"


class AuthenticationError(CorePulseError):
    status_code = 401
    error_code = "AUTHENTICATION_ERROR"


class AuthorizationError(CorePulseError):
    status_code = 403
    error_code = "AUTHORIZATION_ERROR"


class CollectorError(CorePulseError):
    status_code = 502
    error_code = "COLLECTOR_ERROR"

    def __init__(self, message: str, retryable: bool = True, **kwargs: Any) -> None:
        super().__init__(message, **kwargs)
        self.retryable = retryable


class RateLimitError(CorePulseError):
    status_code = 429
    error_code = "RATE_LIMIT_EXCEEDED"


class ServiceUnavailableError(CorePulseError):
    status_code = 503
    error_code = "SERVICE_UNAVAILABLE"


def _error_response(
    status_code: int,
    error_code: str,
    message: str,
    detail: Any = None,
) -> JSONResponse:
    body: dict[str, Any] = {
        "error": {
            "code": error_code,
            "message": message,
        }
    }
    if detail is not None:
        body["error"]["detail"] = detail
    return JSONResponse(status_code=status_code, content=body)


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(CorePulseError)
    async def corepulse_error_handler(request: Request, exc: CorePulseError) -> JSONResponse:
        return _error_response(
            status_code=exc.status_code,
            error_code=exc.error_code,
            message=exc.message,
            detail=exc.detail,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        return _error_response(
            status_code=422,
            error_code="VALIDATION_ERROR",
            message="Request validation failed",
            detail=exc.errors(),
        )

    @app.exception_handler(404)
    async def not_found_handler(request: Request, exc: Exception) -> JSONResponse:
        return _error_response(
            status_code=404,
            error_code="NOT_FOUND",
            message=f"Route '{request.url.path}' not found",
        )

    @app.exception_handler(500)
    async def server_error_handler(request: Request, exc: Exception) -> JSONResponse:
        return _error_response(
            status_code=500,
            error_code="INTERNAL_ERROR",
            message="An internal server error occurred",
        )
