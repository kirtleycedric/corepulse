"""
CorePulse — Redis connection management and cache utilities.
"""
from __future__ import annotations

import json
from typing import Any, Optional

import redis.asyncio as aioredis
from redis.asyncio import Redis

from app.core.config import get_settings
from app.core.logging import get_logger

log = get_logger(__name__)

_redis_pool: Optional[Redis] = None


async def get_redis() -> Redis:
    global _redis_pool
    if _redis_pool is None:
        cfg = get_settings()
        _redis_pool = aioredis.from_url(
            cfg.REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=5,
            retry_on_timeout=True,
            health_check_interval=30,
        )
    return _redis_pool


async def init_redis() -> None:
    redis = await get_redis()
    try:
        await redis.ping()
        log.info("redis.connected")
    except Exception as exc:
        log.error("redis.connection_failed", error=str(exc))
        raise


async def close_redis() -> None:
    global _redis_pool
    if _redis_pool is not None:
        await _redis_pool.aclose()
        _redis_pool = None
    log.info("redis.closed")


class CacheManager:
    """High-level cache operations with automatic JSON serialization."""

    def __init__(self, prefix: str = "corepulse", default_ttl: int = 300) -> None:
        self._prefix = prefix
        self._default_ttl = default_ttl

    def _key(self, key: str) -> str:
        return f"{self._prefix}:{key}"

    async def get(self, key: str) -> Optional[Any]:
        redis = await get_redis()
        value = await redis.get(self._key(key))
        if value is None:
            return None
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return value

    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
    ) -> bool:
        redis = await get_redis()
        serialized = json.dumps(value, default=str)
        return bool(
            await redis.set(
                self._key(key),
                serialized,
                ex=ttl or self._default_ttl,
            )
        )

    async def delete(self, key: str) -> int:
        redis = await get_redis()
        return await redis.delete(self._key(key))

    async def delete_pattern(self, pattern: str) -> int:
        redis = await get_redis()
        keys = await redis.keys(self._key(pattern))
        if not keys:
            return 0
        return await redis.delete(*keys)

    async def exists(self, key: str) -> bool:
        redis = await get_redis()
        return bool(await redis.exists(self._key(key)))

    async def incr(self, key: str, amount: int = 1, ttl: Optional[int] = None) -> int:
        redis = await get_redis()
        full_key = self._key(key)
        value = await redis.incrby(full_key, amount)
        if ttl and value == amount:
            await redis.expire(full_key, ttl)
        return value

    async def publish(self, channel: str, message: Any) -> int:
        redis = await get_redis()
        return await redis.publish(
            f"{self._prefix}:{channel}",
            json.dumps(message, default=str),
        )


# Shared instances
cache = CacheManager(prefix="corepulse:cache")
rate_limit = CacheManager(prefix="corepulse:ratelimit")
