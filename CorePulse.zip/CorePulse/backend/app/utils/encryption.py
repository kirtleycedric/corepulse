"""
CorePulse — AES-256-GCM encryption for credential storage.
Uses Fernet (symmetric authenticated encryption) via cryptography library.
"""
from __future__ import annotations

import base64
import json
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import get_settings
from app.core.exceptions import CorePulseError


def _get_fernet() -> Fernet:
    """Derive a Fernet key from the application SECRET_KEY."""
    cfg = get_settings()
    # Fernet requires a URL-safe base64-encoded 32-byte key
    raw_key = cfg.SECRET_KEY[:32].encode("utf-8").ljust(32, b"0")
    encoded = base64.urlsafe_b64encode(raw_key)
    return Fernet(encoded)


def encrypt_data(data: dict[str, Any]) -> str:
    """Encrypt a dictionary to a base64-encoded ciphertext string."""
    try:
        fernet = _get_fernet()
        plaintext = json.dumps(data, default=str).encode("utf-8")
        return fernet.encrypt(plaintext).decode("utf-8")
    except Exception as exc:
        raise CorePulseError(f"Encryption failed: {exc}") from exc


def decrypt_data(ciphertext: str) -> dict[str, Any]:
    """Decrypt a base64-encoded ciphertext string to a dictionary."""
    try:
        fernet = _get_fernet()
        plaintext = fernet.decrypt(ciphertext.encode("utf-8"))
        return json.loads(plaintext.decode("utf-8"))
    except InvalidToken:
        raise CorePulseError("Credential decryption failed: invalid or corrupted data", error_code="DECRYPTION_ERROR")
    except Exception as exc:
        raise CorePulseError(f"Decryption failed: {exc}") from exc
