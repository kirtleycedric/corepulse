"""
CorePulse — Celery application factory and task definitions.
"""
from __future__ import annotations

from celery import Celery
from celery.schedules import crontab

from app.core.config import get_settings


def create_celery() -> Celery:
    cfg = get_settings()

    app = Celery("corepulse")
    app.config_from_object({
        "broker_url": cfg.CELERY_BROKER_URL,
        "result_backend": cfg.CELERY_RESULT_BACKEND,
        "task_serializer": cfg.CELERY_TASK_SERIALIZER,
        "result_serializer": cfg.CELERY_RESULT_SERIALIZER,
        "accept_content": ["json"],
        "timezone": cfg.CELERY_TIMEZONE,
        "enable_utc": True,
        "broker_transport_options": {"visibility_timeout": 3600},
        "result_expires": 3600,
        "task_acks_late": True,
        "task_reject_on_worker_lost": True,
        "worker_prefetch_multiplier": 1,
        "worker_send_task_events": True,
        "task_send_sent_event": True,
        "task_routes": {
            "app.workers.tasks.poll_proxmox":    {"queue": "collectors"},
            "app.workers.tasks.poll_snmp":       {"queue": "collectors"},
            "app.workers.tasks.poll_flashsystem":{"queue": "collectors"},
            "app.workers.tasks.evaluate_alerts": {"queue": "alerts"},
            "app.workers.tasks.send_notification": {"queue": "notifications"},
            "app.workers.tasks.discovery_scan":  {"queue": "discovery"},
        },
        "beat_schedule": {
            "evaluate-alerts-30s": {
                "task": "app.workers.tasks.evaluate_alerts",
                "schedule": 30.0,
                "options": {"queue": "alerts"},
            },
            "health-sweep-60s": {
                "task": "app.workers.tasks.health_sweep",
                "schedule": 60.0,
                "options": {"queue": "collectors"},
            },
            "enforce-retention-daily": {
                "task": "app.workers.tasks.enforce_retention",
                "schedule": crontab(hour=2, minute=0),
                "options": {"queue": "default"},
            },
        },
    })

    app.autodiscover_tasks(["app.workers"])
    return app


celery_app = create_celery()
