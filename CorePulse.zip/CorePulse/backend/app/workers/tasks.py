"""
CorePulse — Celery task implementations.
All polling, alerting, discovery, and maintenance tasks.
"""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

import structlog
from celery import Task, shared_task
from celery.utils.log import get_task_logger

from app.workers.celery_app import celery_app

log = get_task_logger(__name__)


# ── Helper: run async from sync Celery context ───────────────────────────────

def _run(coro: Any) -> Any:
    """Execute an async coroutine from a synchronous Celery task."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ── Base task with retry behaviour ───────────────────────────────────────────

class PollTask(Task):
    """Base class for device polling tasks with built-in retry logic."""
    abstract = True
    max_retries = 3
    default_retry_delay = 5
    autoretry_for = (Exception,)
    retry_backoff = True
    retry_backoff_max = 60
    retry_jitter = True


# ── Proxmox polling ──────────────────────────────────────────────────────────

@celery_app.task(bind=True, base=PollTask, name="app.workers.tasks.poll_proxmox")
def poll_proxmox(self: Task, device_id: str) -> dict[str, Any]:
    """Poll a single Proxmox cluster device."""
    return _run(_poll_proxmox_async(device_id))


async def _poll_proxmox_async(device_id_str: str) -> dict[str, Any]:
    from app.core.database import get_session_factory
    from app.core.redis import cache
    from app.collectors.proxmox.collector import ProxmoxCollector
    from app.services.device_service import DeviceService, CredentialService
    from app.services.metrics_service import MetricsService

    device_id = UUID(device_id_str)
    factory = get_session_factory()

    async with factory() as session:
        try:
            device_svc = DeviceService(session)
            device = await device_svc.get_device(device_id)

            credentials: dict[str, Any] = {}
            if device.credential_profile_id:
                cred_svc = CredentialService(session)
                credentials = await cred_svc.get_decrypted_credentials(device.credential_profile_id)

            collector = ProxmoxCollector(
                device_id=device_id,
                host=device.host,
                credentials=credentials,
                port=device.port or 8006,
            )

            try:
                metrics, cluster_state = await collector.collect()
            finally:
                await collector.close()

            # Persist metrics
            if metrics:
                metrics_svc = MetricsService(session)
                count = await metrics_svc.ingest_batch(metrics)
                log.info(f"proxmox.poll.ingested device={device_id_str} metrics={count}")

            # Cache latest values for alert evaluation
            for m in metrics:
                key = f"last_metric:{device_id_str}:{m['metric']}"
                await cache.set(key, {
                    "value": m["value"],
                    "labels": m.get("labels", {}),
                    "device_name": device.display_name or device.name,
                    "timestamp": m["timestamp"].isoformat() if hasattr(m["timestamp"], "isoformat") else str(m["timestamp"]),
                }, ttl=300)

            # Update device status
            await device_svc.update_device_status(
                device_id=device_id,
                poll_status="success",
                last_seen=datetime.now(tz=timezone.utc),
            )

            await session.commit()
            return {"status": "success", "metrics": len(metrics), "device_id": device_id_str}

        except Exception as exc:
            log.error(f"proxmox.poll.failed device={device_id_str} error={exc}")
            try:
                device_svc = DeviceService(session)
                await device_svc.update_device_status(
                    device_id=device_id, poll_status="error", failure_increment=True
                )
                await session.commit()
            except Exception:
                pass
            raise


# ── SNMP polling ──────────────────────────────────────────────────────────────

@celery_app.task(bind=True, base=PollTask, name="app.workers.tasks.poll_snmp")
def poll_snmp(self: Task, device_id: str) -> dict[str, Any]:
    """Poll a single SNMP device."""
    return _run(_poll_snmp_async(device_id))


async def _poll_snmp_async(device_id_str: str) -> dict[str, Any]:
    from app.core.database import get_session_factory
    from app.core.redis import cache
    from app.collectors.snmp.transport import SNMPCredentials
    from app.collectors.snmp.drivers.vendors import get_driver
    from app.services.device_service import DeviceService, CredentialService
    from app.services.metrics_service import MetricsService

    device_id = UUID(device_id_str)
    factory = get_session_factory()

    async with factory() as session:
        try:
            device_svc = DeviceService(session)
            device = await device_svc.get_device(device_id)

            raw_creds: dict[str, Any] = {}
            if device.credential_profile_id:
                cred_svc = CredentialService(session)
                raw_creds = await cred_svc.get_decrypted_credentials(device.credential_profile_id)

            creds = SNMPCredentials(
                version=raw_creds.get("version", "2c"),
                community=raw_creds.get("community", "public"),
                username=raw_creds.get("username", ""),
                auth_protocol=raw_creds.get("auth_protocol", "SHA"),
                auth_key=raw_creds.get("auth_key", ""),
                priv_protocol=raw_creds.get("priv_protocol", "AES"),
                priv_key=raw_creds.get("priv_key", ""),
                port=device.port or 161,
                timeout=device.poll_interval_seconds * 0.5,
                retries=2,
                bulk_max_repetitions=25,
            )

            driver = get_driver(
                device_type=device.device_type,
                device_id=device_id,
                host=device.host,
                credentials=creds,
            )

            metrics, iface_states = await driver.collect()

            # Ingest metrics
            if metrics:
                metrics_svc = MetricsService(session)
                await metrics_svc.ingest_batch(metrics)

            # Upsert interface states
            if iface_states:
                for iface in iface_states:
                    await device_svc.upsert_interface(device_id, iface)

            # Cache last values for alerting
            device_name = device.display_name or device.name
            for m in metrics:
                key = f"last_metric:{device_id_str}:{m['metric']}"
                await cache.set(key, {
                    "value": m["value"],
                    "labels": m.get("labels", {}),
                    "device_name": device_name,
                    "timestamp": str(m.get("timestamp", "")),
                }, ttl=300)

            await device_svc.update_device_status(
                device_id=device_id,
                poll_status="success",
                last_seen=datetime.now(tz=timezone.utc),
            )

            await session.commit()
            log.info(f"snmp.poll.success device={device_id_str} metrics={len(metrics)} ifaces={len(iface_states)}")
            return {"status": "success", "metrics": len(metrics), "interfaces": len(iface_states)}

        except Exception as exc:
            log.error(f"snmp.poll.failed device={device_id_str} error={exc}")
            try:
                await device_svc.update_device_status(
                    device_id=device_id, poll_status="error", failure_increment=True
                )
                await session.commit()
            except Exception:
                pass
            raise


# ── FlashSystem polling ───────────────────────────────────────────────────────

@celery_app.task(bind=True, base=PollTask, name="app.workers.tasks.poll_flashsystem")
def poll_flashsystem(self: Task, device_id: str) -> dict[str, Any]:
    """Poll a single IBM FlashSystem device."""
    return _run(_poll_flashsystem_async(device_id))


async def _poll_flashsystem_async(device_id_str: str) -> dict[str, Any]:
    from app.core.database import get_session_factory
    from app.core.redis import cache
    from app.collectors.flashsystem.collector import FlashSystemCollector
    from app.services.device_service import DeviceService, CredentialService
    from app.services.metrics_service import MetricsService

    device_id = UUID(device_id_str)
    factory = get_session_factory()

    async with factory() as session:
        try:
            device_svc = DeviceService(session)
            device = await device_svc.get_device(device_id)

            credentials: dict[str, Any] = {}
            if device.credential_profile_id:
                cred_svc = CredentialService(session)
                credentials = await cred_svc.get_decrypted_credentials(device.credential_profile_id)

            collector = FlashSystemCollector(
                device_id=device_id,
                host=device.host,
                credentials=credentials,
                port=device.port or 7443,
            )

            try:
                metrics, array_state = await collector.collect()
            finally:
                await collector.close()

            if metrics:
                metrics_svc = MetricsService(session)
                await metrics_svc.ingest_batch(metrics)

            device_name = device.display_name or device.name
            for m in metrics:
                key = f"last_metric:{device_id_str}:{m['metric']}"
                await cache.set(key, {
                    "value": m["value"],
                    "labels": m.get("labels", {}),
                    "device_name": device_name,
                }, ttl=300)

            await device_svc.update_device_status(
                device_id=device_id,
                poll_status="success",
                last_seen=datetime.now(tz=timezone.utc),
            )

            await session.commit()
            return {"status": "success", "metrics": len(metrics)}

        except Exception as exc:
            log.error(f"flashsystem.poll.failed device={device_id_str} error={exc}")
            try:
                await device_svc.update_device_status(
                    device_id=device_id, poll_status="error", failure_increment=True
                )
                await session.commit()
            except Exception:
                pass
            raise


# ── Alert evaluation ──────────────────────────────────────────────────────────

@celery_app.task(name="app.workers.tasks.evaluate_alerts")
def evaluate_alerts() -> dict[str, Any]:
    """Run alert rule evaluation across all devices."""
    return _run(_evaluate_alerts_async())


async def _evaluate_alerts_async() -> dict[str, Any]:
    from app.core.database import get_session_factory
    from app.alerting.engine import AlertManager

    factory = get_session_factory()
    async with factory() as session:
        try:
            manager = AlertManager(session)
            stats = await manager.evaluate_all_rules()
            await session.commit()
            return stats
        except Exception as exc:
            log.error(f"alert.evaluation.failed error={exc}")
            await session.rollback()
            raise


# ── Health sweep ──────────────────────────────────────────────────────────────

@celery_app.task(name="app.workers.tasks.health_sweep")
def health_sweep() -> dict[str, Any]:
    """
    Schedule polling for all enabled devices based on their interval.
    This is the main entry point — beat calls this every 60s,
    which then dispatches per-device tasks onto the collectors queue.
    """
    return _run(_health_sweep_async())


async def _health_sweep_async() -> dict[str, Any]:
    from app.core.database import get_session_factory
    from app.services.device_service import DeviceService

    dispatched = {"proxmox": 0, "snmp": 0, "flashsystem": 0, "skipped": 0}
    factory = get_session_factory()
    now = datetime.now(tz=timezone.utc)

    async with factory() as session:
        device_svc = DeviceService(session)
        devices = await device_svc.get_devices_for_polling()

        for device in devices:
            if not device.enabled:
                continue

            # Check if device is due for polling
            if device.last_poll_at:
                elapsed = (now - device.last_poll_at).total_seconds()
                if elapsed < device.poll_interval_seconds * 0.9:  # 10% grace
                    dispatched["skipped"] += 1
                    continue

            device_id_str = str(device.id)

            if device.device_type == "proxmox_cluster":
                poll_proxmox.apply_async(args=[device_id_str], queue="collectors")
                dispatched["proxmox"] += 1
            elif device.device_type == "flashsystem":
                poll_flashsystem.apply_async(args=[device_id_str], queue="collectors")
                dispatched["flashsystem"] += 1
            elif device.device_type in (
                "juniper_switch", "cisco_sg300", "cisco_catalyst", "generic_snmp"
            ):
                poll_snmp.apply_async(args=[device_id_str], queue="collectors")
                dispatched["snmp"] += 1

    log.info(f"health_sweep.dispatched {dispatched}")
    return dispatched


# ── SNMP Discovery ────────────────────────────────────────────────────────────

@celery_app.task(name="app.workers.tasks.discovery_scan")
def discovery_scan(
    subnet: str,
    community: str = "public",
    snmp_version: str = "2c",
    port: int = 161,
) -> dict[str, Any]:
    """Scan a subnet for SNMP-capable devices."""
    return _run(_discovery_scan_async(subnet, community, snmp_version, port))


async def _discovery_scan_async(
    subnet: str, community: str, snmp_version: str, port: int
) -> dict[str, Any]:
    import ipaddress
    from app.collectors.snmp.transport import SNMPCredentials, SNMPTransport, OIDs, _coerce_str, _coerce_value

    try:
        network = ipaddress.ip_network(subnet, strict=False)
    except ValueError as exc:
        return {"error": str(exc), "discovered": []}

    discovered: list[dict[str, Any]] = []
    semaphore = asyncio.Semaphore(20)  # max 20 concurrent probes

    async def probe_host(host_ip: str) -> Optional[dict[str, Any]]:
        async with semaphore:
            creds = SNMPCredentials(
                version=snmp_version,
                community=community,
                port=port,
                timeout=3.0,
                retries=1,
            )
            transport = SNMPTransport(host=host_ip, credentials=creds)
            try:
                raw = await transport.get_scalars([
                    OIDs.SYS_DESCR,
                    OIDs.SYS_OBJECT_ID,
                    OIDs.SYS_NAME,
                    OIDs.SYS_UPTIME,
                ])
                if not raw:
                    return None

                sys_descr    = _coerce_str(raw.get(OIDs.SYS_DESCR, ""))
                sys_name     = _coerce_str(raw.get(OIDs.SYS_NAME, ""))
                sys_object_id = _coerce_str(raw.get(OIDs.SYS_OBJECT_ID, ""))

                # Guess vendor from sysObjectID
                vendor = "generic"
                for prefix, v in {
                    "1.3.6.1.4.1.2636": "juniper",
                    "1.3.6.1.4.1.9.6": "cisco_sg300",
                    "1.3.6.1.4.1.9.1": "cisco_catalyst",
                    "1.3.6.1.4.1.9": "cisco_generic",
                }.items():
                    if sys_object_id.startswith(prefix):
                        vendor = v
                        break

                device_type = {
                    "juniper": "juniper_switch",
                    "cisco_sg300": "cisco_sg300",
                    "cisco_catalyst": "cisco_catalyst",
                    "cisco_generic": "cisco_catalyst",
                }.get(vendor, "generic_snmp")

                return {
                    "host": host_ip,
                    "sys_name": sys_name,
                    "sys_descr": sys_descr[:255],
                    "sys_object_id": sys_object_id,
                    "vendor": vendor,
                    "device_type": device_type,
                    "snmp_version": snmp_version,
                    "port": port,
                }
            except Exception:
                return None

    # Limit to /24 max for safety
    hosts = list(network.hosts())[:254]
    tasks = [probe_host(str(h)) for h in hosts]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for r in results:
        if isinstance(r, dict) and r:
            discovered.append(r)

    log.info(f"discovery.scan.complete subnet={subnet} found={len(discovered)}")
    return {"subnet": subnet, "scanned": len(hosts), "discovered": discovered}


# ── Retention enforcement ─────────────────────────────────────────────────────

@celery_app.task(name="app.workers.tasks.enforce_retention")
def enforce_retention() -> dict[str, Any]:
    """Drop metric records older than the configured retention window."""
    return _run(_enforce_retention_async())


async def _enforce_retention_async() -> dict[str, Any]:
    from sqlalchemy import text
    from app.core.database import get_session_factory
    from app.core.config import get_settings

    cfg = get_settings()
    factory = get_session_factory()

    async with factory() as session:
        stmt = text(f"""
            DELETE FROM metric_records
            WHERE timestamp < NOW() - INTERVAL '{cfg.METRICS_RETENTION_DAYS} days'
        """)
        result = await session.execute(stmt)
        deleted = result.rowcount or 0
        await session.commit()
        log.info(f"retention.enforced deleted={deleted} retention_days={cfg.METRICS_RETENTION_DAYS}")
        return {"deleted": deleted, "retention_days": cfg.METRICS_RETENTION_DAYS}
