"""CorePulse — API v1 router."""
from fastapi import APIRouter

from app.api.v1.endpoints.auth import router as auth_router
from app.api.v1.endpoints.devices import router as devices_router
from app.api.v1.endpoints.metrics import router as metrics_router
from app.api.v1.endpoints.alerts import router as alerts_router
from app.api.v1.endpoints.dashboards import router as dashboards_router
from app.api.v1.endpoints.misc import (
    users_router,
    audit_router,
    health_router,
    discovery_router,
    ws_router,
)

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(auth_router)
api_router.include_router(devices_router)
api_router.include_router(metrics_router)
api_router.include_router(alerts_router)
api_router.include_router(dashboards_router)
api_router.include_router(users_router)
api_router.include_router(audit_router)
api_router.include_router(health_router)
api_router.include_router(discovery_router)
api_router.include_router(ws_router)
