"""CorePulse — Alerts API endpoints."""
from __future__ import annotations

import uuid
from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy import and_, desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.security import Permissions, UserContext, require_permission
from app.models.db.base import AlertIncident, AlertRule, NotificationChannel
from app.models.schemas.all_schemas import (
    AcknowledgeIncidentRequest,
    AlertIncidentResponse,
    AlertRuleCreate,
    AlertRuleResponse,
    AlertRuleUpdate,
    NotificationChannelCreate,
    NotificationChannelResponse,
    PaginatedResponse,
)
from app.utils.encryption import encrypt_data

router = APIRouter(prefix="/alerts", tags=["alerts"])


# ── Alert Rules ───────────────────────────────────────────────────────────────

@router.get("/rules", response_model=PaginatedResponse)
async def list_rules(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_READ))],
    enabled: Optional[bool] = Query(default=None),
    severity: Optional[str] = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
) -> PaginatedResponse:
    query = select(AlertRule)
    if enabled is not None:
        query = query.where(AlertRule.enabled == enabled)
    if severity:
        query = query.where(AlertRule.severity == severity)
    query = query.order_by(AlertRule.name).limit(page_size).offset((page - 1) * page_size)
    result = await session.execute(query)
    rules = list(result.scalars().all())
    count_result = await session.execute(select(AlertRule))
    total = len(count_result.scalars().all())
    return PaginatedResponse(
        total=total, page=page, page_size=page_size,
        items=[AlertRuleResponse.model_validate(r) for r in rules],
    )


@router.post("/rules", response_model=AlertRuleResponse, status_code=201)
async def create_rule(
    body: AlertRuleCreate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_WRITE))],
) -> AlertRuleResponse:
    rule = AlertRule(
        id=uuid.uuid4(),
        name=body.name,
        description=body.description,
        device_id=body.device_id,
        device_type_filter=body.device_type_filter,
        tag_filter=body.tag_filter,
        metric=body.metric,
        condition_type=body.condition_type,
        condition_config=body.condition_config,
        severity=body.severity,
        enabled=body.enabled,
        cooldown_seconds=body.cooldown_seconds,
        notification_channel_ids=[str(c) for c in body.notification_channel_ids],
        created_by=current_user.user_id,
    )
    session.add(rule)
    await session.flush()
    return AlertRuleResponse.model_validate(rule)


@router.get("/rules/{rule_id}", response_model=AlertRuleResponse)
async def get_rule(
    rule_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_READ))],
) -> AlertRuleResponse:
    result = await session.execute(select(AlertRule).where(AlertRule.id == rule_id))
    rule = result.scalar_one_or_none()
    if not rule:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Rule not found")
    return AlertRuleResponse.model_validate(rule)


@router.patch("/rules/{rule_id}", response_model=AlertRuleResponse)
async def update_rule(
    rule_id: UUID,
    body: AlertRuleUpdate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_WRITE))],
) -> AlertRuleResponse:
    result = await session.execute(select(AlertRule).where(AlertRule.id == rule_id))
    rule = result.scalar_one_or_none()
    if not rule:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Rule not found")
    for field, value in body.model_dump(exclude_none=True).items():
        setattr(rule, field, value)
    await session.flush()
    return AlertRuleResponse.model_validate(rule)


@router.delete("/rules/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_WRITE))],
) -> None:
    result = await session.execute(select(AlertRule).where(AlertRule.id == rule_id))
    rule = result.scalar_one_or_none()
    if rule:
        await session.delete(rule)


# ── Alert Incidents ────────────────────────────────────────────────────────────

@router.get("/incidents", response_model=PaginatedResponse)
async def list_incidents(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_READ))],
    status_filter: Optional[str] = Query(default=None, alias="status"),
    severity: Optional[str] = Query(default=None),
    device_id: Optional[UUID] = Query(default=None),
    acknowledged: Optional[bool] = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
) -> PaginatedResponse:
    query = select(AlertIncident).order_by(desc(AlertIncident.triggered_at))
    if status_filter:
        query = query.where(AlertIncident.status == status_filter)
    if severity:
        query = query.where(AlertIncident.severity == severity)
    if device_id:
        query = query.where(AlertIncident.device_id == device_id)
    if acknowledged is not None:
        query = query.where(AlertIncident.acknowledged == acknowledged)

    count_q = query
    query = query.limit(page_size).offset((page - 1) * page_size)
    result = await session.execute(query)
    incidents = list(result.scalars().all())
    total_result = await session.execute(count_q)
    total = len(total_result.scalars().all())
    return PaginatedResponse(
        total=total, page=page, page_size=page_size,
        items=[AlertIncidentResponse.model_validate(i) for i in incidents],
    )


@router.post("/incidents/{incident_id}/acknowledge", response_model=AlertIncidentResponse)
async def acknowledge_incident(
    incident_id: UUID,
    body: AcknowledgeIncidentRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_ACK))],
) -> AlertIncidentResponse:
    from app.alerting.engine import AlertManager
    manager = AlertManager(session)
    incident = await manager.acknowledge_incident(incident_id, current_user.user_id)
    return AlertIncidentResponse.model_validate(incident)


# ── Notification Channels ─────────────────────────────────────────────────────

@router.get("/channels", response_model=list[NotificationChannelResponse])
async def list_channels(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_READ))],
) -> list[NotificationChannelResponse]:
    result = await session.execute(select(NotificationChannel).order_by(NotificationChannel.name))
    channels = list(result.scalars().all())
    return [NotificationChannelResponse.model_validate(c) for c in channels]


@router.post("/channels", response_model=NotificationChannelResponse, status_code=201)
async def create_channel(
    body: NotificationChannelCreate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_WRITE))],
) -> NotificationChannelResponse:
    channel = NotificationChannel(
        id=uuid.uuid4(),
        name=body.name,
        channel_type=body.channel_type,
        enabled=body.enabled,
        config_enc=encrypt_data(body.config),
        created_by=current_user.user_id,
    )
    session.add(channel)
    await session.flush()
    return NotificationChannelResponse.model_validate(channel)


@router.delete("/channels/{channel_id}", status_code=204)
async def delete_channel(
    channel_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.ALERTS_WRITE))],
) -> None:
    result = await session.execute(select(NotificationChannel).where(NotificationChannel.id == channel_id))
    ch = result.scalar_one_or_none()
    if ch:
        await session.delete(ch)
