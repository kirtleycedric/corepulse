"""CorePulse — Auth API endpoints."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.exceptions import AuthenticationError
from app.core.logging import get_logger
from app.core.security import (
    ROLE_PERMISSIONS,
    UserContext,
    create_access_token,
    create_refresh_token,
    decode_token,
    get_current_user,
    hash_password,
    verify_password,
)
from app.models.db.base import AuditLog, RefreshToken, User
from app.models.schemas.all_schemas import LoginRequest, RefreshRequest, TokenResponse, UserResponse

router = APIRouter(prefix="/auth", tags=["auth"])
log = get_logger(__name__)


@router.post("/login", response_model=TokenResponse)
async def login(
    request: Request,
    body: LoginRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> TokenResponse:
    # Find user
    result = await session.execute(
        select(User).where(User.username == body.username, User.is_active == True)
    )
    user = result.scalar_one_or_none()

    if not user or not verify_password(body.password, user.hashed_password):
        # Audit failed login
        session.add(AuditLog(
            action="auth.login.failed",
            resource_type="user",
            resource_id=body.username,
            ip_address=request.client.host if request.client else None,
            result="failure",
        ))
        await session.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    permissions = ROLE_PERMISSIONS.get(user.role, [])

    access_token = create_access_token(
        user_id=user.id,
        username=user.username,
        email=user.email,
        role=user.role,
        is_superuser=user.is_superuser,
        permissions=permissions,
    )
    refresh_token_str = create_refresh_token(user.id)
    refresh_payload = decode_token(refresh_token_str)

    # Store refresh token
    session.add(RefreshToken(
        user_id=user.id,
        jti=refresh_payload.jti,
        expires_at=datetime.fromtimestamp(refresh_payload.exp, tz=timezone.utc),
    ))

    # Update last login
    await session.execute(
        update(User).where(User.id == user.id).values(last_login_at=datetime.now(tz=timezone.utc))
    )

    # Audit success
    session.add(AuditLog(
        user_id=user.id,
        action="auth.login.success",
        resource_type="user",
        resource_id=str(user.id),
        ip_address=request.client.host if request.client else None,
        result="success",
    ))

    await session.commit()
    log.info("auth.login", user_id=str(user.id), username=user.username)

    from app.core.config import get_settings
    cfg = get_settings()
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token_str,
        expires_in=cfg.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    body: RefreshRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> TokenResponse:
    payload = decode_token(body.refresh_token)
    if payload.type != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token type")

    from uuid import UUID
    # Verify token not revoked
    result = await session.execute(
        select(RefreshToken).where(
            RefreshToken.jti == payload.jti,
            RefreshToken.revoked == False,
        )
    )
    token_record = result.scalar_one_or_none()
    if not token_record:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token revoked or not found")

    # Load user
    user_result = await session.execute(
        select(User).where(User.id == UUID(payload.sub), User.is_active == True)
    )
    user = user_result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive")

    # Rotate refresh token (revoke old, issue new)
    await session.execute(
        update(RefreshToken).where(RefreshToken.jti == payload.jti).values(revoked=True)
    )

    permissions = ROLE_PERMISSIONS.get(user.role, [])
    new_access = create_access_token(
        user_id=user.id, username=user.username, email=user.email,
        role=user.role, is_superuser=user.is_superuser, permissions=permissions,
    )
    new_refresh = create_refresh_token(user.id)
    new_payload = decode_token(new_refresh)

    session.add(RefreshToken(
        user_id=user.id,
        jti=new_payload.jti,
        expires_at=datetime.fromtimestamp(new_payload.exp, tz=timezone.utc),
    ))
    await session.commit()

    from app.core.config import get_settings
    cfg = get_settings()
    return TokenResponse(
        access_token=new_access,
        refresh_token=new_refresh,
        expires_in=cfg.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/logout", status_code=204)
async def logout(
    body: RefreshRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(get_current_user)],
) -> None:
    try:
        payload = decode_token(body.refresh_token)
        await session.execute(
            update(RefreshToken).where(RefreshToken.jti == payload.jti).values(revoked=True)
        )
        await session.commit()
    except Exception:
        pass


@router.get("/me", response_model=UserResponse)
async def get_me(
    current_user: Annotated[UserContext, Depends(get_current_user)],
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> UserResponse:
    result = await session.execute(select(User).where(User.id == current_user.user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse.model_validate(user)
