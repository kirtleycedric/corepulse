"""CorePulse — Dashboard API endpoints."""
from __future__ import annotations

import re
import uuid
from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.security import Permissions, UserContext, require_permission
from app.models.db.base import Dashboard
from app.models.schemas.all_schemas import (
    DashboardCreate, DashboardResponse, DashboardUpdate, PaginatedResponse,
)

router = APIRouter(prefix="/dashboards", tags=["dashboards"])


def _slugify(text: str) -> str:
    slug = re.sub(r"[^\w\s-]", "", text.lower())
    slug = re.sub(r"[\s_-]+", "-", slug).strip("-")
    return f"{slug}-{str(uuid.uuid4())[:8]}"


@router.get("", response_model=PaginatedResponse)
async def list_dashboards(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DASHBOARDS_READ))],
    is_template: Optional[bool] = Query(default=None),
    is_starred: Optional[bool] = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
) -> PaginatedResponse:
    from sqlalchemy import or_
    query = select(Dashboard).where(
        or_(Dashboard.owner_id == current_user.user_id, Dashboard.is_public == True)
    )
    if is_template is not None:
        query = query.where(Dashboard.is_template == is_template)
    if is_starred is not None:
        query = query.where(Dashboard.is_starred == is_starred)
    query = query.order_by(Dashboard.name).limit(page_size).offset((page - 1) * page_size)
    result = await session.execute(query)
    items = list(result.scalars().all())
    return PaginatedResponse(total=len(items), page=page, page_size=page_size,
                             items=[DashboardResponse.model_validate(d) for d in items])


@router.post("", response_model=DashboardResponse, status_code=201)
async def create_dashboard(
    body: DashboardCreate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DASHBOARDS_WRITE))],
) -> DashboardResponse:
    layout = {
        "widgets": [w.model_dump() for w in body.widgets],
    }
    dash = Dashboard(
        id=uuid.uuid4(),
        name=body.name,
        description=body.description,
        owner_id=current_user.user_id,
        is_public=body.is_public,
        is_template=body.is_template,
        layout=layout,
        variables=body.variables,
        time_range=body.time_range,
        refresh_interval_seconds=body.refresh_interval_seconds,
        tags=body.tags,
        slug=_slugify(body.name),
    )
    session.add(dash)
    await session.flush()
    return DashboardResponse.model_validate(dash)


@router.get("/{dashboard_id}", response_model=DashboardResponse)
async def get_dashboard(
    dashboard_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DASHBOARDS_READ))],
) -> DashboardResponse:
    result = await session.execute(select(Dashboard).where(Dashboard.id == dashboard_id))
    dash = result.scalar_one_or_none()
    if not dash:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    if not dash.is_public and dash.owner_id != current_user.user_id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="Access denied")
    return DashboardResponse.model_validate(dash)


@router.put("/{dashboard_id}", response_model=DashboardResponse)
async def update_dashboard(
    dashboard_id: UUID,
    body: DashboardUpdate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DASHBOARDS_WRITE))],
) -> DashboardResponse:
    result = await session.execute(select(Dashboard).where(Dashboard.id == dashboard_id))
    dash = result.scalar_one_or_none()
    if not dash:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    if dash.owner_id != current_user.user_id and not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="Not the dashboard owner")

    update_data = body.model_dump(exclude_none=True)
    if "widgets" in update_data:
        dash.layout = {"widgets": update_data.pop("widgets")}
    for field, value in update_data.items():
        setattr(dash, field, value)
    dash.version += 1
    await session.flush()
    return DashboardResponse.model_validate(dash)


@router.delete("/{dashboard_id}", status_code=204)
async def delete_dashboard(
    dashboard_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DASHBOARDS_DELETE))],
) -> None:
    result = await session.execute(select(Dashboard).where(Dashboard.id == dashboard_id))
    dash = result.scalar_one_or_none()
    if dash and (dash.owner_id == current_user.user_id or current_user.is_superuser):
        await session.delete(dash)


@router.post("/{dashboard_id}/star", status_code=204)
async def toggle_star(
    dashboard_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DASHBOARDS_READ))],
) -> None:
    result = await session.execute(select(Dashboard).where(Dashboard.id == dashboard_id))
    dash = result.scalar_one_or_none()
    if dash:
        dash.is_starred = not dash.is_starred
