"""CorePulse — Devices API endpoints."""
from __future__ import annotations

from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.security import Permissions, UserContext, get_current_user, require_permission
from app.models.schemas.all_schemas import (
    CredentialProfileCreate,
    CredentialProfileResponse,
    DeviceCreate,
    DeviceInterfaceResponse,
    DeviceResponse,
    DeviceUpdate,
    PaginatedResponse,
)
from app.services.device_service import CredentialService, DeviceService

router = APIRouter(prefix="/devices", tags=["devices"])


# ── Devices ───────────────────────────────────────────────────────────────────

@router.get("", response_model=PaginatedResponse)
async def list_devices(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_READ))],
    device_type: Optional[str] = Query(default=None),
    enabled: Optional[bool] = Query(default=None),
    site: Optional[str] = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
) -> PaginatedResponse:
    svc = DeviceService(session)
    devices, total = await svc.list_devices(
        device_type=device_type,
        enabled=enabled,
        site=site,
        limit=page_size,
        offset=(page - 1) * page_size,
    )
    return PaginatedResponse(
        total=total,
        page=page,
        page_size=page_size,
        items=[DeviceResponse.model_validate(d) for d in devices],
    )


@router.post("", response_model=DeviceResponse, status_code=status.HTTP_201_CREATED)
async def create_device(
    body: DeviceCreate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_WRITE))],
) -> DeviceResponse:
    svc = DeviceService(session)
    device = await svc.create_device(body)
    return DeviceResponse.model_validate(device)


@router.get("/{device_id}", response_model=DeviceResponse)
async def get_device(
    device_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_READ))],
) -> DeviceResponse:
    svc = DeviceService(session)
    device = await svc.get_device(device_id)
    return DeviceResponse.model_validate(device)


@router.patch("/{device_id}", response_model=DeviceResponse)
async def update_device(
    device_id: UUID,
    body: DeviceUpdate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_WRITE))],
) -> DeviceResponse:
    svc = DeviceService(session)
    device = await svc.update_device(device_id, body)
    return DeviceResponse.model_validate(device)


@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_device(
    device_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_DELETE))],
) -> None:
    svc = DeviceService(session)
    await svc.delete_device(device_id)


@router.get("/{device_id}/interfaces", response_model=list[DeviceInterfaceResponse])
async def get_device_interfaces(
    device_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_READ))],
) -> list[DeviceInterfaceResponse]:
    svc = DeviceService(session)
    device = await svc.get_device(device_id)
    return [DeviceInterfaceResponse.model_validate(i) for i in device.interfaces]


@router.post("/{device_id}/poll", status_code=status.HTTP_202_ACCEPTED)
async def trigger_poll(
    device_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_WRITE))],
) -> dict:
    """Manually trigger an immediate poll for a device."""
    svc = DeviceService(session)
    device = await svc.get_device(device_id)

    from app.workers.tasks import poll_proxmox, poll_snmp, poll_flashsystem
    task_map = {
        "proxmox_cluster": poll_proxmox,
        "flashsystem": poll_flashsystem,
        "juniper_switch": poll_snmp,
        "cisco_sg300": poll_snmp,
        "cisco_catalyst": poll_snmp,
        "generic_snmp": poll_snmp,
    }
    task_fn = task_map.get(device.device_type)
    if not task_fn:
        raise HTTPException(status_code=400, detail=f"No poller for device type: {device.device_type}")

    result = task_fn.apply_async(args=[str(device_id)], queue="collectors")
    return {"task_id": result.id, "device_id": str(device_id), "status": "queued"}


# ── Credential profiles ───────────────────────────────────────────────────────

@router.get("/credentials", response_model=list[CredentialProfileResponse], tags=["credentials"])
async def list_credential_profiles(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_READ))],
) -> list[CredentialProfileResponse]:
    svc = CredentialService(session)
    profiles = await svc.list_profiles()
    return [CredentialProfileResponse.model_validate(p) for p in profiles]


@router.post("/credentials", response_model=CredentialProfileResponse, status_code=201, tags=["credentials"])
async def create_credential_profile(
    body: CredentialProfileCreate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_WRITE))],
) -> CredentialProfileResponse:
    svc = CredentialService(session)
    profile = await svc.create_profile(body, current_user.user_id)
    return CredentialProfileResponse.model_validate(profile)


@router.delete("/credentials/{profile_id}", status_code=204, tags=["credentials"])
async def delete_credential_profile(
    profile_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_DELETE))],
) -> None:
    svc = CredentialService(session)
    await svc.delete_profile(profile_id)
