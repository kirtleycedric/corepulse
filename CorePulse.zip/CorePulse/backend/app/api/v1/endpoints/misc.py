"""CorePulse — Users, Health, Discovery, and WebSocket endpoints."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.security import (
    Permissions, UserContext, get_current_user,
    hash_password, require_permission, require_superuser,
)
from app.models.db.base import AuditLog, User
from app.models.schemas.all_schemas import (
    AuditLogResponse, HealthResponse, PaginatedResponse, UserCreate, UserResponse, UserUpdate,
)

# ── Users ─────────────────────────────────────────────────────────────────────
users_router = APIRouter(prefix="/users", tags=["users"])


@users_router.get("", response_model=PaginatedResponse)
async def list_users(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.USERS_READ))],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
) -> PaginatedResponse:
    query = select(User).order_by(User.username).limit(page_size).offset((page - 1) * page_size)
    result = await session.execute(query)
    users = list(result.scalars().all())
    total_result = await session.execute(select(User))
    total = len(total_result.scalars().all())
    return PaginatedResponse(total=total, page=page, page_size=page_size,
                             items=[UserResponse.model_validate(u) for u in users])


@users_router.post("", response_model=UserResponse, status_code=201)
async def create_user(
    body: UserCreate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.USERS_WRITE))],
) -> UserResponse:
    # Check uniqueness
    existing = await session.execute(
        select(User).where(User.username == body.username)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Username already exists")

    user = User(
        id=uuid.uuid4(),
        username=body.username,
        email=body.email,
        full_name=body.full_name,
        hashed_password=hash_password(body.password),
        role=body.role,
        is_superuser=body.is_superuser,
    )
    session.add(user)
    await session.flush()
    return UserResponse.model_validate(user)


@users_router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.USERS_READ))],
) -> UserResponse:
    result = await session.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse.model_validate(user)


@users_router.patch("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: UUID,
    body: UserUpdate,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.USERS_WRITE))],
) -> UserResponse:
    result = await session.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    update_data = body.model_dump(exclude_none=True)
    if "password" in update_data:
        update_data["hashed_password"] = hash_password(update_data.pop("password"))
    for field, value in update_data.items():
        setattr(user, field, value)
    await session.flush()
    return UserResponse.model_validate(user)


@users_router.delete("/{user_id}", status_code=204)
async def delete_user(
    user_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_superuser)],
) -> None:
    result = await session.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user and user.id != current_user.user_id:
        await session.delete(user)


# ── Audit log ─────────────────────────────────────────────────────────────────
audit_router = APIRouter(prefix="/audit", tags=["audit"])


@audit_router.get("", response_model=PaginatedResponse)
async def list_audit_logs(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.AUDIT_READ))],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=100, ge=1, le=500),
    action: Optional[str] = Query(default=None),
) -> PaginatedResponse:
    from sqlalchemy import desc
    query = select(AuditLog).order_by(desc(AuditLog.timestamp))
    if action:
        query = query.where(AuditLog.action.contains(action))
    query = query.limit(page_size).offset((page - 1) * page_size)
    result = await session.execute(query)
    logs = list(result.scalars().all())
    return PaginatedResponse(total=len(logs), page=page, page_size=page_size,
                             items=[AuditLogResponse.model_validate(l) for l in logs])


# ── Health ─────────────────────────────────────────────────────────────────────
health_router = APIRouter(prefix="/health", tags=["health"])


@health_router.get("", response_model=HealthResponse)
async def health_check(session: Annotated[AsyncSession, Depends(get_db_session)]) -> HealthResponse:
    from sqlalchemy import text
    from app.core.config import get_settings
    from app.core.redis import get_redis
    cfg = get_settings()
    services: dict[str, str] = {}
    try:
        await session.execute(text("SELECT 1"))
        services["database"] = "healthy"
    except Exception as e:
        services["database"] = f"unhealthy: {e}"
    try:
        redis = await get_redis()
        await redis.ping()
        services["redis"] = "healthy"
    except Exception as e:
        services["redis"] = f"unhealthy: {e}"

    overall = "healthy" if all("unhealthy" not in v for v in services.values()) else "degraded"
    return HealthResponse(
        status=overall,
        version=cfg.APP_VERSION,
        timestamp=datetime.now(tz=timezone.utc),
        services=services,
    )


# ── Discovery ──────────────────────────────────────────────────────────────────
discovery_router = APIRouter(prefix="/discovery", tags=["discovery"])


@discovery_router.post("/scan")
async def trigger_discovery_scan(
    subnet: str,
    community: str = "public",
    snmp_version: str = "2c",
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_WRITE))] = None,
) -> dict:
    from app.workers.tasks import discovery_scan
    result = discovery_scan.apply_async(
        args=[subnet, community, snmp_version],
        queue="discovery",
    )
    return {"task_id": result.id, "subnet": subnet, "status": "queued"}


@discovery_router.get("/result/{task_id}")
async def get_discovery_result(
    task_id: str,
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.DEVICES_READ))] = None,
) -> dict:
    from app.workers.celery_app import celery_app
    result = celery_app.AsyncResult(task_id)
    if result.ready():
        return {"status": "complete", "result": result.result}
    return {"status": result.state.lower(), "task_id": task_id}


# ── WebSocket ──────────────────────────────────────────────────────────────────
ws_router = APIRouter(prefix="/ws", tags=["websocket"])


@ws_router.websocket("")
async def websocket_endpoint(websocket: WebSocket) -> None:
    """
    Main WebSocket endpoint.
    Query params: token (JWT access token)
    Client protocol:
      subscribe   → {"type": "subscribe", "room": "device:{uuid}"}
      unsubscribe → {"type": "unsubscribe", "room": "alerts:global"}
      ping        → {"type": "ping"}
    """
    from app.core.security import decode_token
    from app.websocket.hub import hub

    # Authenticate via query param token
    token = websocket.query_params.get("token")
    user_id: Optional[UUID] = None
    if token:
        try:
            payload = decode_token(token)
            user_id = UUID(payload.sub)
        except Exception:
            await websocket.close(code=4001)
            return

    state = await hub.connect(websocket, user_id=user_id)

    try:
        while True:
            data = await websocket.receive_text()
            await hub.handle_client_message(state.conn_id, data)
    except WebSocketDisconnect:
        pass
    finally:
        await hub.disconnect(state.conn_id)
