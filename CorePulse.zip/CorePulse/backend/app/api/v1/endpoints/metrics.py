"""CorePulse — Metrics API endpoints."""
from __future__ import annotations

from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.security import Permissions, UserContext, require_permission
from app.models.schemas.all_schemas import MetricQueryRequest, MetricSeries, DeviceSummaryMetrics
from app.services.metrics_service import MetricsService

router = APIRouter(prefix="/metrics", tags=["metrics"])


@router.post("/query", response_model=list[MetricSeries])
async def query_metrics(
    body: MetricQueryRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.METRICS_READ))],
) -> list[MetricSeries]:
    svc = MetricsService(session)
    return await svc.query_series(body)


@router.get("/device/{device_id}/summary")
async def get_device_summary(
    device_id: UUID,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.METRICS_READ))],
) -> dict:
    svc = MetricsService(session)
    return await svc.get_device_summary(device_id)


@router.get("/top-talkers")
async def get_top_talkers(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.METRICS_READ))],
    metric: str = Query(default="if.in_octets"),
    device_id: Optional[UUID] = Query(default=None),
    limit: int = Query(default=10, ge=1, le=50),
    window_minutes: int = Query(default=5, ge=1, le=60),
) -> list[dict]:
    svc = MetricsService(session)
    return await svc.get_top_talkers(device_id, metric, limit, window_minutes)


@router.get("/stats")
async def get_metrics_stats(
    session: Annotated[AsyncSession, Depends(get_db_session)],
    current_user: Annotated[UserContext, Depends(require_permission(Permissions.METRICS_READ))],
) -> dict:
    svc = MetricsService(session)
    return await svc.get_stats()
