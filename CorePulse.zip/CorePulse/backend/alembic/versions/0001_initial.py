"""Initial schema with TimescaleDB hypertable and retention.

Revision ID: 0001_initial
Revises:
Create Date: 2025-01-01 00:00:00.000000
"""
from __future__ import annotations

from typing import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0001_initial"
down_revision: str | None = None
branch_labels: Sequence[str] | None = None
depends_on: Sequence[str] | None = None


def upgrade() -> None:
    # ── Users ─────────────────────────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("username", sa.String(64), nullable=False, unique=True),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("full_name", sa.String(256), nullable=False, default=""),
        sa.Column("hashed_password", sa.String(256), nullable=False),
        sa.Column("role", sa.String(32), nullable=False, default="viewer"),
        sa.Column("is_active", sa.Boolean, nullable=False, default=True),
        sa.Column("is_superuser", sa.Boolean, nullable=False, default=False),
        sa.Column("avatar_url", sa.String(512)),
        sa.Column("last_login_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_users_username", "users", ["username"])
    op.create_index("ix_users_email", "users", ["email"])

    # ── Refresh tokens ────────────────────────────────────────────────────────
    op.create_table(
        "refresh_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("jti", sa.String(64), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked", sa.Boolean, nullable=False, default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_refresh_tokens_user_id", "refresh_tokens", ["user_id"])
    op.create_index("ix_refresh_tokens_jti", "refresh_tokens", ["jti"])

    # ── Credential profiles ────────────────────────────────────────────────────
    op.create_table(
        "credential_profiles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False, unique=True),
        sa.Column("description", sa.Text, nullable=False, default=""),
        sa.Column("protocol", sa.String(32), nullable=False),
        sa.Column("credentials_enc", sa.Text, nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ── Devices ────────────────────────────────────────────────────────────────
    op.create_table(
        "devices",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("display_name", sa.String(255), nullable=False, default=""),
        sa.Column("device_type", sa.String(64), nullable=False),
        sa.Column("host", sa.String(255), nullable=False),
        sa.Column("port", sa.Integer),
        sa.Column("enabled", sa.Boolean, nullable=False, default=True),
        sa.Column("poll_interval_seconds", sa.Integer, nullable=False, default=60),
        sa.Column("credential_profile_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("credential_profiles.id", ondelete="SET NULL")),
        sa.Column("location", sa.String(255), nullable=False, default=""),
        sa.Column("site", sa.String(128), nullable=False, default=""),
        sa.Column("tags", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("metadata", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("sys_descr", sa.Text),
        sa.Column("sys_object_id", sa.String(255)),
        sa.Column("sys_name", sa.String(255)),
        sa.Column("firmware_version", sa.String(128)),
        sa.Column("model", sa.String(128)),
        sa.Column("vendor", sa.String(64)),
        sa.Column("serial_number", sa.String(128)),
        sa.Column("last_seen_at", sa.DateTime(timezone=True)),
        sa.Column("last_poll_at", sa.DateTime(timezone=True)),
        sa.Column("last_poll_status", sa.String(32)),
        sa.Column("consecutive_failures", sa.Integer, nullable=False, default=0),
        sa.Column("parent_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="SET NULL")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_devices_device_type", "devices", ["device_type"])
    op.create_index("ix_devices_enabled", "devices", ["enabled"])
    op.create_index("ix_devices_type_enabled", "devices", ["device_type", "enabled"])
    op.create_unique_constraint("uq_device_host_type", "devices", ["host", "device_type"])

    # ── Device interfaces ──────────────────────────────────────────────────────
    op.create_table(
        "device_interfaces",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE"), nullable=False),
        sa.Column("if_index", sa.Integer, nullable=False),
        sa.Column("if_name", sa.String(128), nullable=False),
        sa.Column("if_alias", sa.String(255), nullable=False, default=""),
        sa.Column("if_descr", sa.String(255), nullable=False, default=""),
        sa.Column("if_type", sa.Integer, nullable=False, default=6),
        sa.Column("if_speed_bps", sa.BigInteger, nullable=False, default=0),
        sa.Column("if_phys_addr", sa.String(32), nullable=False, default=""),
        sa.Column("if_admin_status", sa.SmallInteger, nullable=False, default=1),
        sa.Column("if_oper_status", sa.SmallInteger, nullable=False, default=2),
        sa.Column("vlan_id", sa.Integer),
        sa.Column("lldp_neighbor", sa.String(255)),
        sa.Column("lldp_neighbor_port", sa.String(128)),
        sa.Column("cdp_neighbor", sa.String(255)),
        sa.Column("enabled_monitoring", sa.Boolean, nullable=False, default=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_device_interfaces_device_id", "device_interfaces", ["device_id"])
    op.create_unique_constraint("uq_interface_device_ifindex", "device_interfaces", ["device_id", "if_index"])

    # ── Metric records (TimescaleDB hypertable) ────────────────────────────────
    op.create_table(
        "metric_records",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE"), nullable=False),
        sa.Column("metric", sa.String(255), nullable=False),
        sa.Column("value", sa.Double, nullable=False),
        sa.Column("metric_type", sa.String(32), nullable=False, default="gauge"),
        sa.Column("unit", sa.String(32), nullable=False, default=""),
        sa.Column("labels", postgresql.JSONB, nullable=False, server_default="{}"),
    )
    op.create_index("ix_metric_records_timestamp", "metric_records", ["timestamp"])
    op.create_index("ix_metric_records_device_metric_time", "metric_records",
                    ["device_id", "metric", "timestamp"])

    # Convert to TimescaleDB hypertable (partitioned by timestamp, 4-hour chunks)
    op.execute(
        "SELECT create_hypertable('metric_records', 'timestamp', "
        "chunk_time_interval => INTERVAL '4 hours', if_not_exists => TRUE)"
    )

    # Compression policy: compress chunks older than 7 days
    op.execute("""
        ALTER TABLE metric_records SET (
            timescaledb.compress,
            timescaledb.compress_orderby = 'timestamp DESC',
            timescaledb.compress_segmentby = 'device_id, metric'
        )
    """)
    op.execute(
        "SELECT add_compression_policy('metric_records', INTERVAL '7 days')"
    )

    # Retention policy: drop data older than 90 days
    op.execute(
        "SELECT add_retention_policy('metric_records', INTERVAL '90 days')"
    )

    # Continuous aggregate: 1-minute buckets
    op.execute("""
        CREATE MATERIALIZED VIEW metric_1m
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 minute', timestamp) AS bucket,
            device_id,
            metric,
            AVG(value) AS avg_val,
            MAX(value) AS max_val,
            MIN(value) AS min_val,
            LAST(value, timestamp) AS last_val
        FROM metric_records
        GROUP BY bucket, device_id, metric
        WITH NO DATA
    """)
    op.execute(
        "SELECT add_continuous_aggregate_policy('metric_1m', "
        "start_offset => INTERVAL '1 hour', end_offset => INTERVAL '1 minute', "
        "schedule_interval => INTERVAL '1 minute')"
    )

    # ── Proxmox tables ─────────────────────────────────────────────────────────
    op.create_table(
        "proxmox_clusters",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("cluster_name", sa.String(128), nullable=False),
        sa.Column("quorate", sa.Boolean, nullable=False, default=False),
        sa.Column("node_count", sa.Integer, nullable=False, default=0),
        sa.Column("ha_enabled", sa.Boolean, nullable=False, default=False),
        sa.Column("pve_version", sa.String(32), nullable=False, default=""),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "proxmox_nodes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("cluster_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("proxmox_clusters.id", ondelete="SET NULL")),
        sa.Column("node_name", sa.String(128), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, default="unknown"),
        sa.Column("cpu_count", sa.Integer, nullable=False, default=0),
        sa.Column("cpu_util", sa.Float, nullable=False, default=0.0),
        sa.Column("mem_total_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("mem_used_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("disk_total_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("disk_used_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("uptime_seconds", sa.BigInteger, nullable=False, default=0),
        sa.Column("pve_version", sa.String(32), nullable=False, default=""),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "virtual_machines",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("node_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("proxmox_nodes.id", ondelete="SET NULL")),
        sa.Column("vmid", sa.Integer, nullable=False),
        sa.Column("vm_name", sa.String(255), nullable=False),
        sa.Column("vm_type", sa.String(16), nullable=False, default="qemu"),
        sa.Column("status", sa.String(32), nullable=False, default="unknown"),
        sa.Column("cpu_count", sa.Integer, nullable=False, default=0),
        sa.Column("cpu_util", sa.Float, nullable=False, default=0.0),
        sa.Column("mem_total_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("mem_used_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("disk_total_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("disk_used_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("netin_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("netout_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("uptime_seconds", sa.BigInteger, nullable=False, default=0),
        sa.Column("ha_managed", sa.Boolean, nullable=False, default=False),
        sa.Column("ha_state", sa.String(32)),
        sa.Column("template", sa.Boolean, nullable=False, default=False),
        sa.Column("tags", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ── FlashSystem tables ─────────────────────────────────────────────────────
    op.create_table(
        "flashsystem_arrays",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("array_name", sa.String(128), nullable=False),
        sa.Column("model", sa.String(64), nullable=False, default=""),
        sa.Column("code_level", sa.String(32), nullable=False, default=""),
        sa.Column("location", sa.String(128), nullable=False, default=""),
        sa.Column("total_capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("used_capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("free_capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("read_iops", sa.Double, nullable=False, default=0),
        sa.Column("write_iops", sa.Double, nullable=False, default=0),
        sa.Column("read_bandwidth_mbps", sa.Double, nullable=False, default=0),
        sa.Column("write_bandwidth_mbps", sa.Double, nullable=False, default=0),
        sa.Column("read_latency_us", sa.Double, nullable=False, default=0),
        sa.Column("write_latency_us", sa.Double, nullable=False, default=0),
        sa.Column("status", sa.String(32), nullable=False, default="unknown"),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "flashsystem_pools",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("array_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("flashsystem_arrays.id", ondelete="CASCADE"), nullable=False),
        sa.Column("pool_id", sa.String(64), nullable=False),
        sa.Column("pool_name", sa.String(128), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, default="online"),
        sa.Column("capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("used_capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("free_capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("overallocation_pct", sa.Double, nullable=False, default=0),
        sa.Column("compression_ratio", sa.Double, nullable=False, default=1),
        sa.Column("dedupe_ratio", sa.Double, nullable=False, default=1),
        sa.Column("drive_count", sa.Integer, nullable=False, default=0),
        sa.Column("mdisk_count", sa.Integer, nullable=False, default=0),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_unique_constraint("uq_pool_array_poolid", "flashsystem_pools", ["array_id", "pool_id"])

    op.create_table(
        "flashsystem_volumes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("array_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("flashsystem_arrays.id", ondelete="CASCADE"), nullable=False),
        sa.Column("pool_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("flashsystem_pools.id", ondelete="SET NULL")),
        sa.Column("volume_id", sa.String(64), nullable=False),
        sa.Column("volume_name", sa.String(255), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, default="online"),
        sa.Column("capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("used_capacity_bytes", sa.BigInteger, nullable=False, default=0),
        sa.Column("read_iops", sa.Double, nullable=False, default=0),
        sa.Column("write_iops", sa.Double, nullable=False, default=0),
        sa.Column("read_bandwidth_mbps", sa.Double, nullable=False, default=0),
        sa.Column("write_bandwidth_mbps", sa.Double, nullable=False, default=0),
        sa.Column("read_latency_us", sa.Double, nullable=False, default=0),
        sa.Column("write_latency_us", sa.Double, nullable=False, default=0),
        sa.Column("throttle_pct", sa.Double, nullable=False, default=0),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_unique_constraint("uq_volume_array_volid", "flashsystem_volumes", ["array_id", "volume_id"])

    # ── Alert rules + incidents ────────────────────────────────────────────────
    op.create_table(
        "alert_rules",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=False, default=""),
        sa.Column("device_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("devices.id", ondelete="CASCADE")),
        sa.Column("device_type_filter", sa.String(64)),
        sa.Column("tag_filter", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("metric", sa.String(255), nullable=False),
        sa.Column("condition_type", sa.String(32), nullable=False),
        sa.Column("condition_config", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("severity", sa.String(16), nullable=False, default="warning"),
        sa.Column("enabled", sa.Boolean, nullable=False, default=True),
        sa.Column("cooldown_seconds", sa.Integer, nullable=False, default=300),
        sa.Column("notification_channel_ids", postgresql.JSONB, nullable=False, server_default="[]"),
        sa.Column("maintenance_until", sa.DateTime(timezone=True)),
        sa.Column("created_by", postgresql.UUID(as_uuid=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "alert_incidents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("rule_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("alert_rules.id", ondelete="CASCADE"), nullable=False),
        sa.Column("device_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("metric", sa.String(255), nullable=False),
        sa.Column("severity", sa.String(16), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, default="firing"),
        sa.Column("trigger_value", sa.Double, nullable=False),
        sa.Column("trigger_labels", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("message", sa.Text, nullable=False, default=""),
        sa.Column("triggered_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("resolved_at", sa.DateTime(timezone=True)),
        sa.Column("acknowledged", sa.Boolean, nullable=False, default=False),
        sa.Column("acknowledged_by", postgresql.UUID(as_uuid=True)),
        sa.Column("acknowledged_at", sa.DateTime(timezone=True)),
        sa.Column("notification_sent", sa.Boolean, nullable=False, default=False),
        sa.Column("notification_attempts", sa.Integer, nullable=False, default=0),
    )
    op.create_index("ix_alert_incidents_rule_id", "alert_incidents", ["rule_id"])
    op.create_index("ix_alert_incidents_device_id", "alert_incidents", ["device_id"])
    op.create_index("ix_alert_incidents_triggered_at", "alert_incidents", ["triggered_at"])
    op.create_index("ix_incidents_status_time", "alert_incidents", ["status", "triggered_at"])

    # ── Notification channels ──────────────────────────────────────────────────
    op.create_table(
        "notification_channels",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("channel_type", sa.String(32), nullable=False),
        sa.Column("enabled", sa.Boolean, nullable=False, default=True),
        sa.Column("config_enc", sa.Text, nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ── Dashboards ─────────────────────────────────────────────────────────────
    op.create_table(
        "dashboards",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=False, default=""),
        sa.Column("owner_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("is_public", sa.Boolean, nullable=False, default=False),
        sa.Column("is_template", sa.Boolean, nullable=False, default=False),
        sa.Column("is_starred", sa.Boolean, nullable=False, default=False),
        sa.Column("layout", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("variables", postgresql.JSONB, nullable=False, server_default="{}"),
        sa.Column("time_range", sa.String(32), nullable=False, default="1h"),
        sa.Column("refresh_interval_seconds", sa.Integer, nullable=False, default=30),
        sa.Column("tags", postgresql.JSONB, nullable=False, server_default="[]"),
        sa.Column("version", sa.Integer, nullable=False, default=1),
        sa.Column("slug", sa.String(128), nullable=False, unique=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_dashboards_slug", "dashboards", ["slug"])

    # ── Audit logs ─────────────────────────────────────────────────────────────
    op.create_table(
        "audit_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("action", sa.String(128), nullable=False),
        sa.Column("resource_type", sa.String(64), nullable=False),
        sa.Column("resource_id", sa.String(64)),
        sa.Column("old_value", postgresql.JSONB),
        sa.Column("new_value", postgresql.JSONB),
        sa.Column("ip_address", sa.String(45)),
        sa.Column("user_agent", sa.String(512)),
        sa.Column("result", sa.String(16), nullable=False, default="success"),
        sa.Column("timestamp", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_audit_logs_user_id", "audit_logs", ["user_id"])
    op.create_index("ix_audit_logs_action", "audit_logs", ["action"])
    op.create_index("ix_audit_logs_timestamp", "audit_logs", ["timestamp"])

    # ── Default admin user ─────────────────────────────────────────────────────
    import uuid as _uuid
    import bcrypt
    admin_id = str(_uuid.uuid4())
    hashed = bcrypt.hashpw(b"corepulse", bcrypt.gensalt(rounds=12)).decode()
    op.execute(f"""
        INSERT INTO users (id, username, email, full_name, hashed_password, role, is_active, is_superuser)
        VALUES ('{admin_id}', 'admin', 'admin@corepulse.local', 'Administrator',
                '{hashed}', 'admin', true, true)
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS metric_1m CASCADE")
    tables = [
        "audit_logs", "dashboards", "notification_channels",
        "alert_incidents", "alert_rules",
        "flashsystem_volumes", "flashsystem_pools", "flashsystem_arrays",
        "virtual_machines", "proxmox_nodes", "proxmox_clusters",
        "metric_records", "device_interfaces", "devices",
        "credential_profiles", "refresh_tokens", "users",
    ]
    for table in tables:
        op.drop_table(table)
