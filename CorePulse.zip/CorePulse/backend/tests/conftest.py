"""
CorePulse test configuration.
Provides async database sessions, test client, and fixture helpers.
"""
from __future__ import annotations

import asyncio
import uuid
from typing import AsyncGenerator, Generator

import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import get_settings
from app.core.database import Base, get_db_session
from app.core.security import ROLE_PERMISSIONS, create_access_token, hash_password
from app.main import create_app
from app.models.db.base import User

# ── Test database URL ─────────────────────────────────────────────────────────
TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

_engine = create_async_engine(TEST_DB_URL, echo=False)
_SessionFactory = async_sessionmaker(
    bind=_engine, class_=AsyncSession,
    expire_on_commit=False, autocommit=False, autoflush=False,
)


@pytest.fixture(scope="session")
def event_loop():
    policy = asyncio.get_event_loop_policy()
    loop = policy.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with _SessionFactory() as session:
        yield session
        await session.rollback()
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture(scope="function")
async def app(db_session: AsyncSession) -> FastAPI:
    application = create_app()
    application.dependency_overrides[get_db_session] = lambda: db_session
    return application


@pytest_asyncio.fixture(scope="function")
async def client(app: FastAPI) -> AsyncGenerator[AsyncClient, None]:
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as c:
        yield c


@pytest_asyncio.fixture(scope="function")
async def admin_user(db_session: AsyncSession) -> User:
    user = User(
        id=uuid.uuid4(),
        username="testadmin",
        email="admin@test.local",
        full_name="Test Admin",
        hashed_password=hash_password("TestPass123!"),
        role="admin",
        is_active=True,
        is_superuser=True,
    )
    db_session.add(user)
    await db_session.flush()
    return user


@pytest_asyncio.fixture(scope="function")
async def viewer_user(db_session: AsyncSession) -> User:
    user = User(
        id=uuid.uuid4(),
        username="testviewer",
        email="viewer@test.local",
        full_name="Test Viewer",
        hashed_password=hash_password("TestPass123!"),
        role="viewer",
        is_active=True,
        is_superuser=False,
    )
    db_session.add(user)
    await db_session.flush()
    return user


def make_auth_header(user: User) -> dict[str, str]:
    token = create_access_token(
        user_id=user.id,
        username=user.username,
        email=user.email,
        role=user.role,
        is_superuser=user.is_superuser,
        permissions=ROLE_PERMISSIONS.get(user.role, []),
    )
    return {"Authorization": f"Bearer {token}"}
