"""Tests for authentication endpoints."""
from __future__ import annotations

import pytest
from httpx import AsyncClient

from app.models.db.base import User
from tests.conftest import make_auth_header


class TestLogin:
    @pytest.mark.asyncio
    async def test_login_success(self, client: AsyncClient, admin_user: User) -> None:
        resp = await client.post("/api/v1/auth/login", json={
            "username": "testadmin",
            "password": "TestPass123!",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    @pytest.mark.asyncio
    async def test_login_wrong_password(self, client: AsyncClient, admin_user: User) -> None:
        resp = await client.post("/api/v1/auth/login", json={
            "username": "testadmin",
            "password": "wrong",
        })
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_login_unknown_user(self, client: AsyncClient) -> None:
        resp = await client.post("/api/v1/auth/login", json={
            "username": "nobody",
            "password": "pass",
        })
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_get_me_authenticated(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get("/api/v1/auth/me", headers=headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["username"] == "testadmin"
        assert data["role"] == "admin"

    @pytest.mark.asyncio
    async def test_get_me_unauthenticated(self, client: AsyncClient) -> None:
        resp = await client.get("/api/v1/auth/me")
        assert resp.status_code in (401, 403)

    @pytest.mark.asyncio
    async def test_refresh_token(self, client: AsyncClient, admin_user: User) -> None:
        # Login first
        login_resp = await client.post("/api/v1/auth/login", json={
            "username": "testadmin",
            "password": "TestPass123!",
        })
        refresh_token = login_resp.json()["refresh_token"]

        # Refresh
        resp = await client.post("/api/v1/auth/refresh", json={"refresh_token": refresh_token})
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert "refresh_token" in data

    @pytest.mark.asyncio
    async def test_refresh_with_access_token_fails(self, client: AsyncClient, admin_user: User) -> None:
        """Access token must not be accepted as refresh token."""
        headers = make_auth_header(admin_user)
        # Get an access token and try to use it as refresh
        login_resp = await client.post("/api/v1/auth/login", json={
            "username": "testadmin",
            "password": "TestPass123!",
        })
        access_token = login_resp.json()["access_token"]
        resp = await client.post("/api/v1/auth/refresh", json={"refresh_token": access_token})
        assert resp.status_code == 401
