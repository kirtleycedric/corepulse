"""Unit tests for core modules: security, encryption, alerting, collectors."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pytest

from app.core.security import (
    ROLE_PERMISSIONS,
    Permissions,
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.utils.encryption import decrypt_data, encrypt_data
from app.alerting.engine import AlertEvaluator
from app.models.db.base import AlertRule


class TestSecurity:
    def test_hash_verify_password(self) -> None:
        plain = "SuperSecret123!"
        hashed = hash_password(plain)
        assert hashed != plain
        assert verify_password(plain, hashed)
        assert not verify_password("wrong", hashed)

    def test_hash_is_salted(self) -> None:
        """Same password should produce different hashes."""
        plain = "password"
        h1 = hash_password(plain)
        h2 = hash_password(plain)
        assert h1 != h2  # Different salts

    def test_create_decode_access_token(self) -> None:
        user_id = uuid.uuid4()
        token = create_access_token(
            user_id=user_id,
            username="alice",
            email="alice@test.com",
            role="admin",
            is_superuser=True,
            permissions=ROLE_PERMISSIONS["admin"],
        )
        payload = decode_token(token)
        assert payload.sub == str(user_id)
        assert payload.type == "access"
        assert payload.role == "admin"
        assert payload.is_superuser is True
        assert Permissions.DEVICES_READ in payload.permissions

    def test_create_refresh_token(self) -> None:
        user_id = uuid.uuid4()
        token = create_refresh_token(user_id)
        payload = decode_token(token)
        assert payload.sub == str(user_id)
        assert payload.type == "refresh"

    def test_role_permissions_viewer(self) -> None:
        perms = ROLE_PERMISSIONS["viewer"]
        assert Permissions.DEVICES_READ in perms
        assert Permissions.METRICS_READ in perms
        assert Permissions.DEVICES_WRITE not in perms
        assert Permissions.USERS_WRITE not in perms

    def test_role_permissions_admin(self) -> None:
        perms = ROLE_PERMISSIONS["admin"]
        assert Permissions.USERS_WRITE in perms
        assert Permissions.SYSTEM_WRITE in perms
        assert Permissions.AUDIT_READ in perms

    def test_role_escalation_blocked(self) -> None:
        """Viewer does not have engineer permissions."""
        viewer_perms = set(ROLE_PERMISSIONS["viewer"])
        engineer_perms = set(ROLE_PERMISSIONS["engineer"])
        assert not viewer_perms.issuperset(engineer_perms)


class TestEncryption:
    def test_encrypt_decrypt_roundtrip(self) -> None:
        data = {"username": "admin", "password": "secret123", "community": "public"}
        ciphertext = encrypt_data(data)
        assert isinstance(ciphertext, str)
        assert ciphertext != str(data)
        recovered = decrypt_data(ciphertext)
        assert recovered == data

    def test_encrypt_nested_data(self) -> None:
        data = {
            "version": "3",
            "auth": {"protocol": "SHA256", "key": "myauthkey"},
            "priv": {"protocol": "AES", "key": "myprivkey"},
        }
        ct = encrypt_data(data)
        result = decrypt_data(ct)
        assert result["auth"]["protocol"] == "SHA256"

    def test_decrypt_invalid_data_raises(self) -> None:
        from app.core.exceptions import CorePulseError
        with pytest.raises(CorePulseError):
            decrypt_data("notvalidciphertext")

    def test_different_encryptions_produce_different_ciphertext(self) -> None:
        """Fernet uses random IV so same data → different ciphertext each time."""
        data = {"key": "value"}
        ct1 = encrypt_data(data)
        ct2 = encrypt_data(data)
        assert ct1 != ct2


class TestAlertEvaluator:
    def _make_rule(self, operator: str, threshold: float, condition_type: str = "threshold") -> AlertRule:
        rule = AlertRule()
        rule.condition_type = condition_type
        rule.condition_config = {"operator": operator, "threshold": threshold}
        rule.severity = "warning"
        return rule

    def test_threshold_greater_than_fires(self) -> None:
        rule = self._make_rule(">", 80.0)
        assert AlertEvaluator.evaluate(rule, 90.0, {}) is True

    def test_threshold_greater_than_does_not_fire(self) -> None:
        rule = self._make_rule(">", 80.0)
        assert AlertEvaluator.evaluate(rule, 70.0, {}) is False

    def test_threshold_equals_fires(self) -> None:
        rule = self._make_rule("==", 0.0)
        assert AlertEvaluator.evaluate(rule, 0.0, {}) is True

    def test_threshold_not_equals(self) -> None:
        rule = self._make_rule("!=", 1.0)
        assert AlertEvaluator.evaluate(rule, 2.0, {}) is True
        assert AlertEvaluator.evaluate(rule, 1.0, {}) is False

    def test_less_than(self) -> None:
        rule = self._make_rule("<", 10.0)
        assert AlertEvaluator.evaluate(rule, 5.0, {}) is True
        assert AlertEvaluator.evaluate(rule, 15.0, {}) is False

    def test_greater_equal(self) -> None:
        rule = self._make_rule(">=", 90.0)
        assert AlertEvaluator.evaluate(rule, 90.0, {}) is True
        assert AlertEvaluator.evaluate(rule, 89.9, {}) is False

    def test_unknown_operator_returns_false(self) -> None:
        rule = self._make_rule("??", 50.0)
        assert AlertEvaluator.evaluate(rule, 100.0, {}) is False

    def test_state_condition_fires_on_mismatch(self) -> None:
        rule = AlertRule()
        rule.condition_type = "state"
        rule.condition_config = {"expected_state": 1}  # expect UP
        rule.severity = "critical"
        # Current value 0 (down) ≠ expected 1 (up) → fire
        assert AlertEvaluator.evaluate(rule, 0.0, {}) is True
        # Current value 1 (up) = expected → no fire
        assert AlertEvaluator.evaluate(rule, 1.0, {}) is False

    def test_format_message(self) -> None:
        rule = self._make_rule(">", 90.0)
        rule.name = "CPU Alert"
        rule.metric = "cpu.util"
        rule.severity = "critical"
        msg = AlertEvaluator.format_message(rule, 95.3, "core-switch-1")
        assert "CPU Alert" in msg
        assert "core-switch-1" in msg
        assert "95.3" in msg


class TestFlashSystemCapacityParser:
    def test_parse_tb(self) -> None:
        from app.collectors.flashsystem.collector import FlashSystemCollector
        assert FlashSystemCollector._to_bytes("1.5 TB") == int(1.5 * 1024**4)

    def test_parse_gb(self) -> None:
        from app.collectors.flashsystem.collector import FlashSystemCollector
        assert FlashSystemCollector._to_bytes("500 GB") == 500 * 1024**3

    def test_parse_zero(self) -> None:
        from app.collectors.flashsystem.collector import FlashSystemCollector
        assert FlashSystemCollector._to_bytes("0") == 0

    def test_parse_empty(self) -> None:
        from app.collectors.flashsystem.collector import FlashSystemCollector
        assert FlashSystemCollector._to_bytes("") == 0

    def test_parse_raw_bytes(self) -> None:
        from app.collectors.flashsystem.collector import FlashSystemCollector
        assert FlashSystemCollector._to_bytes("1024") == 1024


class TestProxmoxMetricParsing:
    def test_parse_node_metrics(self) -> None:
        from app.collectors.proxmox.collector import ProxmoxCollector
        collector = ProxmoxCollector(
            device_id=uuid.uuid4(),
            host="10.0.0.1",
            credentials={},
        )
        node_data = {
            "node": "pve1",
            "status": "online",
            "cpu": 0.45,
            "maxmem": 64 * 1024**3,
            "mem": 32 * 1024**3,
            "uptime": 86400,
        }
        metrics = collector._parse_node(node_data, "pve1")
        names = [m["metric"] for m in metrics]
        assert "node.cpu_util" in names
        assert "node.mem_util" in names
        assert "node.uptime" in names

        cpu_metric = next(m for m in metrics if m["metric"] == "node.cpu_util")
        assert abs(cpu_metric["value"] - 45.0) < 0.01

    def test_parse_vm_resources(self) -> None:
        from app.collectors.proxmox.collector import ProxmoxCollector
        collector = ProxmoxCollector(
            device_id=uuid.uuid4(),
            host="10.0.0.1",
            credentials={},
        )
        resources = [{
            "type": "qemu",
            "vmid": 100,
            "name": "test-vm",
            "node": "pve1",
            "status": "running",
            "cpu": 0.2,
            "maxmem": 4 * 1024**3,
            "mem": 2 * 1024**3,
        }]
        metrics, states = collector._parse_resources(resources)
        assert len(states) == 1
        assert states[0]["vmid"] == 100
        assert states[0]["status"] == "running"
        names = [m["metric"] for m in metrics]
        assert "qemu.status" in names
        assert "qemu.cpu_util" in names
