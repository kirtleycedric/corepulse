"""Tests for device and metrics API endpoints."""
from __future__ import annotations

import uuid
import pytest
from httpx import AsyncClient

from app.models.db.base import Device, User
from tests.conftest import make_auth_header


class TestDevices:
    @pytest.mark.asyncio
    async def test_list_devices_empty(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get("/api/v1/devices", headers=headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["items"] == []

    @pytest.mark.asyncio
    async def test_create_device(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.post("/api/v1/devices", headers=headers, json={
            "name": "test-switch-01",
            "device_type": "juniper_switch",
            "host": "10.0.0.1",
            "port": 161,
            "enabled": True,
            "poll_interval_seconds": 60,
            "location": "DC1",
            "site": "main",
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "test-switch-01"
        assert data["device_type"] == "juniper_switch"
        assert data["host"] == "10.0.0.1"
        return data["id"]

    @pytest.mark.asyncio
    async def test_create_device_duplicate_fails(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        payload = {"name": "dup", "device_type": "juniper_switch", "host": "10.0.0.2"}
        await client.post("/api/v1/devices", headers=headers, json=payload)
        resp = await client.post("/api/v1/devices", headers=headers, json=payload)
        assert resp.status_code == 409

    @pytest.mark.asyncio
    async def test_get_device(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        create_resp = await client.post("/api/v1/devices", headers=headers, json={
            "name": "get-test",
            "device_type": "cisco_sg300",
            "host": "10.0.0.3",
        })
        device_id = create_resp.json()["id"]
        resp = await client.get(f"/api/v1/devices/{device_id}", headers=headers)
        assert resp.status_code == 200
        assert resp.json()["id"] == device_id

    @pytest.mark.asyncio
    async def test_get_nonexistent_device(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get(f"/api/v1/devices/{uuid.uuid4()}", headers=headers)
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_update_device(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        create_resp = await client.post("/api/v1/devices", headers=headers, json={
            "name": "update-test",
            "device_type": "cisco_catalyst",
            "host": "10.0.0.4",
        })
        device_id = create_resp.json()["id"]
        resp = await client.patch(f"/api/v1/devices/{device_id}", headers=headers, json={
            "display_name": "Updated Display",
            "location": "New Location",
        })
        assert resp.status_code == 200
        assert resp.json()["location"] == "New Location"

    @pytest.mark.asyncio
    async def test_delete_device(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        create_resp = await client.post("/api/v1/devices", headers=headers, json={
            "name": "delete-test",
            "device_type": "generic_snmp",
            "host": "10.0.0.5",
        })
        device_id = create_resp.json()["id"]
        del_resp = await client.delete(f"/api/v1/devices/{device_id}", headers=headers)
        assert del_resp.status_code == 204
        # Verify gone
        get_resp = await client.get(f"/api/v1/devices/{device_id}", headers=headers)
        assert get_resp.status_code == 404

    @pytest.mark.asyncio
    async def test_viewer_cannot_create_device(self, client: AsyncClient, viewer_user: User) -> None:
        headers = make_auth_header(viewer_user)
        resp = await client.post("/api/v1/devices", headers=headers, json={
            "name": "forbidden",
            "device_type": "generic",
            "host": "10.0.0.6",
        })
        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_list_devices_with_type_filter(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        # Create mixed types
        for i, dtype in enumerate(["juniper_switch", "cisco_sg300", "flashsystem"]):
            await client.post("/api/v1/devices", headers=headers, json={
                "name": f"filter-{dtype}",
                "device_type": dtype,
                "host": f"10.1.0.{i+1}",
            })
        resp = await client.get("/api/v1/devices?device_type=juniper_switch", headers=headers)
        assert resp.status_code == 200
        items = resp.json()["items"]
        assert all(d["device_type"] == "juniper_switch" for d in items)


class TestMetrics:
    @pytest.mark.asyncio
    async def test_metrics_query_empty(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.post("/api/v1/metrics/query", headers=headers, json={
            "metric": "cpu.util",
            "aggregation": "avg",
            "bucket_interval": "5m",
        })
        assert resp.status_code == 200
        assert resp.json() == []

    @pytest.mark.asyncio
    async def test_metrics_stats(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get("/api/v1/metrics/stats", headers=headers)
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_metrics_forbidden_for_unauthenticated(self, client: AsyncClient) -> None:
        resp = await client.post("/api/v1/metrics/query", json={"metric": "cpu.util"})
        assert resp.status_code in (401, 403)


class TestAlertRules:
    @pytest.mark.asyncio
    async def test_create_alert_rule(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.post("/api/v1/alerts/rules", headers=headers, json={
            "name": "CPU High",
            "metric": "cpu.util",
            "device_type_filter": "juniper_switch",
            "condition_type": "threshold",
            "condition_config": {"operator": ">", "threshold": 90},
            "severity": "critical",
            "enabled": True,
            "cooldown_seconds": 300,
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "CPU High"
        assert data["severity"] == "critical"

    @pytest.mark.asyncio
    async def test_list_alert_rules(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get("/api/v1/alerts/rules", headers=headers)
        assert resp.status_code == 200
        assert "total" in resp.json()

    @pytest.mark.asyncio
    async def test_list_incidents(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get("/api/v1/alerts/incidents", headers=headers)
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_viewer_cannot_create_alert_rule(self, client: AsyncClient, viewer_user: User) -> None:
        headers = make_auth_header(viewer_user)
        resp = await client.post("/api/v1/alerts/rules", headers=headers, json={
            "name": "Forbidden",
            "metric": "cpu.util",
            "condition_type": "threshold",
            "condition_config": {"operator": ">", "threshold": 50},
        })
        assert resp.status_code == 403


class TestHealth:
    @pytest.mark.asyncio
    async def test_health_endpoint(self, client: AsyncClient) -> None:
        resp = await client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert "status" in data
        assert "version" in data
        assert "services" in data

    @pytest.mark.asyncio
    async def test_root_endpoint(self, client: AsyncClient) -> None:
        resp = await client.get("/")
        assert resp.status_code == 200
        assert resp.json()["service"] == "CorePulse API"


class TestDashboards:
    @pytest.mark.asyncio
    async def test_create_dashboard(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.post("/api/v1/dashboards", headers=headers, json={
            "name": "Test Dashboard",
            "description": "Unit test dashboard",
            "is_public": False,
            "widgets": [],
            "time_range": "1h",
            "refresh_interval_seconds": 30,
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Test Dashboard"
        assert "slug" in data

    @pytest.mark.asyncio
    async def test_list_dashboards(self, client: AsyncClient, admin_user: User) -> None:
        headers = make_auth_header(admin_user)
        resp = await client.get("/api/v1/dashboards", headers=headers)
        assert resp.status_code == 200
