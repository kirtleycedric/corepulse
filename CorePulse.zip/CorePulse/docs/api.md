# CorePulse REST API Reference

Base URL: `https://your-domain.com/api/v1`

All API endpoints require JWT Bearer authentication unless noted.

---

## Authentication

### POST /auth/login

Authenticate and receive JWT tokens.

**Request:**
```json
{ "username": "admin", "password": "corepulse" }
```

**Response 200:**
```json
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

### POST /auth/refresh

Rotate refresh token and get new access token.

**Request:**
```json
{ "refresh_token": "eyJ..." }
```

### POST /auth/logout

Revoke refresh token.

### GET /auth/me

Returns current authenticated user.

---

## Devices

### GET /devices

List all devices with optional filters.

| Query Param | Type | Description |
|---|---|---|
| device_type | string | Filter by type (juniper_switch, etc.) |
| enabled | boolean | Filter by enabled state |
| site | string | Filter by site |
| page | int | Page number (default: 1) |
| page_size | int | Results per page (max: 200) |

**Response 200:**
```json
{
  "total": 12,
  "page": 1,
  "page_size": 50,
  "items": [{ "id": "...", "name": "...", ... }]
}
```

### POST /devices

Create a new device.

```json
{
  "name": "core-switch-01",
  "display_name": "Core Switch",
  "device_type": "juniper_switch",
  "host": "10.0.0.1",
  "port": 161,
  "enabled": true,
  "poll_interval_seconds": 60,
  "credential_profile_id": "uuid",
  "location": "DC1 Rack A",
  "site": "main",
  "tags": {"env": "prod"}
}
```

**device_type values:**
`proxmox_cluster` | `proxmox_node` | `vm` | `container` | `flashsystem` | `juniper_switch` | `cisco_sg300` | `cisco_catalyst` | `generic_snmp`

### GET /devices/{id}

Get device by UUID.

### PATCH /devices/{id}

Update device fields (partial update).

### DELETE /devices/{id}

Delete device. Cascades to interfaces and metrics.

### GET /devices/{id}/interfaces

List all SNMP interfaces discovered on a device.

### POST /devices/{id}/poll

Trigger an immediate poll (returns Celery task ID).

---

## Credentials

### GET /devices/credentials

List all credential profiles (without exposing decrypted credentials).

### POST /devices/credentials

```json
{
  "name": "SNMP Production",
  "protocol": "snmp_v2c",
  "credentials": {
    "version": "2c",
    "community": "public"
  }
}
```

**protocol values:** `snmp_v2c` | `snmp_v3` | `api_token` | `ssh` | `rest_basic` | `rest_bearer`

### DELETE /devices/credentials/{id}

---

## Metrics

### POST /metrics/query

Query time-series data.

```json
{
  "device_id": "uuid",
  "metric": "cpu.util",
  "from_ts": "2025-01-01T00:00:00Z",
  "to_ts": "2025-01-01T01:00:00Z",
  "aggregation": "avg",
  "bucket_interval": "1m",
  "limit": 1000
}
```

**aggregation:** `avg` | `max` | `min` | `sum` | `last` | `count`

**bucket_interval:** `1m` | `5m` | `15m` | `30m` | `1h` | `6h` | `1d`

**Response:**
```json
[
  {
    "device_id": "uuid",
    "metric": "cpu.util",
    "unit": "percent",
    "data": [
      { "timestamp": "2025-01-01T00:01:00Z", "value": 23.5, "labels": {} }
    ]
  }
]
```

### GET /metrics/device/{id}/summary

Returns latest values of all tracked metrics for a device.

### GET /metrics/top-talkers

```
?metric=if.in_octets&limit=10&window_minutes=5
```

### GET /metrics/stats

Returns aggregate statistics about the metrics database.

---

## Alerts

### GET /alerts/rules

List alert rules with optional filters.

### POST /alerts/rules

```json
{
  "name": "CPU Critical",
  "metric": "cpu.util",
  "device_type_filter": "juniper_switch",
  "condition_type": "threshold",
  "condition_config": {
    "operator": ">",
    "threshold": 90.0
  },
  "severity": "critical",
  "enabled": true,
  "cooldown_seconds": 300,
  "notification_channel_ids": ["uuid1", "uuid2"]
}
```

**severity:** `info` | `warning` | `critical`

**condition_type:** `threshold` | `state` | `absent`

**operators:** `>` | `>=` | `<` | `<=` | `==` | `!=`

### PATCH /alerts/rules/{id}

### DELETE /alerts/rules/{id}

### GET /alerts/incidents

```
?status=firing&severity=critical&acknowledged=false&page=1
```

### POST /alerts/incidents/{id}/acknowledge

```json
{ "note": "Investigating - ticket #1234" }
```

### GET /alerts/channels

### POST /alerts/channels

```json
{
  "name": "NOC Slack",
  "channel_type": "slack",
  "config": {
    "webhook_url": "https://hooks.slack.com/..."
  }
}
```

**channel_type:** `email` | `slack` | `teams` | `telegram` | `webhook`

---

## Dashboards

### GET /dashboards

```
?is_template=false&is_starred=true
```

### POST /dashboards

```json
{
  "name": "Network Overview",
  "description": "Core switch metrics",
  "is_public": false,
  "widgets": [
    {
      "id": "w1",
      "type": "timeseries",
      "x": 0, "y": 0, "w": 6, "h": 4,
      "config": {
        "metric": "cpu.util",
        "unit": "percent",
        "title": "Switch CPU"
      }
    }
  ],
  "time_range": "1h",
  "refresh_interval_seconds": 30
}
```

### GET /dashboards/{id}

### PUT /dashboards/{id}

Full dashboard update (replaces widget layout).

### DELETE /dashboards/{id}

### POST /dashboards/{id}/star

Toggle starred status.

---

## Users

### GET /users

### POST /users

```json
{
  "username": "alice",
  "email": "alice@company.com",
  "full_name": "Alice Smith",
  "password": "SecurePass123!",
  "role": "engineer"
}
```

**roles:** `viewer` | `operator` | `engineer` | `admin`

### PATCH /users/{id}

### DELETE /users/{id}

Superuser only.

---

## Discovery

### POST /discovery/scan

```
?subnet=10.0.0.0/24&community=public&snmp_version=2c
```

Returns `{ "task_id": "...", "status": "queued" }`.

### GET /discovery/result/{task_id}

Polls for scan completion.

---

## WebSocket

**URL:** `wss://your-domain.com/api/v1/ws?token={access_token}`

### Client messages

```json
// Subscribe to a room
{"type": "subscribe", "room": "device:uuid"}
{"type": "subscribe", "room": "alerts:global"}
{"type": "subscribe", "room": "dashboard:uuid"}

// Unsubscribe
{"type": "unsubscribe", "room": "device:uuid"}

// Ping
{"type": "ping"}
```

### Server messages

```json
// Metric update
{"type": "metric_update", "device_id": "uuid", "metric": "cpu.util", "value": 45.3, "labels": {}}

// Alert event
{"type": "alert_event", "event": "incident_fired", "incident_id": "uuid", "severity": "critical", "message": "..."}

// Alert resolved
{"type": "alert_event", "event": "incident_resolved", "incident_id": "uuid"}

// Heartbeat (every 30s)
{"type": "heartbeat", "timestamp": "2025-01-01T00:00:00Z"}
```

---

## Health

### GET /health

Returns platform health status (no auth required).

```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2025-01-01T00:00:00Z",
  "services": {
    "database": "healthy",
    "redis": "healthy"
  }
}
```

---

## Error Responses

All errors follow the same format:

```json
{
  "error": {
    "code": "NOT_FOUND",
    "message": "Device abc123 not found",
    "detail": null
  }
}
```

| HTTP Code | Error Code | Meaning |
|---|---|---|
| 400 | VALIDATION_ERROR | Invalid request body |
| 401 | AUTHENTICATION_ERROR | Missing or invalid token |
| 403 | AUTHORIZATION_ERROR | Insufficient permissions |
| 404 | NOT_FOUND | Resource not found |
| 409 | CONFLICT | Duplicate resource |
| 422 | VALIDATION_ERROR | Request validation failed |
| 429 | RATE_LIMIT_EXCEEDED | Too many requests |
| 500 | INTERNAL_ERROR | Server error |
| 502 | COLLECTOR_ERROR | Device polling failure |

---

## RBAC Permissions

| Permission | viewer | operator | engineer | admin |
|---|---|---|---|---|
| devices:read | ✓ | ✓ | ✓ | ✓ |
| devices:write | | | ✓ | ✓ |
| devices:delete | | | | ✓ |
| metrics:read | ✓ | ✓ | ✓ | ✓ |
| dashboards:read | ✓ | ✓ | ✓ | ✓ |
| dashboards:write | | ✓ | ✓ | ✓ |
| dashboards:delete | | | ✓ | ✓ |
| alerts:read | ✓ | ✓ | ✓ | ✓ |
| alerts:write | | | ✓ | ✓ |
| alerts:acknowledge | | ✓ | ✓ | ✓ |
| users:read | | | | ✓ |
| users:write | | | | ✓ |
| audit:read | | | | ✓ |
