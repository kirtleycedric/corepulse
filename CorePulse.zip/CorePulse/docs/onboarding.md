# CorePulse Device Onboarding Guide

---

## Proxmox VE

### Prerequisites

- Proxmox VE 7.x or 8.x
- API token with read access (do NOT use root password auth in production)

### Create API Token

In Proxmox UI: **Datacenter → Permissions → API Tokens → Add**

```
User: monitoring@pve
Token ID: corepulse
Privilege Separation: checked
```

Grant read permissions:
```
Datacenter → Permissions → Add → API Token Permission
  Path: /
  API Token: monitoring@pve!corepulse
  Role: PVEAuditor
  Propagate: checked
```

### Add Credential Profile

```bash
curl -X POST https://corepulse.local/api/v1/devices/credentials \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "Proxmox API Token",
    "protocol": "api_token",
    "credentials": {
      "token_id": "monitoring@pve!corepulse",
      "token_secret": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
      "verify_ssl": false
    }
  }'
```

### Add Proxmox Cluster Device

```bash
curl -X POST https://corepulse.local/api/v1/devices \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "pve-prod-cluster",
    "display_name": "Production PVE",
    "device_type": "proxmox_cluster",
    "host": "10.0.1.10",
    "port": 8006,
    "poll_interval_seconds": 30,
    "credential_profile_id": "<profile-uuid>",
    "location": "DC1 Rack A1",
    "site": "headquarters"
  }'
```

---

## IBM FlashSystem 9100

### Prerequisites

- FlashSystem 9100 with REST API enabled (port 7443)
- Dedicated monitoring user with read-only access

### Create Monitoring User

SSH to FlashSystem management:
```
svctask mkuser -name corepulse -password 'StrongPass123!' -role Monitor
```

### Add Credential Profile

```bash
curl -X POST https://corepulse.local/api/v1/devices/credentials \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "FlashSystem REST",
    "protocol": "rest_basic",
    "credentials": {
      "username": "corepulse",
      "password": "StrongPass123!",
      "verify_ssl": false
    }
  }'
```

### Add FlashSystem Device

```bash
curl -X POST https://corepulse.local/api/v1/devices \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "fs9100-prod",
    "display_name": "FlashSystem 9100 Production",
    "device_type": "flashsystem",
    "host": "10.0.2.50",
    "port": 7443,
    "poll_interval_seconds": 60,
    "credential_profile_id": "<profile-uuid>",
    "location": "DC1 Rack B3"
  }'
```

---

## Network Switches — SNMP

### Juniper EX/QFX

Enable SNMP on Juniper:
```
set snmp community <community-string> authorization read-only
set snmp community <community-string> clients 10.0.0.0/24
commit
```

For SNMPv3:
```
set snmp v3 usm local-engine user corepulse authentication-md5 authentication-key <key>
set snmp v3 usm local-engine user corepulse privacy-des privacy-key <key>
set snmp v3 vacm security-to-group security-model usm security-name corepulse group monitor
set snmp v3 vacm access group monitor default-context-prefix security-model any security-level authentication read-view all
commit
```

### Cisco SG300 / SG500

Enable SNMP via web UI:
`Administration → SNMP → Communities → Add`
- Community String: your-community
- Access: Read Only
- View Name: Default

### Cisco Catalyst IOS

```
snmp-server community <community> RO
snmp-server location "DC1 Core"
snmp-server contact "noc@company.com"
```

### Add SNMPv2c Credential Profile

```bash
curl -X POST https://corepulse.local/api/v1/devices/credentials \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "SNMP v2c Production",
    "protocol": "snmp_v2c",
    "credentials": {
      "version": "2c",
      "community": "your-community-string",
      "port": 161,
      "timeout": 10,
      "retries": 2
    }
  }'
```

### Add Switch Devices

```bash
# Juniper switch
curl -X POST https://corepulse.local/api/v1/devices \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "sw-core-01",
    "device_type": "juniper_switch",
    "host": "10.0.3.1",
    "poll_interval_seconds": 60,
    "credential_profile_id": "<snmp-profile-uuid>",
    "location": "DC1 Core Rack"
  }'

# Cisco SG300
curl -X POST https://corepulse.local/api/v1/devices \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "sw-access-01",
    "device_type": "cisco_sg300",
    "host": "10.0.3.10",
    "credential_profile_id": "<snmp-profile-uuid>"
  }'
```

---

## SNMP Discovery (Bulk)

```bash
# Scan entire /24 subnet
curl -X POST "https://corepulse.local/api/v1/discovery/scan?subnet=10.0.3.0/24&community=public" \
  -H "Authorization: Bearer $TOKEN"

# Returns: {"task_id": "...", "status": "queued"}

# Check results
curl "https://corepulse.local/api/v1/discovery/result/<task-id>" \
  -H "Authorization: Bearer $TOKEN"
```

---

## Alert Rules — Quick Examples

### CPU > 90% on any switch

```bash
curl -X POST https://corepulse.local/api/v1/alerts/rules \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "Switch CPU Critical",
    "metric": "cpu.util",
    "device_type_filter": "juniper_switch",
    "condition_type": "threshold",
    "condition_config": {"operator": ">", "threshold": 90},
    "severity": "critical",
    "cooldown_seconds": 300
  }'
```

### Storage utilisation > 85%

```bash
curl -X POST https://corepulse.local/api/v1/alerts/rules \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "Storage High Utilisation",
    "metric": "storage.util",
    "device_type_filter": "flashsystem",
    "condition_type": "threshold",
    "condition_config": {"operator": ">", "threshold": 85},
    "severity": "warning"
  }'
```

### Proxmox node offline

```bash
curl -X POST https://corepulse.local/api/v1/alerts/rules \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "PVE Node Offline",
    "metric": "node.status",
    "device_type_filter": "proxmox_node",
    "condition_type": "state",
    "condition_config": {"expected_state": 1},
    "severity": "critical",
    "cooldown_seconds": 60
  }'
```
