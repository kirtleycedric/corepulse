# CorePulse Architecture

## Overview

CorePulse uses a five-tier, fully asynchronous architecture designed for horizontal scaling and operational resilience.

## Tier Architecture

```
Tier 1: Edge
  NGINX — TLS termination, rate limiting, WebSocket proxying, static caching

Tier 2: Application
  FastAPI API server (4+ uvicorn workers, async)
  Next.js frontend (standalone Node.js)

Tier 3: Message Bus / Cache
  Redis — Celery broker, pub/sub for WebSocket fan-out, metric caching, rate limit state

Tier 4: Workers
  Celery collectors queue   — Proxmox, SNMP, FlashSystem polling (8 concurrency)
  Celery alerts queue       — Alert rule evaluation (30s interval)
  Celery notifications queue — Email, Slack, Teams, Telegram dispatch
  Celery discovery queue    — SNMP subnet discovery
  Celery beat (RedBeat)     — Schedule management via Redis

Tier 5: Persistence
  TimescaleDB hypertable    — Time-series metrics (90d retention, 4h chunks, 7d compression)
  PostgreSQL tables         — Devices, users, rules, dashboards, audit
  TimescaleDB continuous aggregate — 1-minute metric rollups
```

## Data Flow

### Metric Collection

```
Celery beat (60s)
  → health_sweep task
    → inspects devices, checks last_poll_at
    → dispatches poll_proxmox / poll_snmp / poll_flashsystem per device

poll_proxmox / poll_snmp / poll_flashsystem
  → async collector (aiohttp / pysnmp)
    → returns list[MetricRecord dicts]
  → MetricsService.ingest_batch() — PostgreSQL unnest() bulk insert
  → CacheManager.set() — cache last value per device+metric key
  → DeviceService.update_device_status() — update last_poll_at, status
  → session.commit()
```

### Alert Evaluation

```
Celery beat (30s)
  → evaluate_alerts task
    → AlertManager.evaluate_all_rules()
      → for each enabled AlertRule:
        → get target device IDs (specific or filtered)
        → for each device:
          → Redis GET last_metric:{device_id}:{metric}
          → AlertEvaluator.evaluate() — threshold/state check
          → if firing && no existing incident:
            → AlertDeduplicator.is_in_cooldown() — Redis cooldown check
            → if not cooling: create AlertIncident, publish to Redis pub/sub
          → if resolved && incident exists: resolve incident
    → session.commit()
```

### WebSocket Live Updates

```
Redis pub/sub channel: corepulse:alerts
                       corepulse:device:{uuid}
                       corepulse:dashboard:{uuid}

WebSocketHub._redis_listener_loop()
  → subscribes to corepulse:* pattern
  → on message: routes to appropriate WS room
    → hub.broadcast_to_room("alerts:global", msg)
    → hub.broadcast_to_room("device:{uuid}", msg)

Client subscriptions:
  WS connect → {"type": "subscribe", "room": "alerts:global"}
  WS connect → {"type": "subscribe", "room": "device:{uuid}"}
```

## Database Schema

### Time-Series (TimescaleDB hypertable)

```sql
metric_records
  id          BIGSERIAL PRIMARY KEY
  timestamp   TIMESTAMPTZ NOT NULL   -- partition key, 4h chunks
  device_id   UUID NOT NULL
  metric      TEXT NOT NULL          -- e.g. "cpu.util", "if.in_octets"
  value       FLOAT8 NOT NULL
  metric_type TEXT DEFAULT 'gauge'   -- gauge | counter | status
  unit        TEXT DEFAULT ''
  labels      JSONB DEFAULT '{}'     -- {if_index, if_name, node, ...}

-- Hypertable: chunk_time_interval = '4 hours'
-- Compression: 7 days (segmentby = device_id, metric)
-- Retention: 90 days
-- Continuous aggregate: metric_1m (1-minute avg/max/min/last)
```

### Key Relations

```
users ──< dashboards
users ──< audit_logs
users ──< notification_channels

credential_profiles ──< devices
devices ──< device_interfaces
devices ──< metric_records
devices ──< alert_rules
devices ──< proxmox_clusters
devices ──< proxmox_nodes
devices ──< virtual_machines
devices ──< flashsystem_arrays

flashsystem_arrays ──< flashsystem_pools
flashsystem_arrays ──< flashsystem_volumes

alert_rules ──< alert_incidents
```

## Collector Design

### Vendor Abstraction (SNMP)

```
AbstractSNMPDriver
  └── collect_system()
  └── collect_cpu()
  └── collect_memory()
  └── collect_interfaces()   ← standard IF-MIB + HC extension
  └── collect()              ← parallel gather

JuniperDriver       → jnxOperatingTable, jnxRe
CiscoSG300Driver    → vendor OIDs + HR-MIB fallback
CiscoCatalystDriver → CISCO-PROCESS-MIB, CDP
GenericSNMPDriver   → HR-MIB only
```

### Proxmox Collection

```
ProxmoxAPIClient
  └── /cluster/status        ← quorate, node count
  └── /cluster/resources     ← VMs, containers, all resource types
  └── /nodes                 ← per-node stats
  └── /cluster/ha/status     ← HA quorum

ProxmoxCollector
  └── asyncio.gather() — parallel collection of all endpoints
  └── Returns: list[MetricRecord], cluster_state dict
```

### FlashSystem Collection

```
FlashSystemAPIClient
  └── /rest/v1/auth          ← session token
  └── /rest/v1/system        ← capacity, status
  └── /rest/v1/mdiskgroup    ← pools
  └── /rest/v1/vdisk         ← volumes
  └── /rest/v1/iostats/vdisk ← I/O stats per volume
  └── /rest/v1/drive         ← drive health
  └── /rest/v1/node          ← controller status
  └── /rest/v1/iostats/node  ← controller I/O

FlashSystemCollector
  └── asyncio.gather() — all endpoints in parallel
  └── Returns: list[MetricRecord], array_state dict
```

## Security Architecture

```
Transport: TLS 1.2/1.3 via NGINX (ECDHE ciphers)
Auth: JWT HS256 (60-min access + 30-day refresh w/ rotation)
RBAC: flat permission strings in JWT payload, checked per endpoint
Passwords: bcrypt cost=12
Credentials: AES-256-GCM (Fernet) symmetric encryption
Rate limiting: 100 req/s global, 10 req/m login (NGINX + app layer)
Audit: every auth event + resource mutation logged with IP
```

## Scaling Notes

- **Horizontal API**: scale `api` service replicas (all stateless)
- **Horizontal workers**: scale `worker` replicas; Celery auto-distributes tasks
- **Redis Cluster**: supported by switching to redis-cluster URL pattern
- **TimescaleDB**: supports read replicas for query scaling
- **WebSocket**: current design uses single-process hub per worker; for multi-worker WS, deploy behind sticky-session NGINX or migrate to Redis-backed WS (e.g., Socket.IO cluster adapter pattern)
