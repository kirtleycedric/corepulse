# CorePulse — Installation & Deployment Guide

## Prerequisites

| Requirement | Minimum | Recommended |
|---|---|---|
| OS | Ubuntu 22.04 / RHEL 9 | Ubuntu 22.04 LTS |
| CPU | 4 cores | 8+ cores |
| RAM | 8 GB | 16+ GB |
| Disk | 100 GB SSD | 500 GB+ NVMe SSD |
| Docker | 24.x | Latest |
| Docker Compose | 2.x | Latest |

---

## Installation

### Step 1 — Install Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
```

### Step 2 — Install Docker Compose v2

```bash
sudo apt-get install docker-compose-plugin
docker compose version
```

### Step 3 — Clone CorePulse

```bash
git clone https://github.com/your-org/corepulse.git /opt/corepulse
cd /opt/corepulse
```

### Step 4 — Configure environment

```bash
cp .env.example .env
# Edit .env with your settings
nano .env
```

**Mandatory variables to change:**
```bash
SECRET_KEY=$(openssl rand -hex 32)    # Paste output into .env
POSTGRES_PASSWORD=your-strong-password
ALLOWED_ORIGINS=https://your-domain.com
```

### Step 5 — Generate SSL certificate

For production, use Let's Encrypt:
```bash
# Install certbot
sudo apt-get install certbot
sudo certbot certonly --standalone -d your-domain.com

# Copy certs
mkdir -p deployments/ssl
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem deployments/ssl/cert.pem
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem deployments/ssl/key.pem
sudo chown $USER:$USER deployments/ssl/*.pem
```

For development/testing only:
```bash
make gen-ssl
```

### Step 6 — Update NGINX config

Edit `deployments/nginx/conf.d/corepulse.conf`:
- Change `server_name` to your domain
- Verify SSL cert paths

### Step 7 — Start the stack

```bash
make up
```

Wait ~30 seconds for all containers to start, then run migrations:

```bash
make migrate
```

### Step 8 — Verify

```bash
make ps           # All containers should show "Up"
curl http://localhost/api/v1/health  # Should return {"status": "healthy"}
```

Access the UI at `https://your-domain.com`

Default credentials: `admin` / `corepulse` — **change immediately!**

---

## Post-Installation Configuration

### Change Admin Password

```bash
curl -X PATCH https://your-domain.com/api/v1/users/<admin-uuid> \
  -H "Authorization: Bearer <token>" \
  -d '{"password": "your-new-strong-password"}'
```

### Configure Backup Cron

```bash
echo "0 2 * * * /opt/corepulse/scripts/backup.sh >> /var/log/corepulse-backup.log 2>&1" | crontab -
```

### Configure Log Rotation

```bash
cat > /etc/logrotate.d/corepulse << 'LOGEOF'
/var/log/corepulse-*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
}
LOGEOF
```

---

## Scaling

### Scale API horizontally

```bash
docker compose up -d --scale api=4
```

### Scale Celery workers

```bash
docker compose up -d --scale worker=4
```

Workers have built-in concurrency of 8 tasks each, so 4 workers = 32 concurrent device polls.

---

## Upgrade Procedure

```bash
cd /opt/corepulse
git pull
make backup    # Always backup first
make up        # Rebuilds images with --build flag
make migrate   # Apply any new migrations
```

---

## Troubleshooting

### Containers not starting

```bash
make logs       # Check all logs
make logs-api   # Check API specifically
docker compose ps  # Check health status
```

### TimescaleDB hypertable not created

```bash
docker compose exec db psql -U corepulse -d corepulse \
  -c "SELECT * FROM timescaledb_information.hypertables;"
```

If empty, run:
```bash
make migrate
```

### SNMP polls timing out

Check:
1. Device is reachable: `docker compose exec worker ping <device-ip>`
2. SNMP community is correct in credential profile
3. UDP port 161 is open: `nc -zu <device-ip> 161`

### WebSocket not connecting

Ensure NGINX proxy is forwarding the `Upgrade` header (see nginx config). Check:
- `Authorization` header in WS connect URL contains valid JWT
- CORS `ALLOWED_ORIGINS` includes your frontend URL

---

## Backup & Restore

```bash
# Backup now
make backup

# Schedule daily backup
echo "0 2 * * * /opt/corepulse/scripts/backup.sh" | crontab -

# Restore from backup
gzip -dc backups/corepulse_20250101_020000.sql.gz | \
  docker compose exec -T db psql -U corepulse corepulse
```

---

## Security Hardening

1. **Change default admin password** immediately after setup
2. **Rotate SECRET_KEY** if compromised (`make down`, update `.env`, `make up`, re-login all users)
3. **Enable firewall**: only expose ports 80 and 443 publicly
4. **Use real SSL**: avoid self-signed certs in production
5. **Database**: ensure `POSTGRES_PASSWORD` is strong and not default
6. **ALLOWED_ORIGINS**: list only your frontend domain(s)
7. **Audit logs**: regularly review `/api/v1/audit` for suspicious activity
